#!/bin/sh
TOOLDIR=../../tools/src
for i in "" .sfst .ofst .foma; do
    if ((test -z "$i") || $1hfst-format --list-formats | grep $i > /dev/null); then
        if test -f non_minimal$i ; then
            if ! $1hfst-remove-epsilons non_minimal$i > test ; then
                exit 1
            fi
            if ! $1hfst-compare -s test non_minimal$i  ; then
                exit 1
            fi
            rm test;
        fi
    fi
done
