#!/bin/sh
TOOLDIR=../../tools/src
if [ "$srcdir" = "" ] ; then
    srcdir=. ;
fi

if ! $1hfst-pmatch2fst ./pmatch_blanks.txt > test ; then
        exit 1
    fi
# Test with any old string
if ! $1hfst-pmatch test < ./cat.strings > pmatch.out ; then
        exit 1
    fi
rm -f pmatch.out test
exit 0
