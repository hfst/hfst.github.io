#!/bin/sh
TOOLDIR=../../tools/src
if [ "$srcdir" = "" ] ; then
    srcdir=. ;
fi

for i in sfst openfst-tropical foma; do
    
    if ! ($1hfst-format --list-formats | grep $i > /dev/null) ; then
	continue;
    fi
    
    if ! $1hfst-regexp2fst -f $i ./cats_and_dogs.xre > test ; then
        exit 1
    fi
    
    rm test;
    if ! $1hfst-regexp2fst -S -f $i ./cats_and_dogs_semicolon.xre > test ; then
        exit 1
    fi
    
    rm test;
    if ! $1hfst-regexp2fst -f $i ./at_file_quote.$i.xre > test.fst ; then
        exit 1
    fi
    
    if ! $1hfst-regexp2fst -f $i ./not-contains-a.xre > test.fst ; then
        exit 1
    fi
    
    if ! $1hfst-regexp2fst -S -f $i ./not-contains-a-comment-emptyline.xre > test.fst ; then
        exit 1
    fi
    
    if ! $1hfst-regexp2fst -f $i ./parallel-left-arrow.xre > test.fst ; then
        exit 1
    fi
    
    if ! $1hfst-regexp2fst -S -f $i ./parallel-left-arrow-multicom-emptyline.xre > test.fst ; then
        exit 1
    fi

    if ! $1hfst-regexp2fst -S -f $i ./left-arrow-with-semicolon-comment.xre > test.fst ; then
        exit 1
    fi

    if ! $1hfst-regexp2fst -S -f $i ./left-arrow-with-semicolon-many-comments.xre > test.fst ; then
        exit 1
    fi

    # Empty input and input containing only comments
    if (echo "" | $1hfst-regexp2fst -f $i > test.fst 2> /dev/null) ; then
        exit 1
    fi
    if (echo "" | $1hfst-regexp2fst -S -f $i > test.fst 2> /dev/null) ; then
        exit 1
    fi
    if (echo ";" | $1hfst-regexp2fst -S -f $i > test.fst 2> /dev/null) ; then
        exit 1
    fi
    if (echo "! A comment" | $1hfst-regexp2fst -S -f $i > test.fst 2> /dev/null) ; then
        exit 1
    fi
    if (echo "  ! A comment" | $1hfst-regexp2fst -S -f $i > test.fst 2> /dev/null) ; then
        exit 1
    fi
    if (echo "! A comment" | $1hfst-regexp2fst -f $i > test.fst 2> /dev/null) ; then
        exit 1
    fi
    if (echo "  ! A comment" | $1hfst-regexp2fst -f $i > test.fst 2> /dev/null) ; then
        exit 1
    fi

done

rm -f test.fst
exit 0
