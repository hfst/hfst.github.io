#include <stdio.h>

char * hfst_file_to_mem(const char * filename);
