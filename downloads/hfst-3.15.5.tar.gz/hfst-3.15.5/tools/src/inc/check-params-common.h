
    if (!outputNamed)
    {
        outfilename = hfst_strdup("<stdout>");
        outfile = stdout;
        message_out = stderr;
    }

