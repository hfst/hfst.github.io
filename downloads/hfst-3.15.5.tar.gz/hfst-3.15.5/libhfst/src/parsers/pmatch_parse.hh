/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_PMATCH_PMATCH_PARSE_HH_INCLUDED
# define YY_PMATCH_PMATCH_PARSE_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int pmatchdebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_WEIGHTED_EXPRESSION = 258,
    WEIGHT = 259,
    CHARACTER_RANGE = 260,
    CROSS_PRODUCT = 261,
    COMPOSITION = 262,
    LENIENT_COMPOSITION = 263,
    INTERSECTION = 264,
    MERGE_RIGHT_ARROW = 265,
    MERGE_LEFT_ARROW = 266,
    EQUALS = 267,
    CENTER_MARKER = 268,
    MARKUP_MARKER = 269,
    SHUFFLE = 270,
    BEFORE = 271,
    AFTER = 272,
    LEFT_ARROW = 273,
    RIGHT_ARROW = 274,
    LEFT_RIGHT_ARROW = 275,
    LEFT_RESTRICTION = 276,
    REPLACE_RIGHT = 277,
    REPLACE_LEFT = 278,
    OPTIONAL_REPLACE_RIGHT = 279,
    OPTIONAL_REPLACE_LEFT = 280,
    REPLACE_LEFT_RIGHT = 281,
    OPTIONAL_REPLACE_LEFT_RIGHT = 282,
    RTL_LONGEST_MATCH = 283,
    RTL_SHORTEST_MATCH = 284,
    LTR_LONGEST_MATCH = 285,
    LTR_SHORTEST_MATCH = 286,
    REPLACE_CONTEXT_UU = 287,
    REPLACE_CONTEXT_LU = 288,
    REPLACE_CONTEXT_UL = 289,
    REPLACE_CONTEXT_LL = 290,
    UNION = 291,
    MINUS = 292,
    UPPER_MINUS = 293,
    LOWER_MINUS = 294,
    UPPER_PRIORITY_UNION = 295,
    LOWER_PRIORITY_UNION = 296,
    IGNORING = 297,
    IGNORE_INTERNALLY = 298,
    LEFT_QUOTIENT = 299,
    COMMA = 300,
    COMMACOMMA = 301,
    SUBSTITUTE_LEFT = 302,
    TERM_COMPLEMENT = 303,
    COMPLEMENT = 304,
    CONTAINMENT = 305,
    CONTAINMENT_ONCE = 306,
    CONTAINMENT_OPT = 307,
    STAR = 308,
    PLUS = 309,
    REVERSE = 310,
    INVERT = 311,
    UPPER_PROJECT = 312,
    LOWER_PROJECT = 313,
    READ_BIN = 314,
    READ_TEXT = 315,
    READ_SPACED = 316,
    READ_PROLOG = 317,
    READ_RE = 318,
    READ_VEC = 319,
    READ_LEXC = 320,
    CATENATE_N_TO_K = 321,
    CATENATE_N = 322,
    CATENATE_N_PLUS = 323,
    CATENATE_N_MINUS = 324,
    LEFT_BRACKET = 325,
    RIGHT_BRACKET = 326,
    LEFT_PARENTHESIS = 327,
    RIGHT_PARENTHESIS = 328,
    LEFT_BRACKET_DOTTED = 329,
    RIGHT_BRACKET_DOTTED = 330,
    PAIR_SEPARATOR = 331,
    PAIR_SEPARATOR_SOLE = 332,
    PAIR_SEPARATOR_WO_RIGHT = 333,
    PAIR_SEPARATOR_WO_LEFT = 334,
    EPSILON_TOKEN = 335,
    ANY_TOKEN = 336,
    BOUNDARY_MARKER = 337,
    LEXER_ERROR = 338,
    SYMBOL = 339,
    SYMBOL_WITH_LEFT_PAREN = 340,
    QUOTED_LITERAL = 341,
    CURLY_LITERAL = 342,
    ALPHA = 343,
    LOWERALPHA = 344,
    UPPERALPHA = 345,
    NUM = 346,
    PUNCT = 347,
    WHITESPACE = 348,
    VARIABLE_NAME = 349,
    DEFINE = 350,
    SET_VARIABLE = 351,
    LIT_LEFT = 352,
    INS_LEFT = 353,
    REGEX = 354,
    DEFINS = 355,
    DEFINED_LIST = 356,
    CAP_LEFT = 357,
    OPTCAP_LEFT = 358,
    OPT_TOLOWER_LEFT = 359,
    TOLOWER_LEFT = 360,
    OPT_TOUPPER_LEFT = 361,
    TOUPPER_LEFT = 362,
    ANY_CASE_LEFT = 363,
    IMPLODE_LEFT = 364,
    EXPLODE_LEFT = 365,
    DEFINE_LEFT = 366,
    ENDTAG_LEFT = 367,
    CAPTURE_LEFT = 368,
    LIKE_LEFT = 369,
    UNLIKE_LEFT = 370,
    LC_LEFT = 371,
    RC_LEFT = 372,
    NLC_LEFT = 373,
    NRC_LEFT = 374,
    OR_LEFT = 375,
    AND_LEFT = 376,
    WITH_LEFT = 377,
    TAG_LEFT = 378,
    LST_LEFT = 379,
    EXC_LEFT = 380,
    INTERPOLATE_LEFT = 381,
    SIGMA_LEFT = 382,
    COUNTER_LEFT = 383
  };
#endif
/* Tokens.  */
#define END_OF_WEIGHTED_EXPRESSION 258
#define WEIGHT 259
#define CHARACTER_RANGE 260
#define CROSS_PRODUCT 261
#define COMPOSITION 262
#define LENIENT_COMPOSITION 263
#define INTERSECTION 264
#define MERGE_RIGHT_ARROW 265
#define MERGE_LEFT_ARROW 266
#define EQUALS 267
#define CENTER_MARKER 268
#define MARKUP_MARKER 269
#define SHUFFLE 270
#define BEFORE 271
#define AFTER 272
#define LEFT_ARROW 273
#define RIGHT_ARROW 274
#define LEFT_RIGHT_ARROW 275
#define LEFT_RESTRICTION 276
#define REPLACE_RIGHT 277
#define REPLACE_LEFT 278
#define OPTIONAL_REPLACE_RIGHT 279
#define OPTIONAL_REPLACE_LEFT 280
#define REPLACE_LEFT_RIGHT 281
#define OPTIONAL_REPLACE_LEFT_RIGHT 282
#define RTL_LONGEST_MATCH 283
#define RTL_SHORTEST_MATCH 284
#define LTR_LONGEST_MATCH 285
#define LTR_SHORTEST_MATCH 286
#define REPLACE_CONTEXT_UU 287
#define REPLACE_CONTEXT_LU 288
#define REPLACE_CONTEXT_UL 289
#define REPLACE_CONTEXT_LL 290
#define UNION 291
#define MINUS 292
#define UPPER_MINUS 293
#define LOWER_MINUS 294
#define UPPER_PRIORITY_UNION 295
#define LOWER_PRIORITY_UNION 296
#define IGNORING 297
#define IGNORE_INTERNALLY 298
#define LEFT_QUOTIENT 299
#define COMMA 300
#define COMMACOMMA 301
#define SUBSTITUTE_LEFT 302
#define TERM_COMPLEMENT 303
#define COMPLEMENT 304
#define CONTAINMENT 305
#define CONTAINMENT_ONCE 306
#define CONTAINMENT_OPT 307
#define STAR 308
#define PLUS 309
#define REVERSE 310
#define INVERT 311
#define UPPER_PROJECT 312
#define LOWER_PROJECT 313
#define READ_BIN 314
#define READ_TEXT 315
#define READ_SPACED 316
#define READ_PROLOG 317
#define READ_RE 318
#define READ_VEC 319
#define READ_LEXC 320
#define CATENATE_N_TO_K 321
#define CATENATE_N 322
#define CATENATE_N_PLUS 323
#define CATENATE_N_MINUS 324
#define LEFT_BRACKET 325
#define RIGHT_BRACKET 326
#define LEFT_PARENTHESIS 327
#define RIGHT_PARENTHESIS 328
#define LEFT_BRACKET_DOTTED 329
#define RIGHT_BRACKET_DOTTED 330
#define PAIR_SEPARATOR 331
#define PAIR_SEPARATOR_SOLE 332
#define PAIR_SEPARATOR_WO_RIGHT 333
#define PAIR_SEPARATOR_WO_LEFT 334
#define EPSILON_TOKEN 335
#define ANY_TOKEN 336
#define BOUNDARY_MARKER 337
#define LEXER_ERROR 338
#define SYMBOL 339
#define SYMBOL_WITH_LEFT_PAREN 340
#define QUOTED_LITERAL 341
#define CURLY_LITERAL 342
#define ALPHA 343
#define LOWERALPHA 344
#define UPPERALPHA 345
#define NUM 346
#define PUNCT 347
#define WHITESPACE 348
#define VARIABLE_NAME 349
#define DEFINE 350
#define SET_VARIABLE 351
#define LIT_LEFT 352
#define INS_LEFT 353
#define REGEX 354
#define DEFINS 355
#define DEFINED_LIST 356
#define CAP_LEFT 357
#define OPTCAP_LEFT 358
#define OPT_TOLOWER_LEFT 359
#define TOLOWER_LEFT 360
#define OPT_TOUPPER_LEFT 361
#define TOUPPER_LEFT 362
#define ANY_CASE_LEFT 363
#define IMPLODE_LEFT 364
#define EXPLODE_LEFT 365
#define DEFINE_LEFT 366
#define ENDTAG_LEFT 367
#define CAPTURE_LEFT 368
#define LIKE_LEFT 369
#define UNLIKE_LEFT 370
#define LC_LEFT 371
#define RC_LEFT 372
#define NLC_LEFT 373
#define NRC_LEFT 374
#define OR_LEFT 375
#define AND_LEFT 376
#define WITH_LEFT 377
#define TAG_LEFT 378
#define LST_LEFT 379
#define EXC_LEFT 380
#define INTERPOLATE_LEFT 381
#define SIGMA_LEFT 382
#define COUNTER_LEFT 383

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 36 "pmatch_parse.yy" /* yacc.c:1909  */

         int value;
         int* values;
         double weight;
         char* label;
         hfst::pmatch::PmatchObject* pmatchObject;
         std::pair<std::string, hfst::pmatch::PmatchObject*>* pmatchDefinition;
         std::vector<hfst::pmatch::PmatchObject *>* pmatchObject_vector;
         std::vector<std::string>* string_vector;

         hfst::pmatch::PmatchParallelRulesContainer * replaceRules;
         hfst::pmatch::PmatchReplaceRuleContainer * replaceRule;
         hfst::pmatch::PmatchMappingPairsContainer * mappings;
         hfst::pmatch::PmatchContextsContainer * parallelContexts;
         hfst::pmatch::PmatchObjectPair * restrictionContext;
         hfst::pmatch::MappingPairVector * restrictionContexts;
         hfst::xeroxRules::ReplaceType replType;
         hfst::xeroxRules::ReplaceArrow replaceArrow;
     

#line 331 "pmatch_parse.hh" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE pmatchlval;

int pmatchparse (void);

#endif /* !YY_PMATCH_PMATCH_PARSE_HH_INCLUDED  */
