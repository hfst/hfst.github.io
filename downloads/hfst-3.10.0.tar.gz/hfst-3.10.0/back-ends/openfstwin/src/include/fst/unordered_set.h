#ifdef _MSC_VER //Added Paul Dixon
        #include <unordered_set>
        using std::unordered_set;
#else
        #include <tr1/unordered_set>
        using std::tr1::unordered_set;
#endif
