/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     WEIGHT = 258,
     CURLY_BRACKETS = 259,
     SYMBOL = 260,
     MERGE_LEFT_ARROW = 261,
     MERGE_RIGHT_ARROW = 262,
     INTERSECTION = 263,
     LENIENT_COMPOSITION = 264,
     COMPOSITION = 265,
     CROSS_PRODUCT = 266,
     MARKUP_MARKER = 267,
     CENTER_MARKER = 268,
     SHUFFLE = 269,
     LEFT_RIGHT_ARROW = 270,
     RIGHT_ARROW = 271,
     LEFT_ARROW = 272,
     LEFT_RESTRICTION = 273,
     LTR_SHORTEST_MATCH = 274,
     LTR_LONGEST_MATCH = 275,
     RTL_SHORTEST_MATCH = 276,
     RTL_LONGEST_MATCH = 277,
     OPTIONAL_REPLACE_LEFT_RIGHT = 278,
     REPLACE_LEFT_RIGHT = 279,
     OPTIONAL_REPLACE_LEFT = 280,
     OPTIONAL_REPLACE_RIGHT = 281,
     REPLACE_LEFT = 282,
     REPLACE_RIGHT = 283,
     REPLACE_CONTEXT_LL = 284,
     REPLACE_CONTEXT_UL = 285,
     REPLACE_CONTEXT_LU = 286,
     REPLACE_CONTEXT_UU = 287,
     LOWER_PRIORITY_UNION = 288,
     UPPER_PRIORITY_UNION = 289,
     LOWER_MINUS = 290,
     UPPER_MINUS = 291,
     MINUS = 292,
     UNION = 293,
     LEFT_QUOTIENT = 294,
     IGNORE_INTERNALLY = 295,
     IGNORING = 296,
     COMMACOMMA = 297,
     COMMA = 298,
     AFTER = 299,
     BEFORE = 300,
     TERM_COMPLEMENT = 301,
     SUBSTITUTE_LEFT = 302,
     CONTAINMENT_OPT = 303,
     CONTAINMENT_ONCE = 304,
     CONTAINMENT = 305,
     COMPLEMENT = 306,
     PLUS = 307,
     STAR = 308,
     XRE_LOWER = 309,
     XRE_UPPER = 310,
     INVERT = 311,
     REVERSE = 312,
     CATENATE_N_TO_K = 313,
     CATENATE_N_MINUS = 314,
     CATENATE_N_PLUS = 315,
     CATENATE_N = 316,
     READ_RE = 317,
     READ_PROLOG = 318,
     READ_SPACED = 319,
     READ_TEXT = 320,
     READ_BIN = 321,
     FUNCTION_NAME = 322,
     LEFT_BRACKET = 323,
     RIGHT_BRACKET = 324,
     LEFT_PARENTHESIS = 325,
     RIGHT_PARENTHESIS = 326,
     LEFT_BRACKET_DOTTED = 327,
     RIGHT_BRACKET_DOTTED = 328,
     SUBVAL = 329,
     EPSILON_TOKEN = 330,
     ANY_TOKEN = 331,
     BOUNDARY_MARKER = 332,
     LEXER_ERROR = 333,
     END_OF_EXPRESSION = 334,
     PAIR_SEPARATOR = 335,
     QUOTED_LITERAL = 336
   };
#endif
/* Tokens.  */
#define WEIGHT 258
#define CURLY_BRACKETS 259
#define SYMBOL 260
#define MERGE_LEFT_ARROW 261
#define MERGE_RIGHT_ARROW 262
#define INTERSECTION 263
#define LENIENT_COMPOSITION 264
#define COMPOSITION 265
#define CROSS_PRODUCT 266
#define MARKUP_MARKER 267
#define CENTER_MARKER 268
#define SHUFFLE 269
#define LEFT_RIGHT_ARROW 270
#define RIGHT_ARROW 271
#define LEFT_ARROW 272
#define LEFT_RESTRICTION 273
#define LTR_SHORTEST_MATCH 274
#define LTR_LONGEST_MATCH 275
#define RTL_SHORTEST_MATCH 276
#define RTL_LONGEST_MATCH 277
#define OPTIONAL_REPLACE_LEFT_RIGHT 278
#define REPLACE_LEFT_RIGHT 279
#define OPTIONAL_REPLACE_LEFT 280
#define OPTIONAL_REPLACE_RIGHT 281
#define REPLACE_LEFT 282
#define REPLACE_RIGHT 283
#define REPLACE_CONTEXT_LL 284
#define REPLACE_CONTEXT_UL 285
#define REPLACE_CONTEXT_LU 286
#define REPLACE_CONTEXT_UU 287
#define LOWER_PRIORITY_UNION 288
#define UPPER_PRIORITY_UNION 289
#define LOWER_MINUS 290
#define UPPER_MINUS 291
#define MINUS 292
#define UNION 293
#define LEFT_QUOTIENT 294
#define IGNORE_INTERNALLY 295
#define IGNORING 296
#define COMMACOMMA 297
#define COMMA 298
#define AFTER 299
#define BEFORE 300
#define TERM_COMPLEMENT 301
#define SUBSTITUTE_LEFT 302
#define CONTAINMENT_OPT 303
#define CONTAINMENT_ONCE 304
#define CONTAINMENT 305
#define COMPLEMENT 306
#define PLUS 307
#define STAR 308
#define XRE_LOWER 309
#define XRE_UPPER 310
#define INVERT 311
#define REVERSE 312
#define CATENATE_N_TO_K 313
#define CATENATE_N_MINUS 314
#define CATENATE_N_PLUS 315
#define CATENATE_N 316
#define READ_RE 317
#define READ_PROLOG 318
#define READ_SPACED 319
#define READ_TEXT 320
#define READ_BIN 321
#define FUNCTION_NAME 322
#define LEFT_BRACKET 323
#define RIGHT_BRACKET 324
#define LEFT_PARENTHESIS 325
#define RIGHT_PARENTHESIS 326
#define LEFT_BRACKET_DOTTED 327
#define RIGHT_BRACKET_DOTTED 328
#define SUBVAL 329
#define EPSILON_TOKEN 330
#define ANY_TOKEN 331
#define BOUNDARY_MARKER 332
#define LEXER_ERROR 333
#define END_OF_EXPRESSION 334
#define PAIR_SEPARATOR 335
#define QUOTED_LITERAL 336




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 2068 of yacc.c  */
#line 82 "xre_parse.yy"


    int value;
    int* values;
    double weight;
    char* label;
    
    char *subval1, *subval2;
    
    hfst::HfstTransducer* transducer;
    hfst::HfstTransducerPair* transducerPair;
    hfst::HfstTransducerPairVector* transducerPairVector;
    hfst::HfstTransducerVector* transducerVector;

   std::pair<hfst::xeroxRules::ReplaceArrow, std::vector<hfst::xeroxRules::Rule> >* replaceRuleVectorWithArrow;
   std::pair< hfst::xeroxRules::ReplaceArrow, hfst::xeroxRules::Rule>* replaceRuleWithArrow;   
   std::pair< hfst::xeroxRules::ReplaceArrow, hfst::HfstTransducerPairVector>* mappingVectorWithArrow;
   std::pair< hfst::xeroxRules::ReplaceArrow, hfst::HfstTransducerPair>* mappingWithArrow;
       
   std::pair<hfst::xeroxRules::ReplaceType, hfst::HfstTransducerPairVector>* contextWithMark;
   
   hfst::xeroxRules::ReplaceType replType;
   hfst::xeroxRules::ReplaceArrow replaceArrow; 




/* Line 2068 of yacc.c  */
#line 240 "xre_parse.hh"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif




