
This package contains Python bindings for HFST library for Windows.

HFST version number is 3.11.0.

The bindings should work with 64-bit Python versions 3.3 and 3.4.

For more information about the API, see https://hfst.github.io/python/index.html.

The files 'libhfst.py' and '_libhfst.pyd' as well as folder 'hfst' should be
installed under folder 'site-packages' of the version of Python you are using,
e.g. 'C:\Python33\Lib\site-packages'. Alternatively, you can use python in the
directory where you have these files or add the path to sys.path.
