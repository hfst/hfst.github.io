#!/bin/sh
TOOLDIR=../../tools/src
TOOL1=
TOOL2=

if [ "$1" = '--python' ]; then
    TOOL1="python3 ./hfst-strings2fst.py"
    TOOL2="python3 ./hfst-fst2strings.py"
else
    TOOL1=$1hfst-strings2fst
    TOOL2=$1hfst-fst2strings
    if ! which $TOOL1 2>1 > /dev/null; then
	exit 0;
    fi
    if ! which $TOOL2 2>1 > /dev/null; then
	exit 0;
    fi
fi

if ! $TOOL1 ./utf-8.strings > test ; then
    exit 1
fi
if ! $TOOL2 < test > test.strings ; then
    exit 1
fi
rm test test.strings
