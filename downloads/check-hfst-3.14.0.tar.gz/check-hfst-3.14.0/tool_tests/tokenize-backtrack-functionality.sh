#!/bin/sh

if [ "$1" = "--python" ]; then
    exit 77
fi

TOOLDIR=../../tools/src

if [ "$srcdir" = "" ]; then
    srcdir="./";
fi

# Prerequisites:
if ! $1hfst-lexc -q < ./tokenize-backtrack.lexc > ./tokenize-backtrack-gen.hfst; then
    echo punct backtrack gen fail
    exit 1
fi
if ! $1hfst-invert < ./tokenize-backtrack-gen.hfst > ./tokenize-backtrack.hfst; then
    echo invert backtrack fail
    exit 1
fi
if ! $1hfst-pmatch2fst < ./tokenize-backtrack.pmscript > ./tokenize-backtrack.pmhfst; then
    echo pmatch2fst backtrack fail
    exit 1
fi

# Only --giella-cg supports this:
if ! echo "busse skuvla skuvla busse Jan." | $1hfst-tokenize --giella-cg ./tokenize-backtrack.pmhfst > test.strings ; then
    echo tokenize --giella-cg fail:
    cat test.strings
    exit 1
fi
if ! diff test.strings ./tokenize-backtrack-out-giella-cg.strings ; then
    echo diff test.strings ./tokenize-backtrack-out-giella-cg.strings
    exit 1
fi

if ! echo "su. su" | $1hfst-tokenize --giella-cg ./tokenize-backtrack.pmhfst > test.strings ; then
    echo tokenize --giella-cg contiguous fail:
    cat test.strings
    exit 1
fi
if ! diff test.strings ./tokenize-backtrack-out-giella-cg-contiguous.strings ; then
    echo diff test.strings ./tokenize-backtrack-out-giella-cg-contiguous.strings
    exit 1
fi

if ! echo "njeallje   logi guokte" | $1hfst-tokenize --giella-cg ./tokenize-backtrack.pmhfst > test.strings ; then
    echo tokenize --giella-cg contiguous fail:
    cat test.strings
    exit 1
fi
if ! diff test.strings ./tokenize-backtrack-out-giella-cg-spaces.strings ; then
    echo diff test.strings ./tokenize-backtrack-out-giella-cg-spaces.strings
    exit 1
fi


rm test.strings tokenize-backtrack.pmhfst tokenize-backtrack.hfst tokenize-backtrack-gen.hfst
exit 0
