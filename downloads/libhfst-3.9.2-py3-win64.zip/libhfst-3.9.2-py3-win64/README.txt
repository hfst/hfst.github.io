
This package contains Python bindings for HFST library for 64-bit Windows.

HFST version number is 3.9.2.

The bindings should work with versions 3.3 and 3.4 of 64-bit Python.

For more information about the API, see: https://hfst.github.io/python/index.html
