#!/bin/sh
TOOLDIR=../../tools/src
for i in "" .sfst .ofst .foma; do
if ((test -z "$i") || $1hfst-format --list-formats | grep $i > /dev/null); then
    if test -f cat$i ; then
        if ! $1hfst-summarize cat$i > test.txt ; then
            exit 1
        fi
        rm test.txt;
    fi
fi
done
