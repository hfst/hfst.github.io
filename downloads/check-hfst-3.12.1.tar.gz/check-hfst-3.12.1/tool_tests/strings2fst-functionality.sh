#!/bin/sh
TOOLDIR=../../tools/src

if [ "$srcdir" = "" ]; then
    srcdir="./";
fi

for i in "" .sfst .ofst .foma; do
if ((test -z "$i") || $1hfst-format --list-formats | grep $i > /dev/null); then
    FFLAG=
    case $i in
        .sfst)
            FFLAG="-f sfst";;
        .ofst)
            FFLAG="-f openfst-tropical";;
        .foma)
            FFLAG="-f foma";;
        *)
            FFLAG=;;
    esac
    if test -f cat$i ; then
        if ! $1hfst-strings2fst $FFLAG ./cat.strings > test ; then
            exit 1
        fi
        if ! $1hfst-compare -s test cat$i ; then
            exit 1
        fi
        rm test
        if ! $1hfst-strings2fst $FFLAG -S ./c_a_t.strings > test ; then
            exit 1
        fi
        if ! $1hfst-compare -s test cat$i ; then
            exit 1
        fi
        rm test
    fi
    if test -f heavycat$i ; then
        if ! $1hfst-strings2fst $FFLAG ./heavycat.strings > test ; then
            exit 1
        fi
        if ! $1hfst-compare -s test heavycat$i ; then
            exit 1
        fi
        rm test
    fi
    if test -f cat2dog$i ; then
        if ! $1hfst-strings2fst $FFLAG ./cat2dog.strings > test ; then
            exit 1
        fi
        if ! $1hfst-compare -s test cat2dog$i > /dev/null 1>&1 ; then
            exit 1
        fi
        if ! $1hfst-strings2fst $FFLAG -S ./cat2dog.spaces > test ; then
            exit 1
        fi
        if ! $1hfst-compare -s test cat2dog$i > /dev/null 1>&1 ; then
            exit 1
        fi
        if ! $1hfst-strings2fst $FFLAG -p -S ./cat2dog.pairs > test ; then
            exit 1
        fi
        if ! $1hfst-compare -s test cat2dog$i > /dev/null 1>&1 ; then
            exit 1
        fi
        if ! $1hfst-strings2fst $FFLAG -p ./cat2dog.pairstring > test ; then
            exit 1
        fi
        if ! $1hfst-compare -s test cat2dog$i > /dev/null 1>&1 ; then
            exit 1
        fi
        if ! $1hfst-strings2fst $FFLAG ./dos.strings > test.hfst ; then
            exit 1
        fi
        if ! $1hfst-compare -s test.hfst cat$i ; then
            exit 1
        fi
        rm test.hfst
    fi
fi
done

