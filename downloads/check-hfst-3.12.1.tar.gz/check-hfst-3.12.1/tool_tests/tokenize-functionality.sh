#!/bin/sh

TOOLDIR=../../tools/src

if [ "$srcdir" = "" ]; then
    srcdir="./";
fi

# Prerequisites
if ! $1hfst-lexc -q < ./tokenize-dog-in.lexc > ./tokenize-dog-gen.hfst; then
    echo lexc dog fail
    exit 1
fi
if ! $1hfst-invert < ./tokenize-dog-gen.hfst > ./tokenize-dog.hfst; then
    echo invert dog fail
    exit 1
fi
if ! $1hfst-pmatch2fst < ./tokenize-dog.pmscript > ./tokenize-dog.pmhfst; then
    echo pmatch2fst tokenize-dog fail
    exit 1
fi

# basic lookup
if ! echo "test dog be dog catdog" | $1hfst-tokenize ./tokenize-dog.pmhfst > test.strings ; then
    echo tokenize fail:
    cat test.strings
    exit 1
fi
if ! diff test.strings ./tokenize-dog-out.strings ; then
    echo diff test.strings ./tokenize-dog-out.strings
    exit 1
fi

# --cg
if ! echo "test dog be dog catdog" | $1hfst-tokenize --cg ./tokenize-dog.pmhfst > test.strings ; then
    echo tokenize --cg fail:
    cat test.strings
    exit 1
fi
if ! diff test.strings ./tokenize-dog-out-cg.strings ; then
    echo diff test.strings ./tokenize-dog-out-cg.strings 
    exit 1
fi

# --giella-cg
if ! echo "test dog be dog catdog собака" | $1hfst-tokenize --giella-cg ./tokenize-dog.pmhfst > test.strings ; then
    echo tokenize --giella-cg fail:
    cat test.strings
    exit 1
fi
if ! diff test.strings ./tokenize-dog-out-giella-cg.strings ; then
    echo diff test.strings ./tokenize-dog-out-giella-cg.strings 
    exit 1
fi

# --xerox
if ! echo "test dog be dog catdog" | $1hfst-tokenize --xerox ./tokenize-dog.pmhfst > test.strings ; then
    echo tokenize --xerox fail:
    cat test.strings
    exit 1
fi
if ! diff test.strings ./tokenize-dog-out-xerox.strings ; then
    echo diff test.strings ./tokenize-dog-out-xerox.strings 
    exit 1
fi


# --giella-cg superblanks
if ! printf 'dog[\\\n<\\\\>]cat !and \ndogs[][\n]' | $1hfst-tokenize --giella-cg ./tokenize-dog.pmhfst > test.strings ; then
    echo tokenize --giella-cg superblank fail:
    cat test.strings
    exit 1
fi
if ! diff test.strings ./tokenize-dog-out-giella-cg-superblank.strings ; then
    echo diff test.strings ./tokenize-dog-out-giella-cg-superblank.strings 
    exit 1
fi

rm test.strings tokenize-dog.pmhfst tokenize-dog.hfst tokenize-dog-gen.hfst
exit 0
