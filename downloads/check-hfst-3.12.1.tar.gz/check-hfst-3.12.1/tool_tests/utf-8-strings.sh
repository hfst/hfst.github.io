#!/bin/sh
TOOLDIR=../../tools/src
if ! $1hfst-strings2fst ./utf-8.strings > test ; then
    exit 1
fi
if ! $1hfst-fst2strings < test > test.strings ; then
    exit 1
fi
rm test test.strings
