/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison implementation for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.5"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse         pmatchparse
#define yylex           pmatchlex
#define yyerror         pmatcherror
#define yylval          pmatchlval
#define yychar          pmatchchar
#define yydebug         pmatchdebug
#define yynerrs         pmatchnerrs


/* Copy the first part of user declarations.  */

/* Line 268 of yacc.c  */
#line 1 "pmatch_parse.yy"

// Copyright (c) 2016 University of Helsinki                          
//                                                                    
// This library is free software; you can redistribute it and/or      
// modify it under the terms of the GNU Lesser General Public         
// License as published by the Free Software Foundation; either       
// version 3 of the License, or (at your option) any later version.
// See the file COPYING included with this distribution for more      
// information.

#define YYDEBUG 0

#include <stdio.h>
#include <assert.h>
#include <iostream>
#include <sstream>
    
#include "HfstTransducer.h"
#include "HfstInputStream.h"
#include "HfstXeroxRules.h"
    
#include "pmatch_utils.h"
    using namespace hfst;
    using namespace hfst::pmatch;
    using namespace hfst::xeroxRules;

    extern int pmatcherror(const char * text);
    extern int pmatchlex();
    extern int pmatchlineno;

    

/* Line 268 of yacc.c  */
#line 112 "pmatch_parse.cc"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 1
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     WEIGHT = 258,
     END_OF_WEIGHTED_EXPRESSION = 259,
     CHARACTER_RANGE = 260,
     MERGE_LEFT_ARROW = 261,
     MERGE_RIGHT_ARROW = 262,
     INTERSECTION = 263,
     LENIENT_COMPOSITION = 264,
     COMPOSITION = 265,
     CROSS_PRODUCT = 266,
     MARKUP_MARKER = 267,
     CENTER_MARKER = 268,
     AFTER = 269,
     BEFORE = 270,
     SHUFFLE = 271,
     LEFT_RESTRICTION = 272,
     LEFT_RIGHT_ARROW = 273,
     RIGHT_ARROW = 274,
     LEFT_ARROW = 275,
     LTR_SHORTEST_MATCH = 276,
     LTR_LONGEST_MATCH = 277,
     RTL_SHORTEST_MATCH = 278,
     RTL_LONGEST_MATCH = 279,
     OPTIONAL_REPLACE_LEFT_RIGHT = 280,
     REPLACE_LEFT_RIGHT = 281,
     OPTIONAL_REPLACE_LEFT = 282,
     OPTIONAL_REPLACE_RIGHT = 283,
     REPLACE_LEFT = 284,
     REPLACE_RIGHT = 285,
     REPLACE_CONTEXT_LL = 286,
     REPLACE_CONTEXT_UL = 287,
     REPLACE_CONTEXT_LU = 288,
     REPLACE_CONTEXT_UU = 289,
     LOWER_PRIORITY_UNION = 290,
     UPPER_PRIORITY_UNION = 291,
     LOWER_MINUS = 292,
     UPPER_MINUS = 293,
     MINUS = 294,
     UNION = 295,
     LEFT_QUOTIENT = 296,
     IGNORE_INTERNALLY = 297,
     IGNORING = 298,
     COMMACOMMA = 299,
     COMMA = 300,
     CONTAINMENT_OPT = 301,
     CONTAINMENT_ONCE = 302,
     CONTAINMENT = 303,
     COMPLEMENT = 304,
     TERM_COMPLEMENT = 305,
     SUBSTITUTE_LEFT = 306,
     LOWER_PROJECT = 307,
     UPPER_PROJECT = 308,
     INVERT = 309,
     REVERSE = 310,
     PLUS = 311,
     STAR = 312,
     READ_LEXC = 313,
     READ_RE = 314,
     READ_PROLOG = 315,
     READ_SPACED = 316,
     READ_TEXT = 317,
     READ_BIN = 318,
     CATENATE_N_TO_K = 319,
     CATENATE_N_MINUS = 320,
     CATENATE_N_PLUS = 321,
     CATENATE_N = 322,
     LEFT_BRACKET = 323,
     RIGHT_BRACKET = 324,
     LEFT_PARENTHESIS = 325,
     RIGHT_PARENTHESIS = 326,
     LEFT_BRACKET_DOTTED = 327,
     RIGHT_BRACKET_DOTTED = 328,
     PAIR_SEPARATOR = 329,
     PAIR_SEPARATOR_SOLE = 330,
     PAIR_SEPARATOR_WO_RIGHT = 331,
     PAIR_SEPARATOR_WO_LEFT = 332,
     EPSILON_TOKEN = 333,
     ANY_TOKEN = 334,
     BOUNDARY_MARKER = 335,
     LEXER_ERROR = 336,
     SYMBOL = 337,
     SYMBOL_WITH_LEFT_PAREN = 338,
     QUOTED_LITERAL = 339,
     CURLY_LITERAL = 340,
     ALPHA = 341,
     LOWERALPHA = 342,
     UPPERALPHA = 343,
     NUM = 344,
     PUNCT = 345,
     WHITESPACE = 346,
     COUNTER_LEFT = 347,
     SIGMA_LEFT = 348,
     INTERPOLATE_LEFT = 349,
     EXC_LEFT = 350,
     LST_LEFT = 351,
     TAG_LEFT = 352,
     AND_LEFT = 353,
     OR_LEFT = 354,
     NRC_LEFT = 355,
     NLC_LEFT = 356,
     RC_LEFT = 357,
     LC_LEFT = 358,
     ENDTAG_LEFT = 359,
     DEFINE_LEFT = 360,
     TOUPPER_LEFT = 361,
     TOLOWER_LEFT = 362,
     OPTCAP_LEFT = 363,
     DEFINED_LIST = 364,
     DEFINS = 365,
     REGEX = 366,
     INS_LEFT = 367,
     LIT_LEFT = 368,
     DEFINE = 369
   };
#endif
/* Tokens.  */
#define WEIGHT 258
#define END_OF_WEIGHTED_EXPRESSION 259
#define CHARACTER_RANGE 260
#define MERGE_LEFT_ARROW 261
#define MERGE_RIGHT_ARROW 262
#define INTERSECTION 263
#define LENIENT_COMPOSITION 264
#define COMPOSITION 265
#define CROSS_PRODUCT 266
#define MARKUP_MARKER 267
#define CENTER_MARKER 268
#define AFTER 269
#define BEFORE 270
#define SHUFFLE 271
#define LEFT_RESTRICTION 272
#define LEFT_RIGHT_ARROW 273
#define RIGHT_ARROW 274
#define LEFT_ARROW 275
#define LTR_SHORTEST_MATCH 276
#define LTR_LONGEST_MATCH 277
#define RTL_SHORTEST_MATCH 278
#define RTL_LONGEST_MATCH 279
#define OPTIONAL_REPLACE_LEFT_RIGHT 280
#define REPLACE_LEFT_RIGHT 281
#define OPTIONAL_REPLACE_LEFT 282
#define OPTIONAL_REPLACE_RIGHT 283
#define REPLACE_LEFT 284
#define REPLACE_RIGHT 285
#define REPLACE_CONTEXT_LL 286
#define REPLACE_CONTEXT_UL 287
#define REPLACE_CONTEXT_LU 288
#define REPLACE_CONTEXT_UU 289
#define LOWER_PRIORITY_UNION 290
#define UPPER_PRIORITY_UNION 291
#define LOWER_MINUS 292
#define UPPER_MINUS 293
#define MINUS 294
#define UNION 295
#define LEFT_QUOTIENT 296
#define IGNORE_INTERNALLY 297
#define IGNORING 298
#define COMMACOMMA 299
#define COMMA 300
#define CONTAINMENT_OPT 301
#define CONTAINMENT_ONCE 302
#define CONTAINMENT 303
#define COMPLEMENT 304
#define TERM_COMPLEMENT 305
#define SUBSTITUTE_LEFT 306
#define LOWER_PROJECT 307
#define UPPER_PROJECT 308
#define INVERT 309
#define REVERSE 310
#define PLUS 311
#define STAR 312
#define READ_LEXC 313
#define READ_RE 314
#define READ_PROLOG 315
#define READ_SPACED 316
#define READ_TEXT 317
#define READ_BIN 318
#define CATENATE_N_TO_K 319
#define CATENATE_N_MINUS 320
#define CATENATE_N_PLUS 321
#define CATENATE_N 322
#define LEFT_BRACKET 323
#define RIGHT_BRACKET 324
#define LEFT_PARENTHESIS 325
#define RIGHT_PARENTHESIS 326
#define LEFT_BRACKET_DOTTED 327
#define RIGHT_BRACKET_DOTTED 328
#define PAIR_SEPARATOR 329
#define PAIR_SEPARATOR_SOLE 330
#define PAIR_SEPARATOR_WO_RIGHT 331
#define PAIR_SEPARATOR_WO_LEFT 332
#define EPSILON_TOKEN 333
#define ANY_TOKEN 334
#define BOUNDARY_MARKER 335
#define LEXER_ERROR 336
#define SYMBOL 337
#define SYMBOL_WITH_LEFT_PAREN 338
#define QUOTED_LITERAL 339
#define CURLY_LITERAL 340
#define ALPHA 341
#define LOWERALPHA 342
#define UPPERALPHA 343
#define NUM 344
#define PUNCT 345
#define WHITESPACE 346
#define COUNTER_LEFT 347
#define SIGMA_LEFT 348
#define INTERPOLATE_LEFT 349
#define EXC_LEFT 350
#define LST_LEFT 351
#define TAG_LEFT 352
#define AND_LEFT 353
#define OR_LEFT 354
#define NRC_LEFT 355
#define NLC_LEFT 356
#define RC_LEFT 357
#define LC_LEFT 358
#define ENDTAG_LEFT 359
#define DEFINE_LEFT 360
#define TOUPPER_LEFT 361
#define TOLOWER_LEFT 362
#define OPTCAP_LEFT 363
#define DEFINED_LIST 364
#define DEFINS 365
#define REGEX 366
#define INS_LEFT 367
#define LIT_LEFT 368
#define DEFINE 369




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 293 of yacc.c  */
#line 36 "pmatch_parse.yy"

         int value;
         int* values;
         double weight;
         char* label;
         hfst::pmatch::PmatchObject* pmatchObject;
         std::pair<std::string, hfst::pmatch::PmatchObject*>* pmatchDefinition;
         std::vector<hfst::pmatch::PmatchObject *>* pmatchObject_vector;
         std::vector<std::string>* string_vector;

         hfst::pmatch::PmatchParallelRulesContainer * replaceRules;
         hfst::pmatch::PmatchReplaceRuleContainer * replaceRule;
         hfst::pmatch::PmatchMappingPairsContainer * mappings;
         hfst::pmatch::PmatchContextsContainer * parallelContexts;
         hfst::pmatch::PmatchObjectPair * restrictionContext;
         hfst::pmatch::MappingPairVector * restrictionContexts;
         hfst::xeroxRules::ReplaceType replType;
         hfst::xeroxRules::ReplaceArrow replaceArrow; 
     


/* Line 293 of yacc.c  */
#line 398 "pmatch_parse.cc"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif


/* Copy the second part of user declarations.  */


/* Line 343 of yacc.c  */
#line 410 "pmatch_parse.cc"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  2
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1140

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  115
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  42
/* YYNRULES -- Number of rules.  */
#define YYNRULES  166
/* YYNRULES -- Number of states.  */
#define YYNSTATES  282

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   369

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     4,     7,    11,    15,    18,    24,    28,
      32,    34,    35,    38,    40,    44,    48,    52,    56,    60,
      69,    72,    75,    77,    79,    81,    85,    87,    89,    92,
      96,    98,   102,   108,   113,   118,   123,   129,   134,   140,
     143,   145,   149,   153,   156,   159,   161,   163,   165,   167,
     169,   171,   173,   175,   177,   179,   181,   183,   185,   187,
     191,   195,   199,   201,   205,   211,   217,   219,   223,   227,
     230,   233,   235,   237,   241,   245,   249,   253,   257,   261,
     265,   267,   270,   272,   276,   280,   284,   286,   289,   292,
     295,   298,   300,   303,   306,   309,   312,   315,   318,   321,
     324,   327,   330,   332,   335,   337,   341,   345,   349,   352,
     359,   366,   368,   370,   372,   376,   378,   380,   382,   384,
     386,   388,   390,   392,   394,   396,   400,   404,   408,   412,
     414,   416,   420,   424,   428,   432,   436,   438,   440,   442,
     446,   450,   452,   453,   457,   461,   465,   467,   469,   471,
     473,   475,   477,   479,   481,   483,   485,   487,   489,   491,
     495,   499,   501,   505,   509,   513,   517
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     116,     0,    -1,    -1,   116,   117,    -1,   114,    82,   119,
      -1,   110,    82,   119,    -1,   111,   119,    -1,   114,    83,
     118,    71,   119,    -1,   109,    82,   119,    -1,    82,    45,
     118,    -1,    82,    -1,    -1,   120,     4,    -1,   121,    -1,
     120,    10,   121,    -1,   120,    11,   121,    -1,   120,     9,
     121,    -1,   120,     7,   121,    -1,   120,     6,   121,    -1,
      51,    68,   121,    45,   121,    45,   121,    69,    -1,   120,
      76,    -1,    77,   120,    -1,    75,    -1,   131,    -1,   122,
      -1,   122,    44,   123,    -1,   123,    -1,   124,    -1,   124,
     126,    -1,   124,    45,   125,    -1,   125,    -1,   121,   130,
     121,    -1,   121,   130,   121,    12,   121,    -1,   121,   130,
     121,    12,    -1,   121,   130,    12,   121,    -1,    72,    73,
     130,   121,    -1,    72,   121,    73,   130,   121,    -1,   121,
     130,    72,    73,    -1,   121,   130,    72,   121,    73,    -1,
     129,   127,    -1,   128,    -1,   127,    45,   128,    -1,   121,
      13,   121,    -1,   121,    13,    -1,    13,   121,    -1,    13,
      -1,    34,    -1,    33,    -1,    32,    -1,    31,    -1,    30,
      -1,    28,    -1,    24,    -1,    23,    -1,    22,    -1,    21,
      -1,    29,    -1,    27,    -1,   132,    -1,   131,    16,   132,
      -1,   131,    15,   132,    -1,   131,    14,   132,    -1,   135,
      -1,   135,    19,   133,    -1,   135,    20,   135,    13,   135,
      -1,   135,    18,   135,    13,   135,    -1,   134,    -1,   133,
      45,   134,    -1,   135,    13,   135,    -1,   135,    13,    -1,
      13,   135,    -1,    13,    -1,   136,    -1,   135,    40,   136,
      -1,   135,     8,   136,    -1,   135,    39,   136,    -1,   135,
      38,   136,    -1,   135,    37,   136,    -1,   135,    36,   136,
      -1,   135,    35,   136,    -1,   137,    -1,   136,   136,    -1,
     138,    -1,   137,    43,   138,    -1,   137,    42,   138,    -1,
     137,    41,   138,    -1,   139,    -1,    49,   139,    -1,    48,
     139,    -1,    47,   139,    -1,    46,   139,    -1,   140,    -1,
     140,    57,    -1,   140,    56,    -1,   140,    55,    -1,   140,
      54,    -1,   140,    53,    -1,   140,    52,    -1,   140,    67,
      -1,   140,    66,    -1,   140,    65,    -1,   140,    64,    -1,
     141,    -1,    50,   141,    -1,   142,    -1,    68,   120,    69,
      -1,   141,    74,   142,    -1,    70,   120,    71,    -1,   141,
       3,    -1,    68,   120,    69,    97,    82,    71,    -1,    68,
     120,    69,    97,    84,    71,    -1,    84,    -1,    78,    -1,
      80,    -1,   113,    82,    71,    -1,    85,    -1,    79,    -1,
     143,    -1,   145,    -1,    86,    -1,    87,    -1,    88,    -1,
      89,    -1,    90,    -1,    91,    -1,   108,   120,    71,    -1,
     107,   120,    71,    -1,   106,   120,    71,    -1,   105,   120,
      71,    -1,   147,    -1,     5,    -1,    96,   120,    71,    -1,
      95,   120,    71,    -1,    94,   144,    71,    -1,    93,   120,
      71,    -1,    92,    82,    71,    -1,   146,    -1,   148,    -1,
      82,    -1,    83,   144,    71,    -1,   120,    45,   144,    -1,
     120,    -1,    -1,   112,    82,    71,    -1,   104,    82,    71,
      -1,   104,    84,    71,    -1,    63,    -1,    62,    -1,    61,
      -1,    60,    -1,    58,    -1,    59,    -1,   149,    -1,   150,
      -1,   151,    -1,   153,    -1,   154,    -1,   155,    -1,   156,
      -1,    99,   152,    71,    -1,    98,   152,    71,    -1,   149,
      -1,   149,    45,   152,    -1,   102,   120,    71,    -1,   100,
     120,    71,    -1,   103,   120,    71,    -1,   101,   120,    71,
      -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   108,   108,   109,   127,   132,   139,   143,   154,   161,
     162,   163,   165,   175,   176,   177,   178,   179,   180,   181,
     184,   186,   188,   192,   193,   195,   202,   206,   208,   212,
     219,   221,   224,   227,   232,   235,   237,   239,   241,   245,
     249,   252,   258,   259,   260,   261,   265,   266,   267,   268,
     271,   272,   273,   274,   275,   276,   277,   278,   281,   282,
     283,   284,   286,   287,   288,   289,   291,   296,   303,   304,
     305,   306,   308,   309,   310,   311,   312,   313,   314,   315,
     317,   318,   320,   321,   322,   323,   325,   326,   327,   328,
     329,   331,   332,   333,   334,   335,   336,   337,   338,   342,
     346,   350,   357,   358,   360,   361,   362,   363,   364,   365,
     370,   377,   378,   379,   380,   381,   386,   387,   389,   390,
     391,   392,   393,   394,   395,   396,   397,   398,   399,   400,
     401,   402,   403,   404,   405,   406,   407,   408,   409,   419,
     436,   438,   439,   441,   460,   463,   468,   486,   489,   509,
     529,   532,   551,   552,   553,   556,   557,   558,   559,   561,
     579,   595,   598,   603,   609,   619,   627
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "WEIGHT", "END_OF_WEIGHTED_EXPRESSION",
  "CHARACTER_RANGE", "MERGE_LEFT_ARROW", "MERGE_RIGHT_ARROW",
  "INTERSECTION", "LENIENT_COMPOSITION", "COMPOSITION", "CROSS_PRODUCT",
  "MARKUP_MARKER", "CENTER_MARKER", "AFTER", "BEFORE", "SHUFFLE",
  "LEFT_RESTRICTION", "LEFT_RIGHT_ARROW", "RIGHT_ARROW", "LEFT_ARROW",
  "LTR_SHORTEST_MATCH", "LTR_LONGEST_MATCH", "RTL_SHORTEST_MATCH",
  "RTL_LONGEST_MATCH", "OPTIONAL_REPLACE_LEFT_RIGHT", "REPLACE_LEFT_RIGHT",
  "OPTIONAL_REPLACE_LEFT", "OPTIONAL_REPLACE_RIGHT", "REPLACE_LEFT",
  "REPLACE_RIGHT", "REPLACE_CONTEXT_LL", "REPLACE_CONTEXT_UL",
  "REPLACE_CONTEXT_LU", "REPLACE_CONTEXT_UU", "LOWER_PRIORITY_UNION",
  "UPPER_PRIORITY_UNION", "LOWER_MINUS", "UPPER_MINUS", "MINUS", "UNION",
  "LEFT_QUOTIENT", "IGNORE_INTERNALLY", "IGNORING", "COMMACOMMA", "COMMA",
  "CONTAINMENT_OPT", "CONTAINMENT_ONCE", "CONTAINMENT", "COMPLEMENT",
  "TERM_COMPLEMENT", "SUBSTITUTE_LEFT", "LOWER_PROJECT", "UPPER_PROJECT",
  "INVERT", "REVERSE", "PLUS", "STAR", "READ_LEXC", "READ_RE",
  "READ_PROLOG", "READ_SPACED", "READ_TEXT", "READ_BIN", "CATENATE_N_TO_K",
  "CATENATE_N_MINUS", "CATENATE_N_PLUS", "CATENATE_N", "LEFT_BRACKET",
  "RIGHT_BRACKET", "LEFT_PARENTHESIS", "RIGHT_PARENTHESIS",
  "LEFT_BRACKET_DOTTED", "RIGHT_BRACKET_DOTTED", "PAIR_SEPARATOR",
  "PAIR_SEPARATOR_SOLE", "PAIR_SEPARATOR_WO_RIGHT",
  "PAIR_SEPARATOR_WO_LEFT", "EPSILON_TOKEN", "ANY_TOKEN",
  "BOUNDARY_MARKER", "LEXER_ERROR", "SYMBOL", "SYMBOL_WITH_LEFT_PAREN",
  "QUOTED_LITERAL", "CURLY_LITERAL", "ALPHA", "LOWERALPHA", "UPPERALPHA",
  "NUM", "PUNCT", "WHITESPACE", "COUNTER_LEFT", "SIGMA_LEFT",
  "INTERPOLATE_LEFT", "EXC_LEFT", "LST_LEFT", "TAG_LEFT", "AND_LEFT",
  "OR_LEFT", "NRC_LEFT", "NLC_LEFT", "RC_LEFT", "LC_LEFT", "ENDTAG_LEFT",
  "DEFINE_LEFT", "TOUPPER_LEFT", "TOLOWER_LEFT", "OPTCAP_LEFT",
  "DEFINED_LIST", "DEFINS", "REGEX", "INS_LEFT", "LIT_LEFT", "DEFINE",
  "$accept", "PMATCH", "DEFINITION", "ARGLIST", "EXPRESSION1",
  "EXPRESSION2", "EXPRESSION3", "PARALLEL_RULES", "RULE",
  "MAPPINGPAIR_VECTOR", "MAPPINGPAIR", "CONTEXTS_WITH_MARK",
  "CONTEXTS_VECTOR", "CONTEXT", "CONTEXT_MARK", "REPLACE_ARROW",
  "EXPRESSION4", "EXPRESSION5", "RESTR_CONTEXTS", "RESTR_CONTEXT",
  "EXPRESSION6", "EXPRESSION7", "EXPRESSION8", "EXPRESSION9",
  "EXPRESSION10", "EXPRESSION11", "EXPRESSION12", "EXPRESSION13",
  "FUNCALL", "FUNCALL_ARGLIST", "INSERTION", "ENDTAG", "READ_FROM",
  "CONTEXT_CONDITION", "PMATCH_CONTEXT", "PMATCH_OR_CONTEXT",
  "PMATCH_AND_CONTEXT", "PMATCH_CONTEXTS", "PMATCH_RIGHT_CONTEXT",
  "PMATCH_NEGATIVE_RIGHT_CONTEXT", "PMATCH_LEFT_CONTEXT",
  "PMATCH_NEGATIVE_LEFT_CONTEXT", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,   115,   116,   116,   117,   117,   117,   117,   117,   118,
     118,   118,   119,   120,   120,   120,   120,   120,   120,   120,
     120,   120,   120,   121,   121,   122,   122,   123,   123,   124,
     124,   125,   125,   125,   125,   125,   125,   125,   125,   126,
     127,   127,   128,   128,   128,   128,   129,   129,   129,   129,
     130,   130,   130,   130,   130,   130,   130,   130,   131,   131,
     131,   131,   132,   132,   132,   132,   133,   133,   134,   134,
     134,   134,   135,   135,   135,   135,   135,   135,   135,   135,
     136,   136,   137,   137,   137,   137,   138,   138,   138,   138,
     138,   139,   139,   139,   139,   139,   139,   139,   139,   139,
     139,   139,   140,   140,   141,   141,   141,   141,   141,   141,
     141,   142,   142,   142,   142,   142,   142,   142,   142,   142,
     142,   142,   142,   142,   142,   142,   142,   142,   142,   142,
     142,   142,   142,   142,   142,   142,   142,   142,   142,   143,
     144,   144,   144,   145,   146,   146,   147,   147,   147,   147,
     147,   147,   148,   148,   148,   149,   149,   149,   149,   150,
     151,   152,   152,   153,   154,   155,   156
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     2,     3,     3,     2,     5,     3,     3,
       1,     0,     2,     1,     3,     3,     3,     3,     3,     8,
       2,     2,     1,     1,     1,     3,     1,     1,     2,     3,
       1,     3,     5,     4,     4,     4,     5,     4,     5,     2,
       1,     3,     3,     2,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     3,
       3,     3,     1,     3,     5,     5,     1,     3,     3,     2,
       2,     1,     1,     3,     3,     3,     3,     3,     3,     3,
       1,     2,     1,     3,     3,     3,     1,     2,     2,     2,
       2,     1,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     1,     2,     1,     3,     3,     3,     2,     6,
       6,     1,     1,     1,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     3,     3,     3,     3,     1,
       1,     3,     3,     3,     3,     3,     1,     1,     1,     3,
       3,     1,     0,     3,     3,     3,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     3,
       3,     1,     3,     3,     3,     3,     3
};

/* YYDEFACT[STATE-NAME] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       2,     0,     1,     0,     0,     0,     0,     3,     0,     0,
     130,     0,     0,     0,     0,     0,     0,   150,   151,   149,
     148,   147,   146,     0,     0,     0,    22,     0,   112,   116,
     113,   138,   142,   111,   115,   119,   120,   121,   122,   123,
     124,     0,     0,   142,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     6,
       0,    13,    24,    26,    27,    30,    23,    58,    62,    72,
      80,    82,    86,    91,   102,   104,   117,   118,   136,   129,
     137,   152,   153,   154,   155,   156,   157,   158,     0,    11,
       8,     5,    90,    89,    88,    87,   103,     0,     0,     0,
       0,     0,    21,   141,     0,     0,     0,     0,     0,     0,
     161,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    12,     0,     0,     0,     0,
       0,    20,    55,    54,    53,    52,    57,    51,    56,    50,
       0,     0,    49,    48,    47,    46,     0,    28,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    81,     0,     0,     0,    97,    96,    95,    94,
      93,    92,   101,   100,    99,    98,   108,     0,     4,    10,
       0,     0,   105,   107,     0,     0,   142,   139,   135,   134,
     133,   132,   131,     0,   160,   159,   164,   166,   163,   165,
     144,   145,   128,   127,   126,   125,   143,   114,    18,    17,
      16,    14,    15,     0,     0,    31,     0,    25,    29,    45,
       0,    39,    40,    61,    60,    59,    74,     0,    71,    63,
      66,     0,     0,    79,    78,    77,    76,    75,    73,    85,
      84,    83,   106,    11,     0,     0,     0,    35,     0,   140,
     162,    34,    37,     0,    33,    44,    43,     0,     0,    70,
       0,    69,     0,     9,     7,     0,     0,     0,    36,    38,
      32,    42,    41,    65,    67,    68,    64,     0,   109,   110,
       0,    19
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,     7,   180,    59,    60,    61,    62,    63,    64,
      65,   147,   221,   222,   148,   140,    66,    67,   229,   230,
      68,    69,    70,    71,    72,    73,    74,    75,    76,   104,
      77,    78,    79,    80,    81,    82,    83,   111,    84,    85,
      86,    87
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -130
static const yytype_int16 yypact[] =
{
    -130,    16,  -130,   -72,   -65,   195,   -69,  -130,   195,   195,
    -130,   732,   732,   732,   732,   791,   -34,  -130,  -130,  -130,
    -130,  -130,  -130,   195,   195,   263,  -130,   195,  -130,  -130,
    -130,  -130,   195,  -130,  -130,  -130,  -130,  -130,  -130,  -130,
    -130,   -47,   195,   195,   195,   195,    90,    90,   195,   195,
     195,   195,     0,   195,   195,   195,   195,   -42,   -36,  -130,
      41,  1110,     5,  -130,    30,  -130,    13,  -130,  1037,   673,
     197,  -130,  -130,  1063,     6,  -130,  -130,  -130,  -130,  -130,
    -130,  -130,  -130,  -130,  -130,  -130,  -130,  -130,   195,   -29,
    -130,  -130,  -130,  -130,  -130,  -130,     6,   537,    59,    12,
    1110,   157,   100,    67,   -15,   -11,    48,    -4,   130,   138,
      26,     8,    27,   908,   914,   958,   964,    29,    37,   971,
     982,   988,   994,    42,    43,  -130,   537,   537,   537,   537,
     537,  -130,  -130,  -130,  -130,  -130,  -130,  -130,  -130,  -130,
     332,   537,  -130,  -130,  -130,  -130,   537,  -130,   400,   673,
     673,   673,   673,   673,   605,   673,   673,   673,   673,   673,
     673,   673,   673,   673,   673,   673,  -130,  -130,  -130,  -130,
    -130,  -130,  -130,  -130,  -130,  -130,  -130,   850,  -130,    52,
      47,   189,    23,  -130,   537,  1110,   195,  -130,  -130,  -130,
    -130,  -130,  -130,    90,  -130,  -130,  -130,  -130,  -130,  -130,
    -130,  -130,  -130,  -130,  -130,  -130,  -130,  -130,  1110,  1110,
    1110,  1110,  1110,   537,   468,  1009,  1110,  -130,  -130,   537,
    1074,    77,  -130,  -130,  -130,  -130,   673,  1053,   673,    93,
    -130,  1070,  1086,   673,   673,   673,   673,   673,   673,  -130,
    -130,  -130,  -130,   -29,   195,   537,     3,  1110,   537,  -130,
    -130,  1110,  1110,   175,   537,  1110,   537,   400,   673,   126,
     605,   673,   673,  -130,  -130,   996,    71,    75,  1110,  1110,
    1110,  1110,  -130,   126,  -130,   126,   126,   537,  -130,  -130,
     985,  -130
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -130,  -130,  -130,   -93,    -7,   -12,   -25,  -130,    14,  -130,
      11,  -130,  -130,  -103,  -130,   -96,  -130,   110,  -130,  -102,
    -129,   -66,  -130,    86,   213,  -130,   160,    18,  -130,   -35,
    -130,  -130,  -130,  -130,   -41,  -130,  -130,   -40,  -130,  -130,
    -130,  -130
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const yytype_uint16 yytable[] =
{
     101,    90,    91,   162,   184,   110,   110,   112,   107,   176,
       8,    98,    99,    88,    89,   102,     2,     9,   126,   127,
     103,   128,   129,   130,   227,   231,   232,   149,   150,   151,
     106,   103,   108,   109,    97,   105,   113,   114,   115,   116,
     123,   119,   120,   121,   122,   125,   124,   126,   127,   141,
     128,   129,   130,   179,   126,   127,   187,   128,   129,   130,
     188,   142,   143,   144,   145,   126,   127,   190,   128,   129,
     130,   193,   181,   126,   127,   146,   128,   129,   130,   194,
     177,   178,   117,   183,   118,   266,   226,   267,   131,   248,
     233,   234,   235,   236,   237,   238,   162,   243,   195,   259,
     200,   208,   209,   210,   211,   212,   126,   127,   201,   128,
     129,   130,   186,   206,   207,   215,   216,   131,   244,   189,
     246,   216,   257,   220,   131,     3,     4,     5,   182,   273,
       6,   231,   275,   276,   152,   131,   126,   127,   260,   128,
     129,   130,   278,   131,   126,   127,   279,   128,   129,   130,
     263,   249,   110,   250,   272,   217,   184,   218,   274,   247,
     162,   156,   157,   158,   159,   160,   161,   162,   162,   162,
     162,   162,   162,   248,   103,    96,   131,     0,   132,   133,
     134,   135,     0,     0,   136,   137,   138,   139,   251,   253,
      48,    49,    50,    51,   255,   242,   132,   133,   134,   135,
      10,   191,   136,   137,   138,   139,   131,     0,     0,   192,
     132,   133,   134,   135,   131,     0,   136,   137,   138,   139,
     265,     0,     0,   268,    92,    93,    94,    95,     0,   270,
     185,   271,   220,     0,   245,     0,     0,   264,   163,   164,
     165,    11,    12,    13,    14,    15,    16,     0,   269,   239,
     240,   241,   280,    17,    18,    19,    20,    21,    22,   223,
     224,   225,     0,    23,     0,    24,     0,    25,    10,     0,
      26,     0,    27,    28,    29,    30,     0,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,     0,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,     0,     0,     0,    57,    58,    11,
      12,    13,    14,    15,     0,     0,     0,     0,     0,     0,
       0,    17,    18,    19,    20,    21,    22,     0,     0,     0,
       0,    23,     0,    24,     0,    25,   100,    10,     0,     0,
       0,    28,    29,    30,   213,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,     0,     0,     0,    57,    58,     0,    11,    12,
      13,    14,    15,     0,     0,     0,     0,     0,     0,     0,
      17,    18,    19,    20,    21,    22,     0,     0,     0,     0,
      23,     0,    24,     0,   214,    10,     0,     0,     0,     0,
      28,    29,    30,   219,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,     0,     0,     0,    57,    58,    11,    12,    13,    14,
      15,     0,     0,     0,     0,     0,     0,     0,    17,    18,
      19,    20,    21,    22,     0,     0,     0,     0,    23,     0,
      24,     0,    25,    10,     0,     0,     0,     0,    28,    29,
      30,     0,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,     0,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,     0,
       0,     0,    57,    58,    11,    12,    13,    14,    15,     0,
       0,     0,     0,     0,     0,     0,    17,    18,    19,    20,
      21,    22,     0,     0,     0,     0,    23,     0,    24,     0,
      25,   252,    10,     0,     0,     0,    28,    29,    30,     0,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,     0,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,     0,     0,     0,
      57,    58,     0,    11,    12,    13,    14,    15,     0,     0,
       0,     0,     0,     0,     0,    17,    18,    19,    20,    21,
      22,     0,     0,     0,     0,    23,     0,    24,     0,    25,
      10,     0,     0,     0,     0,    28,    29,    30,   228,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,     0,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,     0,     0,     0,    57,
      58,    11,    12,    13,    14,    15,     0,     0,     0,     0,
       0,     0,     0,    17,    18,    19,    20,    21,    22,     0,
       0,     0,     0,    23,     0,    24,     0,     0,    10,     0,
       0,     0,     0,    28,    29,    30,     0,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,     0,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,     0,     0,     0,    57,    58,    11,
      12,    13,    14,    15,     0,     0,     0,     0,     0,     0,
       0,    17,    18,    19,    20,    21,    22,    10,     0,     0,
       0,    23,     0,    24,     0,     0,     0,     0,     0,     0,
       0,    28,    29,    30,     0,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
       0,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    15,     0,     0,    57,    58,     0,     0,     0,
      17,    18,    19,    20,    21,    22,    10,     0,     0,     0,
      23,     0,    24,     0,     0,     0,     0,     0,     0,     0,
      28,    29,    30,     0,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,     0,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,     0,     0,     0,    57,    58,     0,     0,     0,    17,
      18,    19,    20,    21,    22,    10,     0,     0,     0,    23,
       0,    24,     0,     0,     0,     0,     0,     0,     0,    28,
      29,    30,     0,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,     0,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
       0,     0,     0,    57,    58,     0,     0,     0,    17,    18,
      19,    20,    21,    22,   126,   127,     0,   128,   129,   130,
     126,   127,     0,   128,   129,   130,     0,     0,    28,    29,
      30,     0,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,     0,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,     0,
       0,     0,    57,    58,   126,   127,     0,   128,   129,   130,
     126,   127,     0,   128,   129,   130,     0,   126,   127,   196,
     128,   129,   130,     0,   131,   197,     0,     0,   126,   127,
     131,   128,   129,   130,   126,   127,     0,   128,   129,   130,
     126,   127,     0,   128,   129,   130,   132,   133,   134,   135,
       0,     0,   136,   137,   138,   139,     0,   132,   133,   134,
     135,   254,     0,   136,   137,   138,   139,     0,     0,   198,
     132,   133,   134,   135,   131,   199,   136,   137,   138,   139,
     131,   277,   202,     0,     0,   152,     0,   131,     0,     0,
       0,     0,     0,   203,   281,   153,   154,   155,   131,   204,
       0,   152,     0,     0,   131,   205,   258,     0,     0,     0,
     131,     0,   156,   157,   158,   159,   160,   161,   152,     0,
       0,     0,     0,   261,     0,     0,     0,   256,   156,   157,
     158,   159,   160,   161,   152,   132,   133,   134,   135,   262,
       0,   136,   137,   138,   139,   156,   157,   158,   159,   160,
     161,     0,     0,     0,     0,   166,   167,   168,   169,   170,
     171,   156,   157,   158,   159,   160,   161,   172,   173,   174,
     175,   132,   133,   134,   135,     0,     0,   136,   137,   138,
     139
};

#define yypact_value_is_default(yystate) \
  ((yystate) == (-130))

#define yytable_value_is_error(yytable_value) \
  YYID (0)

static const yytype_int16 yycheck[] =
{
      25,     8,     9,    69,   100,    46,    47,    47,    43,     3,
      82,    23,    24,    82,    83,    27,     0,    82,     6,     7,
      32,     9,    10,    11,   153,   154,   155,    14,    15,    16,
      42,    43,    44,    45,    68,    82,    48,    49,    50,    51,
      82,    53,    54,    55,    56,     4,    82,     6,     7,    44,
       9,    10,    11,    82,     6,     7,    71,     9,    10,    11,
      71,    31,    32,    33,    34,     6,     7,    71,     9,    10,
      11,    45,    97,     6,     7,    45,     9,    10,    11,    71,
      74,    88,    82,    71,    84,    82,   152,    84,    76,   185,
     156,   157,   158,   159,   160,   161,   162,    45,    71,   228,
      71,   126,   127,   128,   129,   130,     6,     7,    71,     9,
      10,    11,    45,    71,    71,   140,   141,    76,    71,    71,
      97,   146,    45,   148,    76,   109,   110,   111,    69,   258,
     114,   260,   261,   262,     8,    76,     6,     7,    45,     9,
      10,    11,    71,    76,     6,     7,    71,     9,    10,    11,
     243,   186,   193,   193,   257,   141,   252,   146,   260,   184,
     226,    35,    36,    37,    38,    39,    40,   233,   234,   235,
     236,   237,   238,   269,   186,    15,    76,    -1,    21,    22,
      23,    24,    -1,    -1,    27,    28,    29,    30,   213,   214,
     100,   101,   102,   103,   219,   177,    21,    22,    23,    24,
       5,    71,    27,    28,    29,    30,    76,    -1,    -1,    71,
      21,    22,    23,    24,    76,    -1,    27,    28,    29,    30,
     245,    -1,    -1,   248,    11,    12,    13,    14,    -1,   254,
      73,   256,   257,    -1,    45,    -1,    -1,   244,    41,    42,
      43,    46,    47,    48,    49,    50,    51,    -1,    73,   163,
     164,   165,   277,    58,    59,    60,    61,    62,    63,   149,
     150,   151,    -1,    68,    -1,    70,    -1,    72,     5,    -1,
      75,    -1,    77,    78,    79,    80,    -1,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    -1,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,    -1,    -1,    -1,   112,   113,    46,
      47,    48,    49,    50,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    58,    59,    60,    61,    62,    63,    -1,    -1,    -1,
      -1,    68,    -1,    70,    -1,    72,    73,     5,    -1,    -1,
      -1,    78,    79,    80,    12,    82,    83,    84,    85,    86,
      87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
      -1,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,    -1,    -1,    -1,   112,   113,    -1,    46,    47,
      48,    49,    50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      58,    59,    60,    61,    62,    63,    -1,    -1,    -1,    -1,
      68,    -1,    70,    -1,    72,     5,    -1,    -1,    -1,    -1,
      78,    79,    80,    13,    82,    83,    84,    85,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,    96,    -1,
      98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
     108,    -1,    -1,    -1,   112,   113,    46,    47,    48,    49,
      50,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    58,    59,
      60,    61,    62,    63,    -1,    -1,    -1,    -1,    68,    -1,
      70,    -1,    72,     5,    -1,    -1,    -1,    -1,    78,    79,
      80,    -1,    82,    83,    84,    85,    86,    87,    88,    89,
      90,    91,    92,    93,    94,    95,    96,    -1,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,    -1,
      -1,    -1,   112,   113,    46,    47,    48,    49,    50,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    58,    59,    60,    61,
      62,    63,    -1,    -1,    -1,    -1,    68,    -1,    70,    -1,
      72,    73,     5,    -1,    -1,    -1,    78,    79,    80,    -1,
      82,    83,    84,    85,    86,    87,    88,    89,    90,    91,
      92,    93,    94,    95,    96,    -1,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,    -1,    -1,    -1,
     112,   113,    -1,    46,    47,    48,    49,    50,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    58,    59,    60,    61,    62,
      63,    -1,    -1,    -1,    -1,    68,    -1,    70,    -1,    72,
       5,    -1,    -1,    -1,    -1,    78,    79,    80,    13,    82,
      83,    84,    85,    86,    87,    88,    89,    90,    91,    92,
      93,    94,    95,    96,    -1,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,    -1,    -1,    -1,   112,
     113,    46,    47,    48,    49,    50,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    58,    59,    60,    61,    62,    63,    -1,
      -1,    -1,    -1,    68,    -1,    70,    -1,    -1,     5,    -1,
      -1,    -1,    -1,    78,    79,    80,    -1,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    -1,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,    -1,    -1,    -1,   112,   113,    46,
      47,    48,    49,    50,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    58,    59,    60,    61,    62,    63,     5,    -1,    -1,
      -1,    68,    -1,    70,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    78,    79,    80,    -1,    82,    83,    84,    85,    86,
      87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
      -1,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,    50,    -1,    -1,   112,   113,    -1,    -1,    -1,
      58,    59,    60,    61,    62,    63,     5,    -1,    -1,    -1,
      68,    -1,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      78,    79,    80,    -1,    82,    83,    84,    85,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,    96,    -1,
      98,    99,   100,   101,   102,   103,   104,   105,   106,   107,
     108,    -1,    -1,    -1,   112,   113,    -1,    -1,    -1,    58,
      59,    60,    61,    62,    63,     5,    -1,    -1,    -1,    68,
      -1,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    78,
      79,    80,    -1,    82,    83,    84,    85,    86,    87,    88,
      89,    90,    91,    92,    93,    94,    95,    96,    -1,    98,
      99,   100,   101,   102,   103,   104,   105,   106,   107,   108,
      -1,    -1,    -1,   112,   113,    -1,    -1,    -1,    58,    59,
      60,    61,    62,    63,     6,     7,    -1,     9,    10,    11,
       6,     7,    -1,     9,    10,    11,    -1,    -1,    78,    79,
      80,    -1,    82,    83,    84,    85,    86,    87,    88,    89,
      90,    91,    92,    93,    94,    95,    96,    -1,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,    -1,
      -1,    -1,   112,   113,     6,     7,    -1,     9,    10,    11,
       6,     7,    -1,     9,    10,    11,    -1,     6,     7,    71,
       9,    10,    11,    -1,    76,    71,    -1,    -1,     6,     7,
      76,     9,    10,    11,     6,     7,    -1,     9,    10,    11,
       6,     7,    -1,     9,    10,    11,    21,    22,    23,    24,
      -1,    -1,    27,    28,    29,    30,    -1,    21,    22,    23,
      24,    12,    -1,    27,    28,    29,    30,    -1,    -1,    71,
      21,    22,    23,    24,    76,    71,    27,    28,    29,    30,
      76,    45,    71,    -1,    -1,     8,    -1,    76,    -1,    -1,
      -1,    -1,    -1,    71,    69,    18,    19,    20,    76,    71,
      -1,     8,    -1,    -1,    76,    71,    13,    -1,    -1,    -1,
      76,    -1,    35,    36,    37,    38,    39,    40,     8,    -1,
      -1,    -1,    -1,    13,    -1,    -1,    -1,    13,    35,    36,
      37,    38,    39,    40,     8,    21,    22,    23,    24,    13,
      -1,    27,    28,    29,    30,    35,    36,    37,    38,    39,
      40,    -1,    -1,    -1,    -1,    52,    53,    54,    55,    56,
      57,    35,    36,    37,    38,    39,    40,    64,    65,    66,
      67,    21,    22,    23,    24,    -1,    -1,    27,    28,    29,
      30
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,   116,     0,   109,   110,   111,   114,   117,    82,    82,
       5,    46,    47,    48,    49,    50,    51,    58,    59,    60,
      61,    62,    63,    68,    70,    72,    75,    77,    78,    79,
      80,    82,    83,    84,    85,    86,    87,    88,    89,    90,
      91,    92,    93,    94,    95,    96,    98,    99,   100,   101,
     102,   103,   104,   105,   106,   107,   108,   112,   113,   119,
     120,   121,   122,   123,   124,   125,   131,   132,   135,   136,
     137,   138,   139,   140,   141,   142,   143,   145,   146,   147,
     148,   149,   150,   151,   153,   154,   155,   156,    82,    83,
     119,   119,   139,   139,   139,   139,   141,    68,   120,   120,
      73,   121,   120,   120,   144,    82,   120,   144,   120,   120,
     149,   152,   152,   120,   120,   120,   120,    82,    84,   120,
     120,   120,   120,    82,    82,     4,     6,     7,     9,    10,
      11,    76,    21,    22,    23,    24,    27,    28,    29,    30,
     130,    44,    31,    32,    33,    34,    45,   126,   129,    14,
      15,    16,     8,    18,    19,    20,    35,    36,    37,    38,
      39,    40,   136,    41,    42,    43,    52,    53,    54,    55,
      56,    57,    64,    65,    66,    67,     3,    74,   119,    82,
     118,   121,    69,    71,   130,    73,    45,    71,    71,    71,
      71,    71,    71,    45,    71,    71,    71,    71,    71,    71,
      71,    71,    71,    71,    71,    71,    71,    71,   121,   121,
     121,   121,   121,    12,    72,   121,   121,   123,   125,    13,
     121,   127,   128,   132,   132,   132,   136,   135,    13,   133,
     134,   135,   135,   136,   136,   136,   136,   136,   136,   138,
     138,   138,   142,    45,    71,    45,    97,   121,   130,   144,
     152,   121,    73,   121,    12,   121,    13,    45,    13,   135,
      45,    13,    13,   118,   119,   121,    82,    84,   121,    73,
     121,   121,   128,   135,   134,   135,   135,    45,    71,    71,
     121,    69
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  However,
   YYFAIL appears to be in use.  Nevertheless, it is formally deprecated
   in Bison 2.4.2's NEWS entry, where a plan to phase it out is
   discussed.  */

#define YYFAIL		goto yyerrlab
#if defined YYFAIL
  /* This is here to suppress warnings from the GCC cpp's
     -Wunused-macros.  Normally we don't worry about that warning, but
     some users do, and we want to make it easy for users to remove
     YYFAIL uses, which will produce warnings from Bison 2.5.  */
#endif

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* This macro is provided for backward compatibility. */

#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  YYSIZE_T yysize1;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = 0;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - Assume YYFAIL is not used.  It's too flawed to consider.  See
       <http://lists.gnu.org/archive/html/bison-patches/2009-12/msg00024.html>
       for details.  YYERROR is fine as it does not invoke this
       function.
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                yysize1 = yysize + yytnamerr (0, yytname[yyx]);
                if (! (yysize <= yysize1
                       && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                  return 2;
                yysize = yysize1;
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  yysize1 = yysize + yystrlen (yyformat);
  if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
    return 2;
  yysize = yysize1;

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 3:

/* Line 1806 of yacc.c  */
#line 109 "pmatch_parse.yy"
    {
    if (verbose) {
        std::cerr << std::setiosflags(std::ios::fixed) << std::setprecision(2);
        double duration = (clock() - timer) /
            (double) CLOCKS_PER_SEC;
        timer = clock();
        std::cerr << "defined " << (yyvsp[(2) - (2)].pmatchDefinition)->first << " in " << duration << " seconds\n";
    }
    if (definitions.count((yyvsp[(2) - (2)].pmatchDefinition)->first) != 0) {
        std::stringstream warning;
        warning << "definition of " << (yyvsp[(2) - (2)].pmatchDefinition)->first << " on line " << pmatchlineno
                << " shadows earlier definition\n";
        warn(warning.str());
        delete definitions[(yyvsp[(2) - (2)].pmatchDefinition)->first];
    }
    definitions.insert(*(yyvsp[(2) - (2)].pmatchDefinition));
 }
    break;

  case 4:

/* Line 1806 of yacc.c  */
#line 127 "pmatch_parse.yy"
    {
    (yyval.pmatchDefinition) = new std::pair<std::string, PmatchObject*>((yyvsp[(2) - (3)].label), (yyvsp[(3) - (3)].pmatchObject));
    (yyvsp[(3) - (3)].pmatchObject)->name = (yyvsp[(2) - (3)].label);
    free((yyvsp[(2) - (3)].label));
 }
    break;

  case 5:

/* Line 1806 of yacc.c  */
#line 132 "pmatch_parse.yy"
    {
     (yyval.pmatchDefinition) = new std::pair<std::string, PmatchObject*>(
         (yyvsp[(2) - (3)].label), new PmatchString(get_Ins_transition((yyvsp[(2) - (3)].label))));
     def_insed_expressions[(yyvsp[(2) - (3)].label)] = (yyvsp[(3) - (3)].pmatchObject);
     (yyvsp[(3) - (3)].pmatchObject)->name = (yyvsp[(2) - (3)].label);
     free((yyvsp[(2) - (3)].label));
 }
    break;

  case 6:

/* Line 1806 of yacc.c  */
#line 139 "pmatch_parse.yy"
    {
     (yyval.pmatchDefinition) = new std::pair<std::string, PmatchObject*>("TOP", (yyvsp[(2) - (2)].pmatchObject));
     (yyvsp[(2) - (2)].pmatchObject)->name = "TOP";
 }
    break;

  case 7:

/* Line 1806 of yacc.c  */
#line 143 "pmatch_parse.yy"
    {
     if ((yyvsp[(3) - (5)].string_vector)->size() == 0) {
         (yyvsp[(5) - (5)].pmatchObject)->name = (yyvsp[(2) - (5)].label);
         (yyval.pmatchDefinition) = new std::pair<std::string, PmatchObject*>((yyvsp[(2) - (5)].label), (yyvsp[(5) - (5)].pmatchObject));
     } else {
         PmatchFunction * fun = new PmatchFunction(*(yyvsp[(3) - (5)].string_vector), (yyvsp[(5) - (5)].pmatchObject));
         fun->name = (yyvsp[(2) - (5)].label);
         (yyval.pmatchDefinition) = new std::pair<std::string, PmatchObject*>(std::string((yyvsp[(2) - (5)].label)), fun);
     }
     free((yyvsp[(2) - (5)].label));
 }
    break;

  case 8:

/* Line 1806 of yacc.c  */
#line 154 "pmatch_parse.yy"
    {
     (yyval.pmatchDefinition) = new std::pair<std::string, PmatchObject *>(
         (yyvsp[(2) - (3)].label), new PmatchUnaryOperation(MakeSigma, (yyvsp[(3) - (3)].pmatchObject)));
     (yyvsp[(3) - (3)].pmatchObject)->name = (yyvsp[(2) - (3)].label);
 }
    break;

  case 9:

/* Line 1806 of yacc.c  */
#line 161 "pmatch_parse.yy"
    { (yyval.string_vector) = (yyvsp[(3) - (3)].string_vector); (yyval.string_vector)->push_back(std::string((yyvsp[(1) - (3)].label)));
 }
    break;

  case 10:

/* Line 1806 of yacc.c  */
#line 162 "pmatch_parse.yy"
    { (yyval.string_vector) = new std::vector<std::string>(1, std::string((yyvsp[(1) - (1)].label))); }
    break;

  case 11:

/* Line 1806 of yacc.c  */
#line 163 "pmatch_parse.yy"
    { (yyval.string_vector) = new std::vector<std::string>(); }
    break;

  case 12:

/* Line 1806 of yacc.c  */
#line 165 "pmatch_parse.yy"
    {
     (yyvsp[(1) - (2)].pmatchObject)->weight += (yyvsp[(2) - (2)].weight);
     if (need_delimiters) {
         (yyval.pmatchObject) = new PmatchUnaryOperation(AddDelimiters, (yyvsp[(1) - (2)].pmatchObject));
     } else {
         (yyval.pmatchObject) = (yyvsp[(1) - (2)].pmatchObject);
     }
     need_delimiters = false;
}
    break;

  case 13:

/* Line 1806 of yacc.c  */
#line 175 "pmatch_parse.yy"
    {}
    break;

  case 14:

/* Line 1806 of yacc.c  */
#line 176 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(Compose, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 15:

/* Line 1806 of yacc.c  */
#line 177 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(CrossProduct, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 16:

/* Line 1806 of yacc.c  */
#line 178 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(LenientCompose, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 17:

/* Line 1806 of yacc.c  */
#line 179 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(Merge, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject));}
    break;

  case 18:

/* Line 1806 of yacc.c  */
#line 180 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(Merge, (yyvsp[(3) - (3)].pmatchObject), (yyvsp[(1) - (3)].pmatchObject)); }
    break;

  case 19:

/* Line 1806 of yacc.c  */
#line 181 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchTernaryOperation(Substitute, (yyvsp[(3) - (8)].pmatchObject), (yyvsp[(5) - (8)].pmatchObject), (yyvsp[(7) - (8)].pmatchObject));
}
    break;

  case 20:

/* Line 1806 of yacc.c  */
#line 184 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchBinaryOperation(CrossProduct, (yyvsp[(1) - (2)].pmatchObject), new PmatchQuestionMark); }
    break;

  case 21:

/* Line 1806 of yacc.c  */
#line 186 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchBinaryOperation(CrossProduct, new PmatchQuestionMark, (yyvsp[(2) - (2)].pmatchObject)); }
    break;

  case 22:

/* Line 1806 of yacc.c  */
#line 188 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchQuestionMark;
}
    break;

  case 23:

/* Line 1806 of yacc.c  */
#line 192 "pmatch_parse.yy"
    { }
    break;

  case 24:

/* Line 1806 of yacc.c  */
#line 193 "pmatch_parse.yy"
    { }
    break;

  case 25:

/* Line 1806 of yacc.c  */
#line 196 "pmatch_parse.yy"
    {
    if ((yyvsp[(3) - (3)].replaceRule)->arrow != (yyvsp[(1) - (3)].replaceRules)->arrow) {
        pmatcherror("Replace type mismatch in parallel rules");
    }
    (yyval.replaceRules) = dynamic_cast<PmatchParallelRulesContainer *>((yyval.replaceRules));
    (yyvsp[(1) - (3)].replaceRules)->rules.push_back((yyvsp[(3) - (3)].replaceRule));
}
    break;

  case 26:

/* Line 1806 of yacc.c  */
#line 202 "pmatch_parse.yy"
    {
    (yyval.replaceRules) = new PmatchParallelRulesContainer((yyvsp[(1) - (1)].replaceRule));
}
    break;

  case 27:

/* Line 1806 of yacc.c  */
#line 207 "pmatch_parse.yy"
    { (yyval.replaceRule) = new PmatchReplaceRuleContainer((yyvsp[(1) - (1)].mappings)); }
    break;

  case 28:

/* Line 1806 of yacc.c  */
#line 209 "pmatch_parse.yy"
    { (yyval.replaceRule) = new PmatchReplaceRuleContainer((yyvsp[(1) - (2)].mappings), (yyvsp[(2) - (2)].parallelContexts)); }
    break;

  case 29:

/* Line 1806 of yacc.c  */
#line 213 "pmatch_parse.yy"
    {
          if ((yyvsp[(1) - (3)].mappings)->arrow != (yyvsp[(3) - (3)].mappings)->arrow) {
             pmatcherror("Replace type mismatch in parallel rules.");
          }
         (yyvsp[(1) - (3)].mappings)->push_back((yyvsp[(3) - (3)].mappings));
      }
    break;

  case 30:

/* Line 1806 of yacc.c  */
#line 219 "pmatch_parse.yy"
    { (yyval.mappings) = (yyvsp[(1) - (1)].mappings); }
    break;

  case 31:

/* Line 1806 of yacc.c  */
#line 222 "pmatch_parse.yy"
    {
    (yyval.mappings) = new PmatchMappingPairsContainer((yyvsp[(2) - (3)].replaceArrow), (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 32:

/* Line 1806 of yacc.c  */
#line 224 "pmatch_parse.yy"
    {
    PmatchMarkupContainer * markup = new PmatchMarkupContainer((yyvsp[(3) - (5)].pmatchObject), (yyvsp[(5) - (5)].pmatchObject));
    (yyval.mappings) = new PmatchMappingPairsContainer((yyvsp[(2) - (5)].replaceArrow), (yyvsp[(1) - (5)].pmatchObject), markup); }
    break;

  case 33:

/* Line 1806 of yacc.c  */
#line 227 "pmatch_parse.yy"
    {
    PmatchTransducerContainer * epsilon = new PmatchTransducerContainer(
        new HfstTransducer(hfst::internal_epsilon, format));
    PmatchMarkupContainer * markup = new PmatchMarkupContainer((yyvsp[(3) - (4)].pmatchObject), epsilon);
    (yyval.mappings) = new PmatchMappingPairsContainer((yyvsp[(2) - (4)].replaceArrow), (yyvsp[(1) - (4)].pmatchObject), markup);
}
    break;

  case 34:

/* Line 1806 of yacc.c  */
#line 232 "pmatch_parse.yy"
    {
    PmatchMarkupContainer * markup = new PmatchMarkupContainer(new PmatchEpsilonArc, (yyvsp[(4) - (4)].pmatchObject));
    (yyval.mappings) = new PmatchMappingPairsContainer((yyvsp[(2) - (4)].replaceArrow), (yyvsp[(1) - (4)].pmatchObject), markup);
}
    break;

  case 35:

/* Line 1806 of yacc.c  */
#line 235 "pmatch_parse.yy"
    {
    (yyval.mappings) = new PmatchMappingPairsContainer((yyvsp[(3) - (4)].replaceArrow), new PmatchEpsilonArc, (yyvsp[(4) - (4)].pmatchObject));
}
    break;

  case 36:

/* Line 1806 of yacc.c  */
#line 237 "pmatch_parse.yy"
    {
    (yyval.mappings) = new PmatchMappingPairsContainer((yyvsp[(4) - (5)].replaceArrow), (yyvsp[(2) - (5)].pmatchObject), (yyvsp[(5) - (5)].pmatchObject));
}
    break;

  case 37:

/* Line 1806 of yacc.c  */
#line 239 "pmatch_parse.yy"
    {
    (yyval.mappings) = new PmatchMappingPairsContainer((yyvsp[(2) - (4)].replaceArrow), (yyvsp[(1) - (4)].pmatchObject), new PmatchEpsilonArc);
}
    break;

  case 38:

/* Line 1806 of yacc.c  */
#line 241 "pmatch_parse.yy"
    {
    (yyval.mappings) = new PmatchMappingPairsContainer((yyvsp[(2) - (5)].replaceArrow), (yyvsp[(1) - (5)].pmatchObject), (yyvsp[(4) - (5)].pmatchObject)); }
    break;

  case 39:

/* Line 1806 of yacc.c  */
#line 246 "pmatch_parse.yy"
    {
    (yyval.parallelContexts) = new PmatchContextsContainer((yyvsp[(1) - (2)].replType), (yyvsp[(2) - (2)].parallelContexts));
}
    break;

  case 40:

/* Line 1806 of yacc.c  */
#line 250 "pmatch_parse.yy"
    {
    (yyval.parallelContexts) = new PmatchContextsContainer((yyvsp[(1) - (1)].parallelContexts));
}
    break;

  case 41:

/* Line 1806 of yacc.c  */
#line 252 "pmatch_parse.yy"
    {
    (yyvsp[(1) - (3)].parallelContexts)->push_back((yyvsp[(3) - (3)].parallelContexts));
    (yyval.parallelContexts) = (yyvsp[(1) - (3)].parallelContexts);
}
    break;

  case 42:

/* Line 1806 of yacc.c  */
#line 258 "pmatch_parse.yy"
    { (yyval.parallelContexts) = new PmatchContextsContainer((yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 43:

/* Line 1806 of yacc.c  */
#line 259 "pmatch_parse.yy"
    { (yyval.parallelContexts) = new PmatchContextsContainer((yyvsp[(1) - (2)].pmatchObject), new PmatchEpsilonArc); }
    break;

  case 44:

/* Line 1806 of yacc.c  */
#line 260 "pmatch_parse.yy"
    { (yyval.parallelContexts) = new PmatchContextsContainer(new PmatchEpsilonArc, (yyvsp[(2) - (2)].pmatchObject)); }
    break;

  case 45:

/* Line 1806 of yacc.c  */
#line 261 "pmatch_parse.yy"
    { (yyval.parallelContexts) = new PmatchContextsContainer(new PmatchEpsilonArc, new PmatchEpsilonArc);
}
    break;

  case 46:

/* Line 1806 of yacc.c  */
#line 265 "pmatch_parse.yy"
    { (yyval.replType) = REPL_UP; }
    break;

  case 47:

/* Line 1806 of yacc.c  */
#line 266 "pmatch_parse.yy"
    { (yyval.replType) = REPL_RIGHT; }
    break;

  case 48:

/* Line 1806 of yacc.c  */
#line 267 "pmatch_parse.yy"
    { (yyval.replType) = REPL_LEFT; }
    break;

  case 49:

/* Line 1806 of yacc.c  */
#line 268 "pmatch_parse.yy"
    { (yyval.replType) = REPL_DOWN; }
    break;

  case 50:

/* Line 1806 of yacc.c  */
#line 271 "pmatch_parse.yy"
    { (yyval.replaceArrow) = E_REPLACE_RIGHT; }
    break;

  case 51:

/* Line 1806 of yacc.c  */
#line 272 "pmatch_parse.yy"
    { (yyval.replaceArrow) = E_OPTIONAL_REPLACE_RIGHT; }
    break;

  case 52:

/* Line 1806 of yacc.c  */
#line 273 "pmatch_parse.yy"
    { (yyval.replaceArrow) = E_RTL_LONGEST_MATCH; }
    break;

  case 53:

/* Line 1806 of yacc.c  */
#line 274 "pmatch_parse.yy"
    { (yyval.replaceArrow) = E_RTL_SHORTEST_MATCH; }
    break;

  case 54:

/* Line 1806 of yacc.c  */
#line 275 "pmatch_parse.yy"
    { (yyval.replaceArrow) = E_LTR_LONGEST_MATCH; }
    break;

  case 55:

/* Line 1806 of yacc.c  */
#line 276 "pmatch_parse.yy"
    { (yyval.replaceArrow) = E_LTR_SHORTEST_MATCH; }
    break;

  case 56:

/* Line 1806 of yacc.c  */
#line 277 "pmatch_parse.yy"
    { (yyval.replaceArrow) =  E_REPLACE_LEFT; }
    break;

  case 57:

/* Line 1806 of yacc.c  */
#line 278 "pmatch_parse.yy"
    { (yyval.replaceArrow) = E_OPTIONAL_REPLACE_LEFT;
}
    break;

  case 58:

/* Line 1806 of yacc.c  */
#line 281 "pmatch_parse.yy"
    { }
    break;

  case 59:

/* Line 1806 of yacc.c  */
#line 282 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(Shuffle, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 60:

/* Line 1806 of yacc.c  */
#line 283 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(Before, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject));}
    break;

  case 61:

/* Line 1806 of yacc.c  */
#line 284 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(After, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 62:

/* Line 1806 of yacc.c  */
#line 286 "pmatch_parse.yy"
    { }
    break;

  case 63:

/* Line 1806 of yacc.c  */
#line 287 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchRestrictionContainer((yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].restrictionContexts)); }
    break;

  case 64:

/* Line 1806 of yacc.c  */
#line 288 "pmatch_parse.yy"
    { pmatcherror("Left arrow with contexts not implemented"); }
    break;

  case 65:

/* Line 1806 of yacc.c  */
#line 289 "pmatch_parse.yy"
    { pmatcherror("Left-right arrow with contexts not implemented"); }
    break;

  case 66:

/* Line 1806 of yacc.c  */
#line 291 "pmatch_parse.yy"
    {
    (yyval.restrictionContexts) = new MappingPairVector();
    (yyval.restrictionContexts)->push_back(*(yyvsp[(1) - (1)].restrictionContext));
    delete (yyvsp[(1) - (1)].restrictionContext);
}
    break;

  case 67:

/* Line 1806 of yacc.c  */
#line 296 "pmatch_parse.yy"
    {
     (yyvsp[(1) - (3)].restrictionContexts)->push_back(*(yyvsp[(3) - (3)].restrictionContext));
     (yyval.restrictionContexts) = (yyvsp[(1) - (3)].restrictionContexts);
     delete (yyvsp[(3) - (3)].restrictionContext);
}
    break;

  case 68:

/* Line 1806 of yacc.c  */
#line 303 "pmatch_parse.yy"
    { (yyval.restrictionContext) = new PmatchObjectPair((yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 69:

/* Line 1806 of yacc.c  */
#line 304 "pmatch_parse.yy"
    { (yyval.restrictionContext) = new PmatchObjectPair((yyvsp[(1) - (2)].pmatchObject), new PmatchEpsilonArc); }
    break;

  case 70:

/* Line 1806 of yacc.c  */
#line 305 "pmatch_parse.yy"
    { (yyval.restrictionContext) = new PmatchObjectPair(new PmatchEpsilonArc, (yyvsp[(2) - (2)].pmatchObject)); }
    break;

  case 71:

/* Line 1806 of yacc.c  */
#line 306 "pmatch_parse.yy"
    { (yyval.restrictionContext) = new PmatchObjectPair(new PmatchEmpty, new PmatchEmpty); }
    break;

  case 72:

/* Line 1806 of yacc.c  */
#line 308 "pmatch_parse.yy"
    { }
    break;

  case 73:

/* Line 1806 of yacc.c  */
#line 309 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(Disjunct, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 74:

/* Line 1806 of yacc.c  */
#line 310 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(Intersect, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 75:

/* Line 1806 of yacc.c  */
#line 311 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(Subtract, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 76:

/* Line 1806 of yacc.c  */
#line 312 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(UpperSubtract, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 77:

/* Line 1806 of yacc.c  */
#line 313 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(LowerSubtract, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 78:

/* Line 1806 of yacc.c  */
#line 314 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(UpperPriorityUnion, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 79:

/* Line 1806 of yacc.c  */
#line 315 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(LowerPriorityUnion, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 80:

/* Line 1806 of yacc.c  */
#line 317 "pmatch_parse.yy"
    { }
    break;

  case 81:

/* Line 1806 of yacc.c  */
#line 318 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(Concatenate, (yyvsp[(1) - (2)].pmatchObject), (yyvsp[(2) - (2)].pmatchObject)); }
    break;

  case 82:

/* Line 1806 of yacc.c  */
#line 320 "pmatch_parse.yy"
    { }
    break;

  case 83:

/* Line 1806 of yacc.c  */
#line 321 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(InsertFreely, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 84:

/* Line 1806 of yacc.c  */
#line 322 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(IgnoreInternally, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 85:

/* Line 1806 of yacc.c  */
#line 323 "pmatch_parse.yy"
    { pmatcherror("Left quotient not implemented"); }
    break;

  case 86:

/* Line 1806 of yacc.c  */
#line 325 "pmatch_parse.yy"
    { }
    break;

  case 87:

/* Line 1806 of yacc.c  */
#line 326 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(Complement, (yyvsp[(2) - (2)].pmatchObject)); }
    break;

  case 88:

/* Line 1806 of yacc.c  */
#line 327 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(Containment, (yyvsp[(2) - (2)].pmatchObject)); }
    break;

  case 89:

/* Line 1806 of yacc.c  */
#line 328 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(ContainmentOnce, (yyvsp[(2) - (2)].pmatchObject)); }
    break;

  case 90:

/* Line 1806 of yacc.c  */
#line 329 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(ContainmentOptional, (yyvsp[(2) - (2)].pmatchObject)); }
    break;

  case 91:

/* Line 1806 of yacc.c  */
#line 331 "pmatch_parse.yy"
    { }
    break;

  case 92:

/* Line 1806 of yacc.c  */
#line 332 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(RepeatStar, (yyvsp[(1) - (2)].pmatchObject)); }
    break;

  case 93:

/* Line 1806 of yacc.c  */
#line 333 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(RepeatPlus, (yyvsp[(1) - (2)].pmatchObject)); }
    break;

  case 94:

/* Line 1806 of yacc.c  */
#line 334 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(Reverse, (yyvsp[(1) - (2)].pmatchObject)); }
    break;

  case 95:

/* Line 1806 of yacc.c  */
#line 335 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(Invert, (yyvsp[(1) - (2)].pmatchObject)); }
    break;

  case 96:

/* Line 1806 of yacc.c  */
#line 336 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(InputProject, (yyvsp[(1) - (2)].pmatchObject)); }
    break;

  case 97:

/* Line 1806 of yacc.c  */
#line 337 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(OutputProject, (yyvsp[(1) - (2)].pmatchObject)); }
    break;

  case 98:

/* Line 1806 of yacc.c  */
#line 338 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchNumericOperation(RepeatN, (yyvsp[(1) - (2)].pmatchObject));
    (dynamic_cast<PmatchNumericOperation *>((yyval.pmatchObject)))->values.push_back((yyvsp[(2) - (2)].value));
}
    break;

  case 99:

/* Line 1806 of yacc.c  */
#line 342 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchNumericOperation(RepeatNPlus, (yyvsp[(1) - (2)].pmatchObject));
    (dynamic_cast<PmatchNumericOperation *>((yyval.pmatchObject)))->values.push_back((yyvsp[(2) - (2)].value) + 1);
}
    break;

  case 100:

/* Line 1806 of yacc.c  */
#line 346 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchNumericOperation(RepeatNMinus, (yyvsp[(1) - (2)].pmatchObject));
    (dynamic_cast<PmatchNumericOperation *>((yyval.pmatchObject)))->values.push_back((yyvsp[(2) - (2)].value) - 1);
}
    break;

  case 101:

/* Line 1806 of yacc.c  */
#line 350 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchNumericOperation(RepeatNToK, (yyvsp[(1) - (2)].pmatchObject));
    (dynamic_cast<PmatchNumericOperation *>((yyval.pmatchObject)))->values.push_back((yyvsp[(2) - (2)].values)[0]);
    (dynamic_cast<PmatchNumericOperation *>((yyval.pmatchObject)))->values.push_back((yyvsp[(2) - (2)].values)[1]);
    free((yyvsp[(2) - (2)].values));
}
    break;

  case 102:

/* Line 1806 of yacc.c  */
#line 357 "pmatch_parse.yy"
    { }
    break;

  case 103:

/* Line 1806 of yacc.c  */
#line 358 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(TermComplement, (yyvsp[(2) - (2)].pmatchObject)); }
    break;

  case 104:

/* Line 1806 of yacc.c  */
#line 360 "pmatch_parse.yy"
    { }
    break;

  case 105:

/* Line 1806 of yacc.c  */
#line 361 "pmatch_parse.yy"
    { (yyval.pmatchObject) = (yyvsp[(2) - (3)].pmatchObject); }
    break;

  case 106:

/* Line 1806 of yacc.c  */
#line 362 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBinaryOperation(CrossProduct, (yyvsp[(1) - (3)].pmatchObject), (yyvsp[(3) - (3)].pmatchObject)); }
    break;

  case 107:

/* Line 1806 of yacc.c  */
#line 363 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(Optionalize, (yyvsp[(2) - (3)].pmatchObject)); }
    break;

  case 108:

/* Line 1806 of yacc.c  */
#line 364 "pmatch_parse.yy"
    { (yyval.pmatchObject) = (yyvsp[(1) - (2)].pmatchObject); (yyval.pmatchObject)->weight += (yyvsp[(2) - (2)].weight); }
    break;

  case 109:

/* Line 1806 of yacc.c  */
#line 365 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchUnaryOperation(AddDelimiters,
                                  new PmatchBinaryOperation(Concatenate, (yyvsp[(2) - (6)].pmatchObject),
                                                            new PmatchString((yyvsp[(5) - (6)].label))));
    free((yyvsp[(5) - (6)].label)); }
    break;

  case 110:

/* Line 1806 of yacc.c  */
#line 370 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchUnaryOperation(AddDelimiters,
                                  new PmatchBinaryOperation(Concatenate, (yyvsp[(2) - (6)].pmatchObject),
                                                            new PmatchString((yyvsp[(5) - (6)].label))));
    free((yyvsp[(5) - (6)].label)); }
    break;

  case 111:

/* Line 1806 of yacc.c  */
#line 377 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchString(std::string((yyvsp[(1) - (1)].label))); free((yyvsp[(1) - (1)].label)); }
    break;

  case 112:

/* Line 1806 of yacc.c  */
#line 378 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchString(hfst::internal_epsilon); }
    break;

  case 113:

/* Line 1806 of yacc.c  */
#line 379 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchString("@BOUNDARY@"); }
    break;

  case 114:

/* Line 1806 of yacc.c  */
#line 380 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchString(std::string((yyvsp[(2) - (3)].label))); free((yyvsp[(2) - (3)].label)); }
    break;

  case 115:

/* Line 1806 of yacc.c  */
#line 381 "pmatch_parse.yy"
    {
    PmatchString * retval = new PmatchString(std::string((yyvsp[(1) - (1)].label)));
    retval->multichar = true;
    (yyval.pmatchObject) = retval; free((yyvsp[(1) - (1)].label));
}
    break;

  case 116:

/* Line 1806 of yacc.c  */
#line 386 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchQuestionMark; }
    break;

  case 117:

/* Line 1806 of yacc.c  */
#line 387 "pmatch_parse.yy"
    { }
    break;

  case 118:

/* Line 1806 of yacc.c  */
#line 389 "pmatch_parse.yy"
    { }
    break;

  case 119:

/* Line 1806 of yacc.c  */
#line 390 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchAcceptor(Alpha); }
    break;

  case 120:

/* Line 1806 of yacc.c  */
#line 391 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchAcceptor(LowercaseAlpha); }
    break;

  case 121:

/* Line 1806 of yacc.c  */
#line 392 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchAcceptor(UppercaseAlpha); }
    break;

  case 122:

/* Line 1806 of yacc.c  */
#line 393 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchAcceptor(Numeral); }
    break;

  case 123:

/* Line 1806 of yacc.c  */
#line 394 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchAcceptor(Punctuation); }
    break;

  case 124:

/* Line 1806 of yacc.c  */
#line 395 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchAcceptor(Whitespace); }
    break;

  case 125:

/* Line 1806 of yacc.c  */
#line 396 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(OptCap, (yyvsp[(2) - (3)].pmatchObject)); }
    break;

  case 126:

/* Line 1806 of yacc.c  */
#line 397 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(ToLower, (yyvsp[(2) - (3)].pmatchObject)); }
    break;

  case 127:

/* Line 1806 of yacc.c  */
#line 398 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(ToUpper, (yyvsp[(2) - (3)].pmatchObject)); }
    break;

  case 128:

/* Line 1806 of yacc.c  */
#line 399 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(AddDelimiters, (yyvsp[(2) - (3)].pmatchObject)); }
    break;

  case 129:

/* Line 1806 of yacc.c  */
#line 400 "pmatch_parse.yy"
    { }
    break;

  case 130:

/* Line 1806 of yacc.c  */
#line 401 "pmatch_parse.yy"
    { (yyval.pmatchObject) = (yyvsp[(1) - (1)].pmatchObject); }
    break;

  case 131:

/* Line 1806 of yacc.c  */
#line 402 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(MakeList, (yyvsp[(2) - (3)].pmatchObject)); }
    break;

  case 132:

/* Line 1806 of yacc.c  */
#line 403 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(MakeExcList, (yyvsp[(2) - (3)].pmatchObject)); }
    break;

  case 133:

/* Line 1806 of yacc.c  */
#line 404 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchBuiltinFunction(Interpolate, (yyvsp[(2) - (3)].pmatchObject_vector)); }
    break;

  case 134:

/* Line 1806 of yacc.c  */
#line 405 "pmatch_parse.yy"
    { (yyval.pmatchObject) = new PmatchUnaryOperation(MakeSigma, (yyvsp[(2) - (3)].pmatchObject)); }
    break;

  case 135:

/* Line 1806 of yacc.c  */
#line 406 "pmatch_parse.yy"
    { (yyval.pmatchObject) = hfst::pmatch::make_counter((yyvsp[(2) - (3)].label)); free((yyvsp[(2) - (3)].label)); }
    break;

  case 136:

/* Line 1806 of yacc.c  */
#line 407 "pmatch_parse.yy"
    { (yyval.pmatchObject) = (yyvsp[(1) - (1)].pmatchObject); hfst::pmatch::need_delimiters = true; }
    break;

  case 137:

/* Line 1806 of yacc.c  */
#line 408 "pmatch_parse.yy"
    { (yyval.pmatchObject) = (yyvsp[(1) - (1)].pmatchObject); hfst::pmatch::need_delimiters = true; }
    break;

  case 138:

/* Line 1806 of yacc.c  */
#line 409 "pmatch_parse.yy"
    {
    std::string sym((yyvsp[(1) - (1)].label));
    free((yyvsp[(1) - (1)].label));
    if (sym.size() == 0) {
        (yyval.pmatchObject) = new PmatchEmpty;
    } else {
        (yyval.pmatchObject) = new PmatchSymbol(sym);
    }
}
    break;

  case 139:

/* Line 1806 of yacc.c  */
#line 420 "pmatch_parse.yy"
    {
    std::string sym((yyvsp[(1) - (3)].label));
    if (!symbol_in_global_context(sym)) {
        std::stringstream ss;
        ss << "Function " << sym << " hasn't been defined\n";
        pmatcherror(ss.str().c_str());
        (yyval.pmatchObject) = new PmatchString("");
    } else {
        (yyval.pmatchObject) = new PmatchFuncall(
            (yyvsp[(2) - (3)].pmatchObject_vector),
            dynamic_cast<PmatchFunction *>(symbol_from_global_context(sym)));
    }
    used_definitions.insert(sym);
    free((yyvsp[(1) - (3)].label));
}
    break;

  case 140:

/* Line 1806 of yacc.c  */
#line 436 "pmatch_parse.yy"
    {
(yyval.pmatchObject_vector) = (yyvsp[(3) - (3)].pmatchObject_vector); (yyval.pmatchObject_vector)->push_back((yyvsp[(1) - (3)].pmatchObject)); }
    break;

  case 141:

/* Line 1806 of yacc.c  */
#line 438 "pmatch_parse.yy"
    { (yyval.pmatchObject_vector) = new std::vector<PmatchObject *>(1, (yyvsp[(1) - (1)].pmatchObject)); }
    break;

  case 142:

/* Line 1806 of yacc.c  */
#line 439 "pmatch_parse.yy"
    { (yyval.pmatchObject_vector) = new std::vector<PmatchObject *>; }
    break;

  case 143:

/* Line 1806 of yacc.c  */
#line 441 "pmatch_parse.yy"
    {
    if (!hfst::pmatch::flatten) {
        if(hfst::pmatch::definitions.count((yyvsp[(2) - (3)].label)) == 0) {
            hfst::pmatch::unsatisfied_insertions.insert((yyvsp[(2) - (3)].label));
        }
        (yyval.pmatchObject) = new PmatchString(hfst::pmatch::get_Ins_transition((yyvsp[(2) - (3)].label)));
        hfst::pmatch::inserted_names.insert((yyvsp[(2) - (3)].label));
        hfst::pmatch::used_definitions.insert((yyvsp[(2) - (3)].label));
    } else if(hfst::pmatch::definitions.count((yyvsp[(2) - (3)].label)) != 0) {
        (yyval.pmatchObject) = hfst::pmatch::definitions[(yyvsp[(2) - (3)].label)];
    } else {
        (yyval.pmatchObject) = new PmatchEmpty;
        std::stringstream ss;
        ss << "Insertion of " << (yyvsp[(2) - (3)].label) << " on line " << pmatchlineno << " is undefined and --flatten is in use\n";
        pmatcherror(ss.str().c_str());
    }
    free((yyvsp[(2) - (3)].label));
}
    break;

  case 144:

/* Line 1806 of yacc.c  */
#line 460 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = hfst::pmatch::make_end_tag((yyvsp[(2) - (3)].label));
    free((yyvsp[(2) - (3)].label));
}
    break;

  case 145:

/* Line 1806 of yacc.c  */
#line 463 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = hfst::pmatch::make_end_tag((yyvsp[(2) - (3)].label));
    free((yyvsp[(2) - (3)].label));
}
    break;

  case 146:

/* Line 1806 of yacc.c  */
#line 468 "pmatch_parse.yy"
    {
    HfstTransducer * read;
    try {
        hfst::HfstInputStream instream((yyvsp[(1) - (1)].label));
        read = new HfstTransducer(instream);
        instream.close();
    } catch(HfstException) {
        std::string ermsg =
            std::string("Couldn't read transducer from ") +
            std::string((yyvsp[(1) - (1)].label));
        free((yyvsp[(1) - (1)].label));
        pmatcherror(ermsg.c_str());
    }
    if (read->get_type() != hfst::pmatch::format) {
        read->convert(hfst::pmatch::format);
    }
    (yyval.pmatchObject) = new PmatchTransducerContainer(read);
    free((yyvsp[(1) - (1)].label));
}
    break;

  case 147:

/* Line 1806 of yacc.c  */
#line 486 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchTransducerContainer(hfst::pmatch::read_text((yyvsp[(1) - (1)].label)));
    free((yyvsp[(1) - (1)].label));
}
    break;

  case 148:

/* Line 1806 of yacc.c  */
#line 489 "pmatch_parse.yy"
    {
    FILE * f = NULL;
    f = fopen((yyvsp[(1) - (1)].label), "r");
    if (f == NULL) {
        pmatcherror("File cannot be opened.\n");
    } else {
        HfstTokenizer tok;
        HfstBasicTransducer tmp;
        char line [1000];
        while( fgets(line, 1000, f) != NULL )
        {
            hfst::pmatch::strip_newline(line);
            StringPairVector spv = HfstTokenizer::tokenize_space_separated(line);
            tmp.disjunct(spv, 0);
        }
        fclose(f);
        HfstTransducer * t = new HfstTransducer(tmp, hfst::pmatch::format); 
        t->minimize();
        (yyval.pmatchObject) = new PmatchTransducerContainer(t);
    }
}
    break;

  case 149:

/* Line 1806 of yacc.c  */
#line 509 "pmatch_parse.yy"
    {
    FILE * f = NULL;
    f = fopen((yyvsp[(1) - (1)].label), "r");
    if (f == NULL) {
        pmatcherror("File cannot be opened.\n");
    } else {
        try {
            unsigned int linecount = 0;
            HfstBasicTransducer tmp = HfstBasicTransducer::read_in_prolog_format(f, linecount);
            fclose(f);
            HfstTransducer * t = new HfstTransducer(tmp, hfst::pmatch::format);
            t->minimize();
            (yyval.pmatchObject) = new PmatchTransducerContainer(t);
        }
        catch (const HfstException & e) {
            (void) e;
            fclose(f);
            pmatcherror("Error reading prolog file.\n");
        }
    }
}
    break;

  case 150:

/* Line 1806 of yacc.c  */
#line 529 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchTransducerContainer(hfst::HfstTransducer::read_lexc_ptr((yyvsp[(1) - (1)].label), format, hfst::pmatch::verbose));
    free((yyvsp[(1) - (1)].label));
}
    break;

  case 151:

/* Line 1806 of yacc.c  */
#line 532 "pmatch_parse.yy"
    {
    std::string regex;
    std::string tmp;
    std::ifstream regexfile((yyvsp[(1) - (1)].label));
    if (regexfile.is_open()) {
        while (getline(regexfile, tmp)) {
            regex.append(tmp);
        }
    }
    if (regex.size() == 0) {
        std::stringstream err;
        err << "Failed to read regex from " << (yyvsp[(1) - (1)].label) << ".\n";
        pmatcherror(err.str().c_str());
    }
    hfst::xre::XreCompiler xre_compiler;
    (yyval.pmatchObject) = new PmatchTransducerContainer(xre_compiler.compile(regex));
    }
    break;

  case 152:

/* Line 1806 of yacc.c  */
#line 551 "pmatch_parse.yy"
    { }
    break;

  case 153:

/* Line 1806 of yacc.c  */
#line 552 "pmatch_parse.yy"
    { }
    break;

  case 154:

/* Line 1806 of yacc.c  */
#line 553 "pmatch_parse.yy"
    { }
    break;

  case 155:

/* Line 1806 of yacc.c  */
#line 556 "pmatch_parse.yy"
    { }
    break;

  case 156:

/* Line 1806 of yacc.c  */
#line 557 "pmatch_parse.yy"
    { }
    break;

  case 157:

/* Line 1806 of yacc.c  */
#line 558 "pmatch_parse.yy"
    { }
    break;

  case 158:

/* Line 1806 of yacc.c  */
#line 559 "pmatch_parse.yy"
    { }
    break;

  case 159:

/* Line 1806 of yacc.c  */
#line 562 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = NULL;
    for (std::vector<PmatchObject *>::reverse_iterator it = (yyvsp[(2) - (3)].pmatchObject_vector)->rbegin();
         it != (yyvsp[(2) - (3)].pmatchObject_vector)->rend(); ++it) {
        if ((yyval.pmatchObject) == NULL) {
            (yyval.pmatchObject) = *it;
        } else {
            PmatchObject * tmp = (yyval.pmatchObject);
            (yyval.pmatchObject) = new PmatchBinaryOperation(Disjunct, tmp, *it);
        }
    }
    delete (yyvsp[(2) - (3)].pmatchObject_vector);
    // Zero the counter for making minimization
    // guards for disjuncted negative contexts
    hfst::pmatch::zero_minimization_guard();
}
    break;

  case 160:

/* Line 1806 of yacc.c  */
#line 580 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = NULL;
    for (std::vector<PmatchObject *>::reverse_iterator it = (yyvsp[(2) - (3)].pmatchObject_vector)->rbegin();
         it != (yyvsp[(2) - (3)].pmatchObject_vector)->rend(); ++it) {
        if ((yyval.pmatchObject) = NULL) {
            (yyval.pmatchObject) = *it;
        } else {
            PmatchObject * tmp = (yyval.pmatchObject);
            (yyval.pmatchObject) = new PmatchBinaryOperation(Concatenate, tmp, *it);
        }
    }
    delete (yyvsp[(2) - (3)].pmatchObject_vector);
}
    break;

  case 161:

/* Line 1806 of yacc.c  */
#line 595 "pmatch_parse.yy"
    {
    (yyval.pmatchObject_vector) = new std::vector<PmatchObject *>(1, (yyvsp[(1) - (1)].pmatchObject));
}
    break;

  case 162:

/* Line 1806 of yacc.c  */
#line 598 "pmatch_parse.yy"
    {
    (yyvsp[(3) - (3)].pmatchObject_vector)->push_back((yyvsp[(1) - (3)].pmatchObject));
    (yyval.pmatchObject_vector) = (yyvsp[(3) - (3)].pmatchObject_vector);
}
    break;

  case 163:

/* Line 1806 of yacc.c  */
#line 603 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchBinaryOperation(Concatenate, make_rc_entry(),
                                   new PmatchBinaryOperation(
                                       Concatenate, (yyvsp[(2) - (3)].pmatchObject), make_rc_exit()));
}
    break;

  case 164:

/* Line 1806 of yacc.c  */
#line 609 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchBinaryOperation(
        Concatenate, make_minimization_guard(),
        new PmatchBinaryOperation(
            Disjunct, make_passthrough(),
            new PmatchBinaryOperation(
                Concatenate, make_nrc_entry(),
                new PmatchBinaryOperation(Concatenate, (yyvsp[(2) - (3)].pmatchObject), make_nrc_exit()))));
}
    break;

  case 165:

/* Line 1806 of yacc.c  */
#line 619 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchBinaryOperation(
        Concatenate, make_lc_entry(),
        new PmatchBinaryOperation(
            Concatenate, new PmatchUnaryOperation(
                Reverse, (yyvsp[(2) - (3)].pmatchObject)), make_lc_exit()));
}
    break;

  case 166:

/* Line 1806 of yacc.c  */
#line 627 "pmatch_parse.yy"
    {
    (yyval.pmatchObject) = new PmatchBinaryOperation(
        Concatenate, make_minimization_guard(),
        new PmatchBinaryOperation(
            Disjunct, make_passthrough(),
            new PmatchBinaryOperation(
                Concatenate, make_nlc_entry(),
                new PmatchBinaryOperation(Concatenate, new PmatchUnaryOperation(
                                              Reverse, (yyvsp[(2) - (3)].pmatchObject)), make_nlc_exit()))));
}
    break;



/* Line 1806 of yacc.c  */
#line 3580 "pmatch_parse.cc"
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 2067 of yacc.c  */
#line 666 "pmatch_parse.yy"


