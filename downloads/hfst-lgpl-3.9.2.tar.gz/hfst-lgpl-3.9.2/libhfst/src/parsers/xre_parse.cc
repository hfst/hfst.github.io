/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison implementation for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.5"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse         xreparse
#define yylex           xrelex
#define yyerror         xreerror
#define yylval          xrelval
#define yychar          xrechar
#define yydebug         xredebug
#define yynerrs         xrenerrs


/* Copy the first part of user declarations.  */

/* Line 268 of yacc.c  */
#line 1 "xre_parse.yy"

// Copyright (c) 2016 University of Helsinki                          
//                                                                    
// This library is free software; you can redistribute it and/or      
// modify it under the terms of the GNU Lesser General Public         
// License as published by the Free Software Foundation; either       
// version 3 of the License, or (at your option) any later version.
// See the file COPYING included with this distribution for more      
// information.

#define YYDEBUG 1 

#include <stdio.h>
#include <assert.h>
#include <iostream>

#include "HfstTransducer.h"
#include "HfstInputStream.h"
#include "HfstXeroxRules.h"

using namespace hfst;
using hfst::HfstTransducer;
using namespace hfst::xeroxRules;
using namespace hfst::implementations;

#include "xre_utils.h"

namespace hfst { 
  namespace xre {
    // number of characters read, used for scanning function definition xre for argument symbols
    extern unsigned int cr;
    extern bool harmonize_;
    extern bool harmonize_flags_;
    extern bool allow_extra_text_at_end;

    bool has_weight_been_zeroed = false; // to control how many times a warning is given
    float zero_weights(float f)
    {
        if ((! has_weight_been_zeroed) && (f != 0))
        {
            hfst::xre::warn("warning: ignoring weights in rule context\n");
            has_weight_been_zeroed = true;
        }
        return 0;
    }

    bool is_weighted()
    {   
        return (hfst::xre::format == hfst::TROPICAL_OPENFST_TYPE || 
                hfst::xre::format == hfst::LOG_OPENFST_TYPE);
    }
  }
}

using hfst::xre::harmonize_;
using hfst::xre::harmonize_flags_;

union YYSTYPE;
struct yy_buffer_state;
typedef yy_buffer_state * YY_BUFFER_STATE;
typedef void * yyscan_t;

extern int xreparse(yyscan_t);
extern int xrelex_init (yyscan_t*);
extern YY_BUFFER_STATE xre_scan_string (const char *, yyscan_t);
extern void xre_delete_buffer (YY_BUFFER_STATE, yyscan_t);
extern int xrelex_destroy (yyscan_t);

extern int xreerror(yyscan_t, const char*);
extern int xreerror(const char*);
int xrelex ( YYSTYPE * , yyscan_t );



/* Line 268 of yacc.c  */
#line 154 "xre_parse.cc"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 1
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     WEIGHT = 258,
     CURLY_BRACKETS = 259,
     SYMBOL = 260,
     MERGE_LEFT_ARROW = 261,
     MERGE_RIGHT_ARROW = 262,
     INTERSECTION = 263,
     LENIENT_COMPOSITION = 264,
     COMPOSITION = 265,
     CROSS_PRODUCT = 266,
     MARKUP_MARKER = 267,
     CENTER_MARKER = 268,
     SHUFFLE = 269,
     LEFT_RIGHT_ARROW = 270,
     RIGHT_ARROW = 271,
     LEFT_ARROW = 272,
     LEFT_RESTRICTION = 273,
     LTR_SHORTEST_MATCH = 274,
     LTR_LONGEST_MATCH = 275,
     RTL_SHORTEST_MATCH = 276,
     RTL_LONGEST_MATCH = 277,
     OPTIONAL_REPLACE_LEFT_RIGHT = 278,
     REPLACE_LEFT_RIGHT = 279,
     OPTIONAL_REPLACE_LEFT = 280,
     OPTIONAL_REPLACE_RIGHT = 281,
     REPLACE_LEFT = 282,
     REPLACE_RIGHT = 283,
     REPLACE_CONTEXT_LL = 284,
     REPLACE_CONTEXT_UL = 285,
     REPLACE_CONTEXT_LU = 286,
     REPLACE_CONTEXT_UU = 287,
     LOWER_PRIORITY_UNION = 288,
     UPPER_PRIORITY_UNION = 289,
     LOWER_MINUS = 290,
     UPPER_MINUS = 291,
     MINUS = 292,
     UNION = 293,
     LEFT_QUOTIENT = 294,
     IGNORE_INTERNALLY = 295,
     IGNORING = 296,
     COMMACOMMA = 297,
     COMMA = 298,
     AFTER = 299,
     BEFORE = 300,
     TERM_COMPLEMENT = 301,
     SUBSTITUTE_LEFT = 302,
     CONTAINMENT_OPT = 303,
     CONTAINMENT_ONCE = 304,
     CONTAINMENT = 305,
     COMPLEMENT = 306,
     PLUS = 307,
     STAR = 308,
     XRE_LOWER = 309,
     XRE_UPPER = 310,
     INVERT = 311,
     REVERSE = 312,
     CATENATE_N_TO_K = 313,
     CATENATE_N_MINUS = 314,
     CATENATE_N_PLUS = 315,
     CATENATE_N = 316,
     READ_RE = 317,
     READ_PROLOG = 318,
     READ_SPACED = 319,
     READ_TEXT = 320,
     READ_BIN = 321,
     FUNCTION_NAME = 322,
     LEFT_BRACKET = 323,
     RIGHT_BRACKET = 324,
     LEFT_PARENTHESIS = 325,
     RIGHT_PARENTHESIS = 326,
     LEFT_BRACKET_DOTTED = 327,
     RIGHT_BRACKET_DOTTED = 328,
     SUBVAL = 329,
     EPSILON_TOKEN = 330,
     ANY_TOKEN = 331,
     BOUNDARY_MARKER = 332,
     LEXER_ERROR = 333,
     END_OF_EXPRESSION = 334,
     PAIR_SEPARATOR = 335,
     QUOTED_LITERAL = 336
   };
#endif
/* Tokens.  */
#define WEIGHT 258
#define CURLY_BRACKETS 259
#define SYMBOL 260
#define MERGE_LEFT_ARROW 261
#define MERGE_RIGHT_ARROW 262
#define INTERSECTION 263
#define LENIENT_COMPOSITION 264
#define COMPOSITION 265
#define CROSS_PRODUCT 266
#define MARKUP_MARKER 267
#define CENTER_MARKER 268
#define SHUFFLE 269
#define LEFT_RIGHT_ARROW 270
#define RIGHT_ARROW 271
#define LEFT_ARROW 272
#define LEFT_RESTRICTION 273
#define LTR_SHORTEST_MATCH 274
#define LTR_LONGEST_MATCH 275
#define RTL_SHORTEST_MATCH 276
#define RTL_LONGEST_MATCH 277
#define OPTIONAL_REPLACE_LEFT_RIGHT 278
#define REPLACE_LEFT_RIGHT 279
#define OPTIONAL_REPLACE_LEFT 280
#define OPTIONAL_REPLACE_RIGHT 281
#define REPLACE_LEFT 282
#define REPLACE_RIGHT 283
#define REPLACE_CONTEXT_LL 284
#define REPLACE_CONTEXT_UL 285
#define REPLACE_CONTEXT_LU 286
#define REPLACE_CONTEXT_UU 287
#define LOWER_PRIORITY_UNION 288
#define UPPER_PRIORITY_UNION 289
#define LOWER_MINUS 290
#define UPPER_MINUS 291
#define MINUS 292
#define UNION 293
#define LEFT_QUOTIENT 294
#define IGNORE_INTERNALLY 295
#define IGNORING 296
#define COMMACOMMA 297
#define COMMA 298
#define AFTER 299
#define BEFORE 300
#define TERM_COMPLEMENT 301
#define SUBSTITUTE_LEFT 302
#define CONTAINMENT_OPT 303
#define CONTAINMENT_ONCE 304
#define CONTAINMENT 305
#define COMPLEMENT 306
#define PLUS 307
#define STAR 308
#define XRE_LOWER 309
#define XRE_UPPER 310
#define INVERT 311
#define REVERSE 312
#define CATENATE_N_TO_K 313
#define CATENATE_N_MINUS 314
#define CATENATE_N_PLUS 315
#define CATENATE_N 316
#define READ_RE 317
#define READ_PROLOG 318
#define READ_SPACED 319
#define READ_TEXT 320
#define READ_BIN 321
#define FUNCTION_NAME 322
#define LEFT_BRACKET 323
#define RIGHT_BRACKET 324
#define LEFT_PARENTHESIS 325
#define RIGHT_PARENTHESIS 326
#define LEFT_BRACKET_DOTTED 327
#define RIGHT_BRACKET_DOTTED 328
#define SUBVAL 329
#define EPSILON_TOKEN 330
#define ANY_TOKEN 331
#define BOUNDARY_MARKER 332
#define LEXER_ERROR 333
#define END_OF_EXPRESSION 334
#define PAIR_SEPARATOR 335
#define QUOTED_LITERAL 336




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 293 of yacc.c  */
#line 82 "xre_parse.yy"


    int value;
    int* values;
    double weight;
    char* label;
    
    char *subval1, *subval2;
    
    hfst::HfstTransducer* transducer;
    hfst::HfstTransducerPair* transducerPair;
    hfst::HfstTransducerPairVector* transducerPairVector;
    hfst::HfstTransducerVector* transducerVector;

   std::pair<hfst::xeroxRules::ReplaceArrow, std::vector<hfst::xeroxRules::Rule> >* replaceRuleVectorWithArrow;
   std::pair< hfst::xeroxRules::ReplaceArrow, hfst::xeroxRules::Rule>* replaceRuleWithArrow;   
   std::pair< hfst::xeroxRules::ReplaceArrow, hfst::HfstTransducerPairVector>* mappingVectorWithArrow;
   std::pair< hfst::xeroxRules::ReplaceArrow, hfst::HfstTransducerPair>* mappingWithArrow;
       
   std::pair<hfst::xeroxRules::ReplaceType, hfst::HfstTransducerPairVector>* contextWithMark;
   
   hfst::xeroxRules::ReplaceType replType;
   hfst::xeroxRules::ReplaceArrow replaceArrow; 




/* Line 293 of yacc.c  */
#line 380 "xre_parse.cc"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif


/* Copy the second part of user declarations.  */


/* Line 343 of yacc.c  */
#line 392 "xre_parse.cc"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  57
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   612

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  82
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  35
/* YYNRULES -- Number of rules.  */
#define YYNRULES  133
/* YYNRULES -- Number of states.  */
#define YYNSTATES  212

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   336

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     6,     9,    11,    13,    17,    21,
      25,    29,    33,    43,    47,    52,    55,    58,    60,    62,
      64,    68,    70,    72,    75,    79,    81,    85,    91,    96,
     101,   106,   112,   117,   123,   126,   128,   132,   136,   139,
     142,   144,   146,   148,   150,   152,   154,   156,   158,   160,
     162,   164,   166,   168,   170,   174,   178,   182,   184,   188,
     194,   200,   202,   206,   210,   213,   216,   218,   220,   224,
     228,   232,   236,   240,   244,   248,   250,   253,   255,   259,
     263,   267,   269,   272,   275,   279,   282,   285,   287,   290,
     293,   296,   299,   302,   305,   308,   311,   314,   317,   319,
     322,   324,   328,   336,   342,   348,   354,   360,   365,   369,
     371,   374,   376,   379,   381,   383,   385,   387,   389,   391,
     395,   399,   403,   405,   409,   413,   415,   417,   419,   421,
     423,   425,   429,   431
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int8 yyrhs[] =
{
      83,     0,    -1,    84,    -1,    -1,    85,    79,    -1,    85,
      -1,    89,    -1,    85,    10,    89,    -1,    85,    11,    89,
      -1,    85,     9,    89,    -1,    85,     7,    89,    -1,    85,
       6,    89,    -1,    86,   114,    80,   114,    43,   114,    80,
     114,    69,    -1,    86,    87,    88,    -1,    47,    68,    89,
      43,    -1,   114,    43,    -1,   110,    69,    -1,    69,    -1,
      99,    -1,    90,    -1,    90,    42,    91,    -1,    91,    -1,
      92,    -1,    92,    94,    -1,    92,    43,    93,    -1,    93,
      -1,    89,    98,    89,    -1,    89,    98,    89,    12,    89,
      -1,    89,    98,    89,    12,    -1,    89,    98,    12,    89,
      -1,    72,    73,    98,    89,    -1,    72,    89,    73,    98,
      89,    -1,    89,    98,    72,    73,    -1,    89,    98,    72,
      89,    73,    -1,    97,    95,    -1,    96,    -1,    95,    43,
      96,    -1,    89,    13,    89,    -1,    89,    13,    -1,    13,
      89,    -1,    13,    -1,    32,    -1,    31,    -1,    30,    -1,
      29,    -1,    28,    -1,    26,    -1,    22,    -1,    21,    -1,
      20,    -1,    19,    -1,    27,    -1,    25,    -1,   100,    -1,
      99,    14,   100,    -1,    99,    45,   100,    -1,    99,    44,
     100,    -1,   103,    -1,   100,    16,   101,    -1,   100,    17,
     103,    13,   103,    -1,   100,    15,   103,    13,   103,    -1,
     102,    -1,   101,    43,   102,    -1,   100,    13,   100,    -1,
     100,    13,    -1,    13,   100,    -1,    13,    -1,   104,    -1,
     103,    38,   104,    -1,   103,     8,   104,    -1,   103,    37,
     104,    -1,   103,    36,   104,    -1,   103,    35,   104,    -1,
     103,    34,   104,    -1,   103,    33,   104,    -1,   105,    -1,
     104,   105,    -1,   106,    -1,   105,    41,   106,    -1,   105,
      40,   106,    -1,   105,    39,   106,    -1,   107,    -1,    51,
     106,    -1,    50,   106,    -1,    50,     3,   106,    -1,    49,
     106,    -1,    48,   106,    -1,   108,    -1,   107,    53,    -1,
     107,    52,    -1,   107,    57,    -1,   107,    56,    -1,   107,
      55,    -1,   107,    54,    -1,   107,    61,    -1,   107,    60,
      -1,   107,    59,    -1,   107,    58,    -1,   109,    -1,    46,
     108,    -1,   111,    -1,    68,    85,    69,    -1,    68,    85,
      69,    80,    68,    85,    69,    -1,    68,    85,    69,    80,
       4,    -1,     4,    80,    68,    85,    69,    -1,    68,    85,
      69,    80,   114,    -1,   114,    80,    68,    85,    69,    -1,
      68,    85,    69,     3,    -1,    70,    85,    71,    -1,   114,
      -1,   110,   114,    -1,   112,    -1,   112,     3,    -1,    66,
      -1,    65,    -1,    64,    -1,    63,    -1,    62,    -1,   114,
      -1,   114,    80,   114,    -1,   114,    80,     4,    -1,     4,
      80,   114,    -1,     4,    -1,     4,    80,     4,    -1,   116,
     115,    71,    -1,     5,    -1,    81,    -1,   113,    -1,    75,
      -1,    76,    -1,    77,    -1,   115,    43,    85,    -1,    85,
      -1,    67,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   174,   174,   176,   182,   193,   205,   210,   234,   238,
     242,   255,   260,   264,   342,   343,   344,   346,   353,   354,
     393,   406,   417,   426,   438,   455,   467,   476,   485,   495,
     505,   515,   522,   530,   540,   545,   553,   561,   594,   616,
     639,   645,   649,   653,   657,   663,   667,   671,   675,   679,
     683,   687,   691,   698,   699,   705,   709,   716,   718,   724,
     732,   741,   749,   758,   763,   773,   779,   787,   788,   792,
     797,   801,   807,   813,   817,   827,   828,   834,   835,   839,
     845,   853,   854,   862,   875,   885,   891,   897,   898,   901,
     904,   907,   910,   913,   916,   919,   923,   926,   932,   933,
     948,   949,   953,   958,   965,   972,   979,   985,   988,   994,
    1005,  1022,  1023,  1026,  1041,  1065,  1089,  1113,  1157,  1171,
    1176,  1184,  1192,  1196,  1202,  1248,  1249,  1252,  1261,  1264,
    1267,  1272,  1276,  1283
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "WEIGHT", "CURLY_BRACKETS", "SYMBOL",
  "MERGE_LEFT_ARROW", "MERGE_RIGHT_ARROW", "INTERSECTION",
  "LENIENT_COMPOSITION", "COMPOSITION", "CROSS_PRODUCT", "MARKUP_MARKER",
  "CENTER_MARKER", "SHUFFLE", "LEFT_RIGHT_ARROW", "RIGHT_ARROW",
  "LEFT_ARROW", "LEFT_RESTRICTION", "LTR_SHORTEST_MATCH",
  "LTR_LONGEST_MATCH", "RTL_SHORTEST_MATCH", "RTL_LONGEST_MATCH",
  "OPTIONAL_REPLACE_LEFT_RIGHT", "REPLACE_LEFT_RIGHT",
  "OPTIONAL_REPLACE_LEFT", "OPTIONAL_REPLACE_RIGHT", "REPLACE_LEFT",
  "REPLACE_RIGHT", "REPLACE_CONTEXT_LL", "REPLACE_CONTEXT_UL",
  "REPLACE_CONTEXT_LU", "REPLACE_CONTEXT_UU", "LOWER_PRIORITY_UNION",
  "UPPER_PRIORITY_UNION", "LOWER_MINUS", "UPPER_MINUS", "MINUS", "UNION",
  "LEFT_QUOTIENT", "IGNORE_INTERNALLY", "IGNORING", "COMMACOMMA", "COMMA",
  "AFTER", "BEFORE", "TERM_COMPLEMENT", "SUBSTITUTE_LEFT",
  "CONTAINMENT_OPT", "CONTAINMENT_ONCE", "CONTAINMENT", "COMPLEMENT",
  "PLUS", "STAR", "XRE_LOWER", "XRE_UPPER", "INVERT", "REVERSE",
  "CATENATE_N_TO_K", "CATENATE_N_MINUS", "CATENATE_N_PLUS", "CATENATE_N",
  "READ_RE", "READ_PROLOG", "READ_SPACED", "READ_TEXT", "READ_BIN",
  "FUNCTION_NAME", "LEFT_BRACKET", "RIGHT_BRACKET", "LEFT_PARENTHESIS",
  "RIGHT_PARENTHESIS", "LEFT_BRACKET_DOTTED", "RIGHT_BRACKET_DOTTED",
  "SUBVAL", "EPSILON_TOKEN", "ANY_TOKEN", "BOUNDARY_MARKER", "LEXER_ERROR",
  "END_OF_EXPRESSION", "PAIR_SEPARATOR", "QUOTED_LITERAL", "$accept",
  "XRE", "REGEXP1", "REGEXP2", "SUB1", "SUB2", "SUB3", "REPLACE",
  "PARALLEL_RULES", "RULE", "MAPPINGPAIR_VECTOR", "MAPPINGPAIR",
  "CONTEXTS_WITH_MARK", "CONTEXTS_VECTOR", "CONTEXT", "CONTEXT_MARK",
  "REPLACE_ARROW", "REGEXP3", "REGEXP4", "RESTR_CONTEXTS_VECTOR",
  "RESTR_CONTEXT", "REGEXP5", "REGEXP6", "REGEXP7", "REGEXP8", "REGEXP9",
  "REGEXP10", "REGEXP11", "SYMBOL_LIST", "REGEXP12", "LABEL",
  "SYMBOL_OR_QUOTED", "HALFARC", "REGEXP_LIST", "FUNCTION", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    82,    83,    83,    84,    84,    85,    85,    85,    85,
      85,    85,    85,    85,    86,    87,    88,    88,    89,    89,
      90,    90,    91,    91,    92,    92,    93,    93,    93,    93,
      93,    93,    93,    93,    94,    95,    95,    96,    96,    96,
      96,    97,    97,    97,    97,    98,    98,    98,    98,    98,
      98,    98,    98,    99,    99,    99,    99,   100,   100,   100,
     100,   101,   101,   102,   102,   102,   102,   103,   103,   103,
     103,   103,   103,   103,   103,   104,   104,   105,   105,   105,
     105,   106,   106,   106,   106,   106,   106,   107,   107,   107,
     107,   107,   107,   107,   107,   107,   107,   107,   108,   108,
     109,   109,   109,   109,   109,   109,   109,   109,   109,   110,
     110,   111,   111,   111,   111,   111,   111,   111,   112,   112,
     112,   112,   112,   112,   112,   113,   113,   114,   114,   114,
     114,   115,   115,   116
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     0,     2,     1,     1,     3,     3,     3,
       3,     3,     9,     3,     4,     2,     2,     1,     1,     1,
       3,     1,     1,     2,     3,     1,     3,     5,     4,     4,
       4,     5,     4,     5,     2,     1,     3,     3,     2,     2,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     3,     3,     3,     1,     3,     5,
       5,     1,     3,     3,     2,     2,     1,     1,     3,     3,
       3,     3,     3,     3,     3,     1,     2,     1,     3,     3,
       3,     1,     2,     2,     3,     2,     2,     1,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     1,     2,
       1,     3,     7,     5,     5,     5,     5,     4,     3,     1,
       2,     1,     2,     1,     1,     1,     1,     1,     1,     3,
       3,     3,     1,     3,     3,     1,     1,     1,     1,     1,
       1,     3,     1,     1
};

/* YYDEFACT[STATE-NAME] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       3,   122,   125,     0,     0,     0,     0,     0,     0,   117,
     116,   115,   114,   113,   133,     0,     0,     0,   128,   129,
     130,   126,     0,     2,     5,     0,     6,    19,    21,    22,
      25,    18,    53,    57,    67,    75,    77,    81,    87,    98,
     100,   111,   127,   118,     0,     0,    99,     0,    86,    85,
       0,    83,    82,     0,     0,     0,     0,     1,     0,     0,
       0,     0,     0,     4,     0,     0,    50,    49,    48,    47,
      52,    46,    51,    45,     0,     0,    44,    43,    42,    41,
       0,    23,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    76,     0,     0,     0,
      89,    88,    93,    92,    91,    90,    97,    96,    95,    94,
     112,     0,   132,     0,   123,     0,   121,     0,    84,   101,
     108,     0,     0,    11,    10,     9,     7,     8,    17,    13,
       0,   109,    15,     0,     0,     0,    26,     0,    20,    24,
      40,     0,    34,    35,    54,    56,    55,     0,    66,     0,
      58,    61,     0,    69,    74,    73,    72,    71,    70,    68,
      80,    79,    78,   120,     0,   119,     0,   124,     0,    14,
     107,     0,    30,     0,    16,   110,     0,    29,    32,     0,
      28,    39,    38,     0,     0,    65,    64,     0,     0,     0,
     131,   104,   103,     0,   105,    31,     0,    33,    27,    37,
      36,    60,    63,    62,    59,   106,     0,     0,   102,     0,
       0,    12
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    22,    23,    24,    25,    64,   129,    26,    27,    28,
      29,    30,    81,   142,   143,    82,    74,    31,    32,   150,
     151,    33,    34,    35,    36,    37,    38,    39,   130,    40,
      41,    42,    43,   113,    44
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -110
static const yytype_int16 yypact[] =
{
     173,   -76,  -110,    17,   -60,   433,   433,   137,   433,  -110,
    -110,  -110,  -110,  -110,  -110,   173,   173,   211,  -110,  -110,
    -110,  -110,    19,  -110,    47,   115,   571,    -4,  -110,    12,
    -110,     1,    44,   304,   433,   -12,  -110,   528,  -110,  -110,
    -110,    14,  -110,   -33,   173,    85,  -110,   359,  -110,  -110,
     433,  -110,  -110,   148,    25,   571,   466,  -110,   359,   359,
     359,   359,   359,  -110,   303,   -40,  -110,  -110,  -110,  -110,
    -110,  -110,  -110,  -110,   251,   359,  -110,  -110,  -110,  -110,
     359,  -110,   285,   433,   433,   433,   433,   399,   433,   433,
     433,   433,   433,   433,   433,   433,   -12,   433,   433,   433,
    -110,  -110,  -110,  -110,  -110,  -110,  -110,  -110,  -110,  -110,
    -110,    99,   601,   -38,  -110,   173,  -110,   515,  -110,    11,
    -110,   359,   571,   571,   571,   571,   571,   571,  -110,  -110,
     377,  -110,  -110,   115,   359,   325,   540,   571,  -110,  -110,
     359,   551,    23,  -110,    44,    44,    44,   494,   433,   106,
      24,  -110,   512,   433,   433,   433,   433,   433,   433,   433,
    -110,  -110,  -110,  -110,   173,  -110,   173,  -110,   222,  -110,
    -110,   190,   571,   359,  -110,  -110,    26,   571,   571,   496,
     359,   571,   359,   285,   433,    44,   433,   399,   433,   300,
     601,  -110,  -110,   173,  -110,   571,   115,   571,   571,   571,
    -110,   304,    44,  -110,   304,  -110,   408,   -18,  -110,   115,
       2,  -110
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -110,  -110,  -110,   -14,  -110,  -110,  -110,   -10,  -110,     0,
    -110,    -3,  -110,  -110,  -107,  -110,   -49,  -110,   -74,  -110,
    -109,   -70,   511,   -22,    18,  -110,    92,  -110,  -110,  -110,
    -110,  -110,   -25,  -110,  -110
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const yytype_uint8 yytable[] =
{
      65,    53,    54,   132,    45,   166,   121,    56,    47,   144,
     145,   146,    96,   149,   170,    83,   147,   110,   152,    57,
     116,     1,     2,    48,    49,    51,    52,    97,    98,    99,
     112,    58,    59,   167,    60,    61,    62,   117,    75,   131,
     133,    76,    77,    78,    79,    84,    85,   111,   123,   124,
     125,   126,   127,    58,    59,    80,    60,    61,    62,    86,
      87,    88,   209,     3,   136,   137,   183,   187,   118,   196,
     137,   211,   141,   173,   185,   138,   200,   139,   203,     9,
      10,    11,    12,    13,    14,    15,   165,    16,     0,   114,
       2,   171,    18,    19,    20,    46,   120,     0,    21,     0,
       0,   168,     0,   163,     2,   175,     0,     0,   176,     0,
       0,   172,   202,   149,   201,   160,   161,   162,   204,   186,
       2,    86,    87,    88,   177,   179,    63,     0,     0,   121,
     181,    96,    96,    96,    96,    96,    96,    96,     0,     0,
      50,     1,     2,     0,     0,     0,   194,     0,   173,     0,
     189,     0,   190,   115,    58,    59,     0,    60,    61,    62,
      18,    19,    20,   195,     0,     0,    21,   164,     0,     0,
     198,   207,   199,   141,    18,    19,    20,     1,     2,   206,
      21,     0,     0,     3,   210,     5,     6,     7,     8,     0,
      18,    19,    20,     0,   192,     2,    21,     0,     0,     9,
      10,    11,    12,    13,    14,    15,     0,    16,     0,     0,
       0,     0,    18,    19,    20,     1,     2,   119,    21,     3,
       4,     5,     6,     7,     8,     0,     0,     0,    58,    59,
       0,    60,    61,    62,     0,     9,    10,    11,    12,    13,
      14,    15,     0,    16,     0,    17,     0,     0,    18,    19,
      20,     0,     0,     0,    21,     1,     2,     3,   193,     5,
       6,     7,     8,   134,     0,    18,    19,    20,     0,     0,
       0,    21,     0,     9,    10,    11,    12,    13,    14,    15,
       0,    16,     0,    17,    55,     0,    18,    19,    20,     1,
       2,   191,    21,     0,     0,     0,     0,     3,   140,     5,
       6,     7,     8,     0,     0,     0,    58,    59,     2,    60,
      61,    62,    89,     9,    10,    11,    12,    13,    14,    15,
       0,    16,     0,   135,     0,     0,    18,    19,    20,     1,
       2,     3,    21,     5,     6,     7,     8,    90,    91,    92,
      93,    94,    95,     0,     0,     0,     0,     9,    10,    11,
      12,    13,    14,    15,     0,    16,     0,    17,     0,     0,
      18,    19,    20,     1,     2,     0,    21,     0,     0,   205,
       0,     3,   128,     5,     6,     7,     8,     0,    18,    19,
      20,     0,     2,     0,    21,     0,     0,     9,    10,    11,
      12,    13,    14,    15,     0,    16,     0,    17,   178,     0,
      18,    19,    20,     1,     2,     3,    21,     5,     6,     7,
       8,     0,   148,     0,    58,    59,     0,    60,    61,    62,
       0,     9,    10,    11,    12,    13,    14,    15,     0,    16,
       0,    17,     0,     0,    18,    19,    20,     1,     2,     0,
      21,     0,     0,     0,     0,     3,   174,     5,     6,     7,
       8,     0,    18,    19,    20,     0,     0,     0,    21,     0,
       0,     9,    10,    11,    12,    13,    14,    15,     0,    16,
       0,     0,     0,     0,    18,    19,    20,   208,     0,     3,
      21,     5,     6,     7,     8,    66,    67,    68,    69,     0,
       0,    70,    71,    72,    73,     9,    10,    11,    12,    13,
      14,    15,    89,    16,     0,     0,     0,   184,    18,    19,
      20,     0,     0,     0,    21,    66,    67,    68,    69,     0,
      89,    70,    71,    72,    73,   188,     0,    90,    91,    92,
      93,    94,    95,     0,    66,    67,    68,    69,     0,   122,
      70,    71,    72,    73,     0,    90,    91,    92,    93,    94,
      95,     0,   180,     0,     0,     0,     0,     0,   169,    66,
      67,    68,    69,     0,   182,    70,    71,    72,    73,   197,
      66,    67,    68,    69,     0,     0,    70,    71,    72,    73,
     100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
      66,    67,    68,    69,     0,     0,    70,    71,    72,    73,
     153,   154,   155,   156,   157,   158,   159,    58,    59,     0,
      60,    61,    62
};

#define yypact_value_is_default(yystate) \
  ((yystate) == (-110))

#define yytable_value_is_error(yytable_value) \
  YYID (0)

static const yytype_int16 yycheck[] =
{
      25,    15,    16,    43,    80,    43,    55,    17,    68,    83,
      84,    85,    34,    87,     3,    14,    86,     3,    88,     0,
      45,     4,     5,     5,     6,     7,     8,    39,    40,    41,
      44,     6,     7,    71,     9,    10,    11,    47,    42,    64,
      80,    29,    30,    31,    32,    44,    45,    80,    58,    59,
      60,    61,    62,     6,     7,    43,     9,    10,    11,    15,
      16,    17,    80,    46,    74,    75,    43,    43,    50,    43,
      80,    69,    82,   122,   148,    75,   183,    80,   187,    62,
      63,    64,    65,    66,    67,    68,   111,    70,    -1,     4,
       5,    80,    75,    76,    77,     3,    71,    -1,    81,    -1,
      -1,   115,    -1,     4,     5,   130,    -1,    -1,   133,    -1,
      -1,   121,   186,   187,   184,    97,    98,    99,   188,    13,
       5,    15,    16,    17,   134,   135,    79,    -1,    -1,   178,
     140,   153,   154,   155,   156,   157,   158,   159,    -1,    -1,
       3,     4,     5,    -1,    -1,    -1,   171,    -1,   197,    -1,
     164,    -1,   166,    68,     6,     7,    -1,     9,    10,    11,
      75,    76,    77,   173,    -1,    -1,    81,    68,    -1,    -1,
     180,   196,   182,   183,    75,    76,    77,     4,     5,   193,
      81,    -1,    -1,    46,   209,    48,    49,    50,    51,    -1,
      75,    76,    77,    -1,     4,     5,    81,    -1,    -1,    62,
      63,    64,    65,    66,    67,    68,    -1,    70,    -1,    -1,
      -1,    -1,    75,    76,    77,     4,     5,    69,    81,    46,
      47,    48,    49,    50,    51,    -1,    -1,    -1,     6,     7,
      -1,     9,    10,    11,    -1,    62,    63,    64,    65,    66,
      67,    68,    -1,    70,    -1,    72,    -1,    -1,    75,    76,
      77,    -1,    -1,    -1,    81,     4,     5,    46,    68,    48,
      49,    50,    51,    12,    -1,    75,    76,    77,    -1,    -1,
      -1,    81,    -1,    62,    63,    64,    65,    66,    67,    68,
      -1,    70,    -1,    72,    73,    -1,    75,    76,    77,     4,
       5,    69,    81,    -1,    -1,    -1,    -1,    46,    13,    48,
      49,    50,    51,    -1,    -1,    -1,     6,     7,     5,     9,
      10,    11,     8,    62,    63,    64,    65,    66,    67,    68,
      -1,    70,    -1,    72,    -1,    -1,    75,    76,    77,     4,
       5,    46,    81,    48,    49,    50,    51,    33,    34,    35,
      36,    37,    38,    -1,    -1,    -1,    -1,    62,    63,    64,
      65,    66,    67,    68,    -1,    70,    -1,    72,    -1,    -1,
      75,    76,    77,     4,     5,    -1,    81,    -1,    -1,    69,
      -1,    46,    69,    48,    49,    50,    51,    -1,    75,    76,
      77,    -1,     5,    -1,    81,    -1,    -1,    62,    63,    64,
      65,    66,    67,    68,    -1,    70,    -1,    72,    73,    -1,
      75,    76,    77,     4,     5,    46,    81,    48,    49,    50,
      51,    -1,    13,    -1,     6,     7,    -1,     9,    10,    11,
      -1,    62,    63,    64,    65,    66,    67,    68,    -1,    70,
      -1,    72,    -1,    -1,    75,    76,    77,     4,     5,    -1,
      81,    -1,    -1,    -1,    -1,    46,    69,    48,    49,    50,
      51,    -1,    75,    76,    77,    -1,    -1,    -1,    81,    -1,
      -1,    62,    63,    64,    65,    66,    67,    68,    -1,    70,
      -1,    -1,    -1,    -1,    75,    76,    77,    69,    -1,    46,
      81,    48,    49,    50,    51,    19,    20,    21,    22,    -1,
      -1,    25,    26,    27,    28,    62,    63,    64,    65,    66,
      67,    68,     8,    70,    -1,    -1,    -1,    13,    75,    76,
      77,    -1,    -1,    -1,    81,    19,    20,    21,    22,    -1,
       8,    25,    26,    27,    28,    13,    -1,    33,    34,    35,
      36,    37,    38,    -1,    19,    20,    21,    22,    -1,    73,
      25,    26,    27,    28,    -1,    33,    34,    35,    36,    37,
      38,    -1,    12,    -1,    -1,    -1,    -1,    -1,    43,    19,
      20,    21,    22,    -1,    13,    25,    26,    27,    28,    73,
      19,    20,    21,    22,    -1,    -1,    25,    26,    27,    28,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
      19,    20,    21,    22,    -1,    -1,    25,    26,    27,    28,
      89,    90,    91,    92,    93,    94,    95,     6,     7,    -1,
       9,    10,    11
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     4,     5,    46,    47,    48,    49,    50,    51,    62,
      63,    64,    65,    66,    67,    68,    70,    72,    75,    76,
      77,    81,    83,    84,    85,    86,    89,    90,    91,    92,
      93,    99,   100,   103,   104,   105,   106,   107,   108,   109,
     111,   112,   113,   114,   116,    80,   108,    68,   106,   106,
       3,   106,   106,    85,    85,    73,    89,     0,     6,     7,
       9,    10,    11,    79,    87,   114,    19,    20,    21,    22,
      25,    26,    27,    28,    98,    42,    29,    30,    31,    32,
      43,    94,    97,    14,    44,    45,    15,    16,    17,     8,
      33,    34,    35,    36,    37,    38,   105,    39,    40,    41,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    61,
       3,    80,    85,   115,     4,    68,   114,    89,   106,    69,
      71,    98,    73,    89,    89,    89,    89,    89,    69,    88,
     110,   114,    43,    80,    12,    72,    89,    89,    91,    93,
      13,    89,    95,    96,   100,   100,   100,   103,    13,   100,
     101,   102,   103,   104,   104,   104,   104,   104,   104,   104,
     106,   106,   106,     4,    68,   114,    43,    71,    85,    43,
       3,    80,    89,    98,    69,   114,   114,    89,    73,    89,
      12,    89,    13,    43,    13,   100,    13,    43,    13,    85,
      85,    69,     4,    68,   114,    89,    43,    73,    89,    89,
      96,   103,   100,   102,   103,    69,    85,   114,    69,    80,
     114,    69
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  However,
   YYFAIL appears to be in use.  Nevertheless, it is formally deprecated
   in Bison 2.4.2's NEWS entry, where a plan to phase it out is
   discussed.  */

#define YYFAIL		goto yyerrlab
#if defined YYFAIL
  /* This is here to suppress warnings from the GCC cpp's
     -Wunused-macros.  Normally we don't worry about that warning, but
     some users do, and we want to make it easy for users to remove
     YYFAIL uses, which will produce warnings from Bison 2.5.  */
#endif

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (scanner, YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* This macro is provided for backward compatibility. */

#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (&yylval, YYLEX_PARAM)
#else
# define YYLEX yylex (&yylval, scanner)
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value, scanner); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, void * scanner)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep, scanner)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    void * scanner;
#endif
{
  if (!yyvaluep)
    return;
  YYUSE (scanner);
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, void * scanner)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep, scanner)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    void * scanner;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep, scanner);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule, void * scanner)
#else
static void
yy_reduce_print (yyvsp, yyrule, scanner)
    YYSTYPE *yyvsp;
    int yyrule;
    void * scanner;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       , scanner);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule, scanner); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  YYSIZE_T yysize1;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = 0;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - Assume YYFAIL is not used.  It's too flawed to consider.  See
       <http://lists.gnu.org/archive/html/bison-patches/2009-12/msg00024.html>
       for details.  YYERROR is fine as it does not invoke this
       function.
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                yysize1 = yysize + yytnamerr (0, yytname[yyx]);
                if (! (yysize <= yysize1
                       && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                  return 2;
                yysize = yysize1;
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  yysize1 = yysize + yystrlen (yyformat);
  if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
    return 2;
  yysize = yysize1;

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, void * scanner)
#else
static void
yydestruct (yymsg, yytype, yyvaluep, scanner)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
    void * scanner;
#endif
{
  YYUSE (yyvaluep);
  YYUSE (scanner);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void * scanner);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void * scanner)
#else
int
yyparse (scanner)
    void * scanner;
#endif
#endif
{
/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

    /* Number of syntax errors so far.  */
    int yynerrs;

    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

/* Line 1806 of yacc.c  */
#line 174 "xre_parse.yy"
    { }
    break;

  case 3:

/* Line 1806 of yacc.c  */
#line 176 "xre_parse.yy"
    { 
       // only comments
       hfst::xre::contains_only_comments = true;
       return 0;
     }
    break;

  case 4:

/* Line 1806 of yacc.c  */
#line 182 "xre_parse.yy"
    {
      // std::cerr << "regexp1:regexp2 end of expr \n"<< std::endl;
       // Symbols of form <foo> are not harmonized in xfst, that is why
       // they are escaped as @_<foo>_@ and need to be unescaped finally.  
       // hfst::xre::last_compiled = & hfst::xre::unescape_enclosing_angle_brackets($1)->minimize();
       hfst::xre::last_compiled = & (yyvsp[(1) - (2)].transducer)->minimize();
       (yyval.transducer) = hfst::xre::last_compiled;
       if (hfst::xre::allow_extra_text_at_end) {
         return 0;
       }
   }
    break;

  case 5:

/* Line 1806 of yacc.c  */
#line 193 "xre_parse.yy"
    {
   
        //std::cerr << "regexp1:regexp2\n"<< *$1 << std::endl; 
       // Symbols of form <foo> are not harmonized in xfst, that is why
       // they are escaped as @_<foo>_@ and need to be unescaped finally.  
        // hfst::xre::last_compiled = & hfst::xre::unescape_enclosing_angle_brackets($1)->minimize();
        hfst::xre::last_compiled = & (yyvsp[(1) - (1)].transducer)->minimize();
        (yyval.transducer) = hfst::xre::last_compiled;
   }
    break;

  case 6:

/* Line 1806 of yacc.c  */
#line 206 "xre_parse.yy"
    { 
            (yyval.transducer) = & (yyvsp[(1) - (1)].transducer)->minimize();
          //  std::cerr << "regexp2:replace \n"<< std::endl; 
         }
    break;

  case 7:

/* Line 1806 of yacc.c  */
#line 211 "xre_parse.yy"
    {
        if ((yyvsp[(1) - (3)].transducer)->has_flag_diacritics() && (yyvsp[(3) - (3)].transducer)->has_flag_diacritics())
          {
            if (! harmonize_flags_) {
                 hfst::xre::warn("warning: both composition arguments contain flag diacritics that are not harmonized\n");
            }
            else {
                (yyvsp[(1) - (3)].transducer)->harmonize_flag_diacritics(*(yyvsp[(3) - (3)].transducer));
            }
          }

         try {
            (yyval.transducer) = & (yyvsp[(1) - (3)].transducer)->compose(*(yyvsp[(3) - (3)].transducer), harmonize_).minimize();
         }
         catch (const FlagDiacriticsAreNotIdentitiesException & e)
             {
               xreerror("Error: flag diacritics must be identities in composition if flag-is-epsilon is ON.\n"
               "I.e. only FLAG:FLAG is allowed, not FLAG1:FLAG2, FLAG:bar or foo:FLAG\n"
               "Apply twosided flag-diacritics (tfd) before composition.\n");
               YYABORT;
             }
            delete (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 8:

/* Line 1806 of yacc.c  */
#line 234 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (3)].transducer)->cross_product(*(yyvsp[(3) - (3)].transducer));
            delete (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 9:

/* Line 1806 of yacc.c  */
#line 238 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (3)].transducer)->lenient_composition(*(yyvsp[(3) - (3)].transducer)).minimize();
            delete (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 10:

/* Line 1806 of yacc.c  */
#line 242 "xre_parse.yy"
    {
          try {
            (yyval.transducer) = hfst::xre::merge_first_to_second((yyvsp[(1) - (3)].transducer), (yyvsp[(3) - (3)].transducer));
          }
          catch (const TransducersAreNotAutomataException & e)
          {
            xreerror("Error: transducers must be automata in merge operation.");
            delete (yyvsp[(1) - (3)].transducer);
            delete (yyvsp[(3) - (3)].transducer);
            YYABORT;
          }
          delete (yyvsp[(1) - (3)].transducer);
       }
    break;

  case 11:

/* Line 1806 of yacc.c  */
#line 255 "xre_parse.yy"
    {
            (yyval.transducer) = hfst::xre::merge_first_to_second((yyvsp[(3) - (3)].transducer), (yyvsp[(1) - (3)].transducer));
            delete (yyvsp[(3) - (3)].transducer);
       }
    break;

  case 12:

/* Line 1806 of yacc.c  */
#line 260 "xre_parse.yy"
    {
            (yyvsp[(1) - (9)].transducer)->substitute(StringPair((yyvsp[(2) - (9)].label),(yyvsp[(4) - (9)].label)), StringPair((yyvsp[(6) - (9)].label),(yyvsp[(8) - (9)].label)));
            (yyval.transducer) = (yyvsp[(1) - (9)].transducer);
       }
    break;

  case 13:

/* Line 1806 of yacc.c  */
#line 264 "xre_parse.yy"
    {

            StringSet alpha = (yyvsp[(1) - (3)].transducer)->get_alphabet();
            if (hfst::xre::is_definition((yyvsp[(2) - (3)].label)))
            {
                hfst::xre::warn("warning: using definition as an ordinary label, cannot substitute\n");
                (yyval.transducer) = (yyvsp[(1) - (3)].transducer);
            }
            else if (alpha.find((yyvsp[(2) - (3)].label)) == alpha.end())
            {
                (yyval.transducer) = (yyvsp[(1) - (3)].transducer);
            }
            else
            {
                alpha = (yyvsp[(3) - (3)].transducer)->get_alphabet();

                StringPair tmp((yyvsp[(2) - (3)].label), (yyvsp[(2) - (3)].label));
                HfstTransducer * tmpTr = new HfstTransducer(*(yyvsp[(1) - (3)].transducer));

	        bool empty_replace_transducer=false;
	        HfstTransducer empty(hfst::xre::format);
	        if (empty.compare(*(yyvsp[(3) - (3)].transducer)))
	        {
                        empty_replace_transducer=true;
	        }	

	        if (empty_replace_transducer)
	        {
                        // substitute all transitions {b:a, a:b, b:b} with b:b
		        // as they will be removed anyway
		        hfst::xre::set_substitution_function_symbol((yyvsp[(2) - (3)].label));
		        tmpTr->substitute(&hfst::xre::substitution_function);
	        }	

                // `[ a:b, b, x y ]
                // substitute b with x | y
                tmpTr->substitute(tmp, *(yyvsp[(3) - (3)].transducer), false); // no harmonization

	        if (!empty_replace_transducer) 
                {
                        // a:b .o. b -> x | y
                        // [[a:b].i .o. b -> x | y].i - this is for cases when b is on left side

	                // build Replace transducer
                        HfstTransducerPair mappingPair(HfstTransducer((yyvsp[(2) - (3)].label), (yyvsp[(2) - (3)].label), hfst::xre::format), *(yyvsp[(3) - (3)].transducer));
                        HfstTransducerPairVector mappingPairVector;
                        mappingPairVector.push_back(mappingPair);
                        Rule rule(mappingPairVector);
                        HfstTransducer replaceTr(hfst::xre::format);
                        replaceTr = replace(rule, false);

                        // if we are replacing with flag diacritics, the rule must allow
                        // flags to be replaced with themselves
                        StringSet alpha = (yyvsp[(3) - (3)].transducer)->get_alphabet();
                        for (StringSet::const_iterator it = alpha.begin(); it != alpha.end(); it++)
                        {
                          if (FdOperation::is_diacritic(*it))
                          {
                            replaceTr.insert_freely(StringPair(*it, *it), false);
                          }
                        }
                        replaceTr.minimize();

                        tmpTr->compose(replaceTr).minimize();
                        tmpTr->invert().compose(replaceTr).invert();
	        }
            
                if (alpha.find((yyvsp[(2) - (3)].label)) == alpha.end())
                {
                  tmpTr->remove_from_alphabet((yyvsp[(2) - (3)].label));
                }
                tmpTr->minimize();
                (yyval.transducer) = tmpTr;
                delete((yyvsp[(1) - (3)].transducer), (yyvsp[(2) - (3)].label), (yyvsp[(3) - (3)].transducer));
            }
         }
    break;

  case 14:

/* Line 1806 of yacc.c  */
#line 342 "xre_parse.yy"
    { (yyval.transducer) = (yyvsp[(3) - (4)].transducer); }
    break;

  case 15:

/* Line 1806 of yacc.c  */
#line 343 "xre_parse.yy"
    { (yyval.label) = (yyvsp[(1) - (2)].label); }
    break;

  case 16:

/* Line 1806 of yacc.c  */
#line 344 "xre_parse.yy"
    {  (yyval.transducer) = (yyvsp[(1) - (2)].transducer);  }
    break;

  case 17:

/* Line 1806 of yacc.c  */
#line 346 "xre_parse.yy"
    { (yyval.transducer) = new HfstTransducer(hfst::xre::format); }
    break;

  case 18:

/* Line 1806 of yacc.c  */
#line 353 "xre_parse.yy"
    { }
    break;

  case 19:

/* Line 1806 of yacc.c  */
#line 355 "xre_parse.yy"
    {
            switch ( (yyvsp[(1) - (1)].replaceRuleVectorWithArrow)->first )
            {
               case E_REPLACE_RIGHT:
                 (yyval.transducer) = new HfstTransducer( replace( (yyvsp[(1) - (1)].replaceRuleVectorWithArrow)->second, false ) );
                 break;
               case E_OPTIONAL_REPLACE_RIGHT:
                 (yyval.transducer) = new HfstTransducer( replace( (yyvsp[(1) - (1)].replaceRuleVectorWithArrow)->second, true ) );
                 break;
              case E_REPLACE_LEFT:
                 (yyval.transducer) = new HfstTransducer( replace_left( (yyvsp[(1) - (1)].replaceRuleVectorWithArrow)->second, false ) );
                 break;
               case E_OPTIONAL_REPLACE_LEFT:
                 (yyval.transducer) = new HfstTransducer( replace_left( (yyvsp[(1) - (1)].replaceRuleVectorWithArrow)->second, true ) );
                 break;
               case E_RTL_LONGEST_MATCH:
                 (yyval.transducer) = new HfstTransducer( replace_rightmost_longest_match( (yyvsp[(1) - (1)].replaceRuleVectorWithArrow)->second ) );
                 break;
               case E_RTL_SHORTEST_MATCH:
                 (yyval.transducer) = new HfstTransducer( replace_rightmost_shortest_match((yyvsp[(1) - (1)].replaceRuleVectorWithArrow)->second) );
                 break;
               case E_LTR_LONGEST_MATCH:
                 (yyval.transducer) = new HfstTransducer( replace_leftmost_longest_match( (yyvsp[(1) - (1)].replaceRuleVectorWithArrow)->second ) );
                 break;
               case E_LTR_SHORTEST_MATCH:
                 (yyval.transducer) = new HfstTransducer( replace_leftmost_shortest_match( (yyvsp[(1) - (1)].replaceRuleVectorWithArrow)->second ) );
                 break;
               case E_REPLACE_RIGHT_MARKUP:
               default:
                xreerror("Unhandled arrow stuff I suppose");
                YYABORT;
                break;
            }
       
            delete (yyvsp[(1) - (1)].replaceRuleVectorWithArrow);
         }
    break;

  case 20:

/* Line 1806 of yacc.c  */
#line 394 "xre_parse.yy"
    {
           //std::cerr << "parallel_rules: parallel_rules ,, rule"<< std::endl;      
           if ((yyvsp[(3) - (3)].replaceRuleWithArrow)->first != (yyvsp[(1) - (3)].replaceRuleVectorWithArrow)->first)
           {
             xreerror("Replace type mismatch in parallel rules");
             YYABORT;
           }
            Rule tmpRule((yyvsp[(3) - (3)].replaceRuleWithArrow)->second);
            (yyvsp[(1) - (3)].replaceRuleVectorWithArrow)->second.push_back(tmpRule);
            (yyval.replaceRuleVectorWithArrow) =  new std::pair< ReplaceArrow, std::vector<Rule> > ((yyvsp[(3) - (3)].replaceRuleWithArrow)->first, (yyvsp[(1) - (3)].replaceRuleVectorWithArrow)->second);
            delete (yyvsp[(3) - (3)].replaceRuleWithArrow);
         }
    break;

  case 21:

/* Line 1806 of yacc.c  */
#line 407 "xre_parse.yy"
    {
         //std::cerr << "parallel_rules:rule"<< std::endl;        
            std::vector<Rule> * ruleVector = new std::vector<Rule>();
            ruleVector->push_back((yyvsp[(1) - (1)].replaceRuleWithArrow)->second);
            
            (yyval.replaceRuleVectorWithArrow) =  new std::pair< ReplaceArrow, std::vector<Rule> > ((yyvsp[(1) - (1)].replaceRuleWithArrow)->first, *ruleVector);
            delete (yyvsp[(1) - (1)].replaceRuleWithArrow);
         }
    break;

  case 22:

/* Line 1806 of yacc.c  */
#line 418 "xre_parse.yy"
    {
         // std::cerr << "rule: mapping_vector"<< std::endl;      
        // HfstTransducer allMappingsDisjuncted = disjunctVectorMembers($1->second);
         
         Rule rule( (yyvsp[(1) - (1)].mappingVectorWithArrow)->second );;
         (yyval.replaceRuleWithArrow) =  new std::pair< ReplaceArrow, Rule> ((yyvsp[(1) - (1)].mappingVectorWithArrow)->first, rule);
         delete (yyvsp[(1) - (1)].mappingVectorWithArrow);
      }
    break;

  case 23:

/* Line 1806 of yacc.c  */
#line 427 "xre_parse.yy"
    {
       //  std::cerr << "rule: mapping_vector contextsWM"<< std::endl;      
     //   HfstTransducer allMappingsDisjuncted = disjunctVectorMembers($1->second);
        
        Rule rule( (yyvsp[(1) - (2)].mappingVectorWithArrow)->second, (yyvsp[(2) - (2)].contextWithMark)->second, (yyvsp[(2) - (2)].contextWithMark)->first );
        (yyval.replaceRuleWithArrow) =  new std::pair< ReplaceArrow, Rule> ((yyvsp[(1) - (2)].mappingVectorWithArrow)->first, rule);
        delete (yyvsp[(1) - (2)].mappingVectorWithArrow), (yyvsp[(2) - (2)].contextWithMark);
      }
    break;

  case 24:

/* Line 1806 of yacc.c  */
#line 439 "xre_parse.yy"
    {
        // std::cerr << "mapping_vector : mapping_vector comma mapping"<< std::endl;      
         // check if new Arrow is the same as the first one

         if ((yyvsp[(1) - (3)].mappingVectorWithArrow)->first != (yyvsp[(3) - (3)].mappingWithArrow)->first)
         {
            hfst::xre::warn("Replace arrows should be the same. Calculated as if all replacements had the first arrow.");
            //exit(1);
         }
 
         (yyvsp[(1) - (3)].mappingVectorWithArrow)->second.push_back((yyvsp[(3) - (3)].mappingWithArrow)->second);
         (yyval.mappingVectorWithArrow) =  new std::pair< ReplaceArrow, HfstTransducerPairVector> ((yyvsp[(1) - (3)].mappingVectorWithArrow)->first, (yyvsp[(1) - (3)].mappingVectorWithArrow)->second);
         delete (yyvsp[(3) - (3)].mappingWithArrow); 
            
      }
    break;

  case 25:

/* Line 1806 of yacc.c  */
#line 456 "xre_parse.yy"
    {
         // std::cerr << "mapping_vector : mapping"<< std::endl;      
         HfstTransducerPairVector * mappingPairVector = new HfstTransducerPairVector();
         mappingPairVector->push_back( (yyvsp[(1) - (1)].mappingWithArrow)->second );
         (yyval.mappingVectorWithArrow) =  new std::pair< ReplaceArrow, HfstTransducerPairVector> ((yyvsp[(1) - (1)].mappingWithArrow)->first, * mappingPairVector);
         delete (yyvsp[(1) - (1)].mappingWithArrow); 
      }
    break;

  case 26:

/* Line 1806 of yacc.c  */
#line 468 "xre_parse.yy"
    {
	  hfst::xre::warn_about_special_symbols_in_replace((yyvsp[(1) - (3)].transducer));  
	  hfst::xre::warn_about_special_symbols_in_replace((yyvsp[(3) - (3)].transducer));  
          HfstTransducerPair mappingPair(*(yyvsp[(1) - (3)].transducer), *(yyvsp[(3) - (3)].transducer));
          (yyval.mappingWithArrow) =  new std::pair< ReplaceArrow, HfstTransducerPair> ((yyvsp[(2) - (3)].replaceArrow), mappingPair);

          delete (yyvsp[(1) - (3)].transducer), (yyvsp[(3) - (3)].transducer);
      }
    break;

  case 27:

/* Line 1806 of yacc.c  */
#line 477 "xre_parse.yy"
    {
          HfstTransducerPair marks(*(yyvsp[(3) - (5)].transducer), *(yyvsp[(5) - (5)].transducer));
          HfstTransducerPair tmpMappingPair(*(yyvsp[(1) - (5)].transducer), HfstTransducer(hfst::xre::format));
          HfstTransducerPair mappingPair = create_mapping_for_mark_up_replace( tmpMappingPair, marks );
          
          (yyval.mappingWithArrow) =  new std::pair< ReplaceArrow, HfstTransducerPair> ((yyvsp[(2) - (5)].replaceArrow), mappingPair);
          delete (yyvsp[(1) - (5)].transducer), (yyvsp[(3) - (5)].transducer), (yyvsp[(5) - (5)].transducer);
      }
    break;

  case 28:

/* Line 1806 of yacc.c  */
#line 486 "xre_parse.yy"
    {
          HfstTransducer epsilon(hfst::internal_epsilon, hfst::xre::format);
          HfstTransducerPair marks(*(yyvsp[(3) - (4)].transducer), epsilon);
          HfstTransducerPair tmpMappingPair(*(yyvsp[(1) - (4)].transducer), HfstTransducer(hfst::xre::format));
          HfstTransducerPair mappingPair = create_mapping_for_mark_up_replace( tmpMappingPair, marks );
                   
          (yyval.mappingWithArrow) =  new std::pair< ReplaceArrow, HfstTransducerPair> ((yyvsp[(2) - (4)].replaceArrow), mappingPair);
          delete (yyvsp[(1) - (4)].transducer), (yyvsp[(3) - (4)].transducer);
      }
    break;

  case 29:

/* Line 1806 of yacc.c  */
#line 496 "xre_parse.yy"
    {
          HfstTransducer epsilon(hfst::internal_epsilon, hfst::xre::format);
          HfstTransducerPair marks(epsilon, *(yyvsp[(4) - (4)].transducer));
          HfstTransducerPair tmpMappingPair(*(yyvsp[(1) - (4)].transducer), HfstTransducer(hfst::xre::format));
          HfstTransducerPair mappingPair = create_mapping_for_mark_up_replace( tmpMappingPair, marks );
          
          (yyval.mappingWithArrow) =  new std::pair< ReplaceArrow, HfstTransducerPair> ((yyvsp[(2) - (4)].replaceArrow), mappingPair);
          delete (yyvsp[(1) - (4)].transducer), (yyvsp[(4) - (4)].transducer);
      }
    break;

  case 30:

/* Line 1806 of yacc.c  */
#line 506 "xre_parse.yy"
    {
          HfstTransducer epsilon(hfst::internal_epsilon, hfst::xre::format);
          //HfstTransducer mappingTr(epsilon);
          //mappingTr.cross_product(*$4);
          HfstTransducerPair mappingPair(epsilon, *(yyvsp[(4) - (4)].transducer));
          
          (yyval.mappingWithArrow) =  new std::pair< ReplaceArrow, HfstTransducerPair> ((yyvsp[(3) - (4)].replaceArrow), mappingPair);
          delete (yyvsp[(4) - (4)].transducer);
      }
    break;

  case 31:

/* Line 1806 of yacc.c  */
#line 516 "xre_parse.yy"
    {
	  HfstTransducerPair mappingPair(*(yyvsp[(2) - (5)].transducer), *(yyvsp[(5) - (5)].transducer));
          (yyval.mappingWithArrow) =  new std::pair< ReplaceArrow, HfstTransducerPair> ((yyvsp[(4) - (5)].replaceArrow), mappingPair);
          delete (yyvsp[(2) - (5)].transducer), (yyvsp[(5) - (5)].transducer);
      }
    break;

  case 32:

/* Line 1806 of yacc.c  */
#line 523 "xre_parse.yy"
    {
          HfstTransducer epsilon(hfst::internal_epsilon, hfst::xre::format);
          HfstTransducerPair mappingPair(*(yyvsp[(1) - (4)].transducer), epsilon);
          
          (yyval.mappingWithArrow) =  new std::pair< ReplaceArrow, HfstTransducerPair> ((yyvsp[(2) - (4)].replaceArrow), mappingPair);
          delete (yyvsp[(1) - (4)].transducer);
      }
    break;

  case 33:

/* Line 1806 of yacc.c  */
#line 531 "xre_parse.yy"
    {
          HfstTransducerPair mappingPair(*(yyvsp[(1) - (5)].transducer), *(yyvsp[(4) - (5)].transducer));
          (yyval.mappingWithArrow) =  new std::pair< ReplaceArrow, HfstTransducerPair> ((yyvsp[(2) - (5)].replaceArrow), mappingPair);
          delete (yyvsp[(1) - (5)].transducer), (yyvsp[(4) - (5)].transducer);
      }
    break;

  case 34:

/* Line 1806 of yacc.c  */
#line 541 "xre_parse.yy"
    {       
         (yyval.contextWithMark) =  new std::pair< ReplaceType, HfstTransducerPairVector> ((yyvsp[(1) - (2)].replType), *(yyvsp[(2) - (2)].transducerPairVector));
         }
    break;

  case 35:

/* Line 1806 of yacc.c  */
#line 546 "xre_parse.yy"
    {
            HfstTransducerPairVector * ContextVector = new HfstTransducerPairVector();
            ContextVector->push_back(*(yyvsp[(1) - (1)].transducerPair));
            (yyval.transducerPairVector) = ContextVector;
            delete (yyvsp[(1) - (1)].transducerPair); 
         }
    break;

  case 36:

/* Line 1806 of yacc.c  */
#line 554 "xre_parse.yy"
    {
            (yyvsp[(1) - (3)].transducerPairVector)->push_back(*(yyvsp[(3) - (3)].transducerPair));
            (yyval.transducerPairVector) = (yyvsp[(1) - (3)].transducerPairVector);
            delete (yyvsp[(3) - (3)].transducerPair); 
         }
    break;

  case 37:

/* Line 1806 of yacc.c  */
#line 562 "xre_parse.yy"
    {
            if (hfst::xre::has_non_identity_pairs((yyvsp[(1) - (3)].transducer))) // if non-identity symbols present..
            {
              xreerror("Contexts need to be automata");
              YYABORT;
            }
            if (hfst::xre::has_non_identity_pairs((yyvsp[(3) - (3)].transducer))) // if non-identity symbols present..
            {
              xreerror("Contexts need to be automata");
              YYABORT;
            }
            
            HfstTransducer t1(*(yyvsp[(1) - (3)].transducer));
            HfstTransducer t2(*(yyvsp[(3) - (3)].transducer)); 

             if (hfst::xre::is_weighted())
             {
               hfst::xre::has_weight_been_zeroed=false;
               t1.transform_weights(&hfst::xre::zero_weights);
             }
             t1.minimize().prune_alphabet(false);

             if (hfst::xre::is_weighted())
             {
               t2.transform_weights(&hfst::xre::zero_weights);
               hfst::xre::has_weight_been_zeroed=false;
             }
             t2.minimize().prune_alphabet(false);

            (yyval.transducerPair) = new HfstTransducerPair(t1, t2);
            delete (yyvsp[(1) - (3)].transducer), (yyvsp[(3) - (3)].transducer); 
         }
    break;

  case 38:

/* Line 1806 of yacc.c  */
#line 595 "xre_parse.yy"
    {
            if (hfst::xre::has_non_identity_pairs((yyvsp[(1) - (2)].transducer))) // if non-identity symbols present..
            {
              xreerror("Contexts need to be automata");
              YYABORT;
            }

            HfstTransducer t1(*(yyvsp[(1) - (2)].transducer));
            
            if (hfst::xre::is_weighted())
            {
              hfst::xre::has_weight_been_zeroed=false;
              t1.transform_weights(&hfst::xre::zero_weights);
              hfst::xre::has_weight_been_zeroed=false;
            }
            t1.minimize().prune_alphabet(false);

            HfstTransducer epsilon(hfst::internal_epsilon, hfst::xre::format);            
            (yyval.transducerPair) = new HfstTransducerPair(t1, epsilon);
            delete (yyvsp[(1) - (2)].transducer); 
         }
    break;

  case 39:

/* Line 1806 of yacc.c  */
#line 617 "xre_parse.yy"
    {

            if (hfst::xre::has_non_identity_pairs((yyvsp[(2) - (2)].transducer))) // if non-identity symbols present..
            {
              xreerror("Contexts need to be automata");
              YYABORT;
            }
            
            HfstTransducer t1(*(yyvsp[(2) - (2)].transducer));

            if (hfst::xre::is_weighted())
            {
              hfst::xre::has_weight_been_zeroed=false;
              t1.transform_weights(&hfst::xre::zero_weights);
              hfst::xre::has_weight_been_zeroed=false;
            }
            t1.minimize().prune_alphabet(false);
             
            HfstTransducer epsilon(hfst::internal_epsilon, hfst::xre::format);
            (yyval.transducerPair) = new HfstTransducerPair(epsilon, t1);
            delete (yyvsp[(2) - (2)].transducer); 
         }
    break;

  case 40:

/* Line 1806 of yacc.c  */
#line 640 "xre_parse.yy"
    {
            HfstTransducer epsilon(hfst::internal_epsilon, hfst::xre::format);
            (yyval.transducerPair) = new HfstTransducerPair(epsilon, epsilon);
          }
    break;

  case 41:

/* Line 1806 of yacc.c  */
#line 646 "xre_parse.yy"
    {
            (yyval.replType) = REPL_UP;
         }
    break;

  case 42:

/* Line 1806 of yacc.c  */
#line 650 "xre_parse.yy"
    {
            (yyval.replType) = REPL_RIGHT;
         }
    break;

  case 43:

/* Line 1806 of yacc.c  */
#line 654 "xre_parse.yy"
    {
            (yyval.replType) = REPL_LEFT;
         }
    break;

  case 44:

/* Line 1806 of yacc.c  */
#line 658 "xre_parse.yy"
    {
            (yyval.replType) = REPL_DOWN;
         }
    break;

  case 45:

/* Line 1806 of yacc.c  */
#line 664 "xre_parse.yy"
    {
            (yyval.replaceArrow) = E_REPLACE_RIGHT;
         }
    break;

  case 46:

/* Line 1806 of yacc.c  */
#line 668 "xre_parse.yy"
    {
            (yyval.replaceArrow) = E_OPTIONAL_REPLACE_RIGHT;
         }
    break;

  case 47:

/* Line 1806 of yacc.c  */
#line 672 "xre_parse.yy"
    {
            (yyval.replaceArrow) = E_RTL_LONGEST_MATCH;
         }
    break;

  case 48:

/* Line 1806 of yacc.c  */
#line 676 "xre_parse.yy"
    {
            (yyval.replaceArrow) = E_RTL_SHORTEST_MATCH;
         }
    break;

  case 49:

/* Line 1806 of yacc.c  */
#line 680 "xre_parse.yy"
    {
            (yyval.replaceArrow) = E_LTR_LONGEST_MATCH;
         }
    break;

  case 50:

/* Line 1806 of yacc.c  */
#line 684 "xre_parse.yy"
    {
            (yyval.replaceArrow) = E_LTR_SHORTEST_MATCH;
         }
    break;

  case 51:

/* Line 1806 of yacc.c  */
#line 688 "xre_parse.yy"
    {
        	 (yyval.replaceArrow) =  E_REPLACE_LEFT;
         }
    break;

  case 52:

/* Line 1806 of yacc.c  */
#line 692 "xre_parse.yy"
    {
        	 (yyval.replaceArrow) = E_OPTIONAL_REPLACE_LEFT;
         }
    break;

  case 53:

/* Line 1806 of yacc.c  */
#line 698 "xre_parse.yy"
    { }
    break;

  case 54:

/* Line 1806 of yacc.c  */
#line 699 "xre_parse.yy"
    {
            xreerror("No shuffle");
            //$$ = $1;
            delete (yyvsp[(3) - (3)].transducer);
            YYABORT;
        }
    break;

  case 55:

/* Line 1806 of yacc.c  */
#line 705 "xre_parse.yy"
    {
            (yyval.transducer) = new HfstTransducer( before (*(yyvsp[(1) - (3)].transducer), *(yyvsp[(3) - (3)].transducer)) );
            delete (yyvsp[(1) - (3)].transducer), (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 56:

/* Line 1806 of yacc.c  */
#line 709 "xre_parse.yy"
    {
            (yyval.transducer) = new HfstTransducer( after (*(yyvsp[(1) - (3)].transducer), *(yyvsp[(3) - (3)].transducer)) );
            delete (yyvsp[(1) - (3)].transducer), (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 57:

/* Line 1806 of yacc.c  */
#line 716 "xre_parse.yy"
    { }
    break;

  case 58:

/* Line 1806 of yacc.c  */
#line 718 "xre_parse.yy"
    {
            (yyval.transducer) = new HfstTransducer( restriction(*(yyvsp[(1) - (3)].transducer), *(yyvsp[(3) - (3)].transducerPairVector)) ) ;
            delete (yyvsp[(1) - (3)].transducer);
            delete (yyvsp[(3) - (3)].transducerPairVector);
        }
    break;

  case 59:

/* Line 1806 of yacc.c  */
#line 724 "xre_parse.yy"
    {
            xreerror("No Arrows");
            //$$ = $1;
            delete (yyvsp[(3) - (5)].transducer);
            delete (yyvsp[(5) - (5)].transducer);
            YYABORT;
        }
    break;

  case 60:

/* Line 1806 of yacc.c  */
#line 732 "xre_parse.yy"
    {
            xreerror("No Arrows");
            //$$ = $1;
            delete (yyvsp[(3) - (5)].transducer);
            delete (yyvsp[(5) - (5)].transducer);
            YYABORT;
        }
    break;

  case 61:

/* Line 1806 of yacc.c  */
#line 742 "xre_parse.yy"
    {
            HfstTransducerPairVector * ContextVector = new HfstTransducerPairVector();
            ContextVector->push_back(*(yyvsp[(1) - (1)].transducerPair));
            (yyval.transducerPairVector) = ContextVector;
            delete (yyvsp[(1) - (1)].transducerPair); 
         }
    break;

  case 62:

/* Line 1806 of yacc.c  */
#line 750 "xre_parse.yy"
    {
            (yyvsp[(1) - (3)].transducerPairVector)->push_back(*(yyvsp[(3) - (3)].transducerPair));
            (yyval.transducerPairVector) = (yyvsp[(1) - (3)].transducerPairVector);
            delete (yyvsp[(3) - (3)].transducerPair); 
         }
    break;

  case 63:

/* Line 1806 of yacc.c  */
#line 759 "xre_parse.yy"
    {
            (yyval.transducerPair) = new HfstTransducerPair(*(yyvsp[(1) - (3)].transducer), *(yyvsp[(3) - (3)].transducer));
            delete (yyvsp[(1) - (3)].transducer), (yyvsp[(3) - (3)].transducer); 
         }
    break;

  case 64:

/* Line 1806 of yacc.c  */
#line 764 "xre_parse.yy"
    {
           // std::cerr << "Mapping: \n" << *$1  << std::endl;
            
            HfstTransducer epsilon(hfst::internal_epsilon, hfst::xre::format);
            
           // std::cerr << "Epsilon: \n" << epsilon  << std::endl;
            (yyval.transducerPair) = new HfstTransducerPair(*(yyvsp[(1) - (2)].transducer), epsilon);
            delete (yyvsp[(1) - (2)].transducer); 
         }
    break;

  case 65:

/* Line 1806 of yacc.c  */
#line 774 "xre_parse.yy"
    {
            HfstTransducer epsilon(hfst::internal_epsilon, hfst::xre::format);
            (yyval.transducerPair) = new HfstTransducerPair(epsilon, *(yyvsp[(2) - (2)].transducer));
            delete (yyvsp[(2) - (2)].transducer); 
         }
    break;

  case 66:

/* Line 1806 of yacc.c  */
#line 780 "xre_parse.yy"
    {
            HfstTransducer empty(hfst::xre::format);
            (yyval.transducerPair) = new HfstTransducerPair(empty, empty);
         }
    break;

  case 67:

/* Line 1806 of yacc.c  */
#line 787 "xre_parse.yy"
    { }
    break;

  case 68:

/* Line 1806 of yacc.c  */
#line 788 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (3)].transducer)->disjunct(*(yyvsp[(3) - (3)].transducer), harmonize_);
            delete (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 69:

/* Line 1806 of yacc.c  */
#line 792 "xre_parse.yy"
    {
        // std::cerr << "Intersection: \n"  << std::endl;
            (yyval.transducer) = & (yyvsp[(1) - (3)].transducer)->intersect(*(yyvsp[(3) - (3)].transducer), harmonize_).minimize().prune_alphabet(false);
            delete (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 70:

/* Line 1806 of yacc.c  */
#line 797 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (3)].transducer)->subtract(*(yyvsp[(3) - (3)].transducer), harmonize_).prune_alphabet(false);
            delete (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 71:

/* Line 1806 of yacc.c  */
#line 801 "xre_parse.yy"
    {
            xreerror("No upper minus");
            //$$ = $1;
            delete (yyvsp[(3) - (3)].transducer);
            YYABORT;
        }
    break;

  case 72:

/* Line 1806 of yacc.c  */
#line 807 "xre_parse.yy"
    {
            xreerror("No lower minus");
            //$$ = $1;
            delete (yyvsp[(3) - (3)].transducer);
            YYABORT;
        }
    break;

  case 73:

/* Line 1806 of yacc.c  */
#line 813 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (3)].transducer)->priority_union(*(yyvsp[(3) - (3)].transducer));
            delete (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 74:

/* Line 1806 of yacc.c  */
#line 817 "xre_parse.yy"
    {
            HfstTransducer* left = new HfstTransducer(*(yyvsp[(1) - (3)].transducer));
            HfstTransducer* right =  new HfstTransducer(*(yyvsp[(3) - (3)].transducer));
            right->invert();
            left->invert();
            (yyval.transducer) = & (left->priority_union(*right).invert());
            delete (yyvsp[(1) - (3)].transducer), (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 75:

/* Line 1806 of yacc.c  */
#line 827 "xre_parse.yy"
    { }
    break;

  case 76:

/* Line 1806 of yacc.c  */
#line 828 "xre_parse.yy"
    { 
        (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->concatenate(*(yyvsp[(2) - (2)].transducer), harmonize_);
        delete (yyvsp[(2) - (2)].transducer);
        }
    break;

  case 77:

/* Line 1806 of yacc.c  */
#line 834 "xre_parse.yy"
    { }
    break;

  case 78:

/* Line 1806 of yacc.c  */
#line 835 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (3)].transducer)->insert_freely(*(yyvsp[(3) - (3)].transducer), false); // no harmonization
            delete (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 79:

/* Line 1806 of yacc.c  */
#line 839 "xre_parse.yy"
    {
            xreerror("No ignoring internally");
            //$$ = $1;
            delete (yyvsp[(3) - (3)].transducer);
            YYABORT;
        }
    break;

  case 80:

/* Line 1806 of yacc.c  */
#line 845 "xre_parse.yy"
    {
            xreerror("No left quotient");
            //$$ = $1;
            delete (yyvsp[(3) - (3)].transducer);
            YYABORT;
        }
    break;

  case 81:

/* Line 1806 of yacc.c  */
#line 853 "xre_parse.yy"
    { }
    break;

  case 82:

/* Line 1806 of yacc.c  */
#line 854 "xre_parse.yy"
    {
       		// TODO: forbid pair complement (ie ~a:b)
       		HfstTransducer complement = HfstTransducer::identity_pair( hfst::xre::format );
       		complement.repeat_star().minimize();
       		complement.subtract(*(yyvsp[(2) - (2)].transducer)).prune_alphabet(false);
       		(yyval.transducer) = new HfstTransducer(complement);
   			delete (yyvsp[(2) - (2)].transducer);
        }
    break;

  case 83:

/* Line 1806 of yacc.c  */
#line 862 "xre_parse.yy"
    {
            // std::cerr << "Containment: \n" << std::endl;
            if (hfst::xre::has_non_identity_pairs((yyvsp[(2) - (2)].transducer))) // if non-identity symbols present..
            {
              hfst::xre::warn("warning: using transducer that is non an automaton in containment\n");
              (yyval.transducer) = hfst::xre::contains((yyvsp[(2) - (2)].transducer)); // ..resort to simple containment
            }
            else
            {
              (yyval.transducer) = hfst::xre::contains_with_weight((yyvsp[(2) - (2)].transducer), 0);
            }
            delete (yyvsp[(2) - (2)].transducer);
        }
    break;

  case 84:

/* Line 1806 of yacc.c  */
#line 875 "xre_parse.yy"
    {
            // std::cerr << "Containment: \n" << std::endl;
            if (hfst::xre::has_non_identity_pairs((yyvsp[(3) - (3)].transducer))) // if non-identity symbols present..
            {
              xreerror("Containment with weight only works with automata");
              YYABORT;
            }
            (yyval.transducer) = hfst::xre::contains_with_weight((yyvsp[(3) - (3)].transducer), (yyvsp[(2) - (3)].weight));
            delete (yyvsp[(3) - (3)].transducer);
        }
    break;

  case 85:

/* Line 1806 of yacc.c  */
#line 885 "xre_parse.yy"
    {
            //std::cerr << "Contain 1 \n"<< std::endl;

            (yyval.transducer) = hfst::xre::contains_once((yyvsp[(2) - (2)].transducer));
            delete (yyvsp[(2) - (2)].transducer);
        }
    break;

  case 86:

/* Line 1806 of yacc.c  */
#line 891 "xre_parse.yy"
    {
            (yyval.transducer) = hfst::xre::contains_once_optional((yyvsp[(2) - (2)].transducer));
            delete (yyvsp[(2) - (2)].transducer);
        }
    break;

  case 87:

/* Line 1806 of yacc.c  */
#line 897 "xre_parse.yy"
    { }
    break;

  case 88:

/* Line 1806 of yacc.c  */
#line 898 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->repeat_star();
        }
    break;

  case 89:

/* Line 1806 of yacc.c  */
#line 901 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->repeat_plus();
        }
    break;

  case 90:

/* Line 1806 of yacc.c  */
#line 904 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->reverse();
        }
    break;

  case 91:

/* Line 1806 of yacc.c  */
#line 907 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->invert();
        }
    break;

  case 92:

/* Line 1806 of yacc.c  */
#line 910 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->input_project();
        }
    break;

  case 93:

/* Line 1806 of yacc.c  */
#line 913 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->output_project();
        }
    break;

  case 94:

/* Line 1806 of yacc.c  */
#line 916 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->repeat_n((yyvsp[(2) - (2)].value));
        }
    break;

  case 95:

/* Line 1806 of yacc.c  */
#line 919 "xre_parse.yy"
    {
            //std::cerr << "value is ::::: \n"<< $2 << std::endl; 
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->repeat_n_plus((yyvsp[(2) - (2)].value)+1);
        }
    break;

  case 96:

/* Line 1806 of yacc.c  */
#line 923 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->repeat_n_minus((yyvsp[(2) - (2)].value)-1);
        }
    break;

  case 97:

/* Line 1806 of yacc.c  */
#line 926 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->repeat_n_to_k((yyvsp[(2) - (2)].values)[0], (yyvsp[(2) - (2)].values)[1]);
            free((yyvsp[(2) - (2)].values));
        }
    break;

  case 98:

/* Line 1806 of yacc.c  */
#line 932 "xre_parse.yy"
    { }
    break;

  case 99:

/* Line 1806 of yacc.c  */
#line 933 "xre_parse.yy"
    {
            HfstTransducer* any = new HfstTransducer(hfst::internal_identity,
                                        hfst::xre::format);
            (yyval.transducer) = & ( any->subtract(*(yyvsp[(2) - (2)].transducer)));
            delete (yyvsp[(2) - (2)].transducer);
        }
    break;

  case 100:

/* Line 1806 of yacc.c  */
#line 948 "xre_parse.yy"
    { }
    break;

  case 101:

/* Line 1806 of yacc.c  */
#line 949 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(2) - (3)].transducer)->minimize();
        }
    break;

  case 102:

/* Line 1806 of yacc.c  */
#line 953 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(2) - (7)].transducer)->cross_product(*(yyvsp[(6) - (7)].transducer));
            delete (yyvsp[(6) - (7)].transducer);
        }
    break;

  case 103:

/* Line 1806 of yacc.c  */
#line 958 "xre_parse.yy"
    {
     	    HfstTransducer * tmp = hfst::xre::xfst_curly_label_to_transducer((yyvsp[(5) - (5)].label),(yyvsp[(5) - (5)].label));
            free((yyvsp[(5) - (5)].label));
            (yyval.transducer) = & (yyvsp[(2) - (5)].transducer)->cross_product(*tmp);
            delete tmp;
        }
    break;

  case 104:

/* Line 1806 of yacc.c  */
#line 965 "xre_parse.yy"
    {
     	    HfstTransducer * tmp = hfst::xre::xfst_curly_label_to_transducer((yyvsp[(1) - (5)].label),(yyvsp[(1) - (5)].label));
            free((yyvsp[(1) - (5)].label));
            (yyval.transducer) = & (yyvsp[(4) - (5)].transducer)->cross_product(*tmp);
            delete tmp;
        }
    break;

  case 105:

/* Line 1806 of yacc.c  */
#line 972 "xre_parse.yy"
    {
            HfstTransducer * tmp = hfst::xre::expand_definition((yyvsp[(5) - (5)].label));
            free((yyvsp[(5) - (5)].label));
            (yyval.transducer) = & (yyvsp[(2) - (5)].transducer)->cross_product(*tmp);
            delete tmp;
        }
    break;

  case 106:

/* Line 1806 of yacc.c  */
#line 979 "xre_parse.yy"
    {
            (yyval.transducer) = hfst::xre::expand_definition((yyvsp[(1) - (5)].label));
            free((yyvsp[(1) - (5)].label));
            (yyval.transducer) = & (yyval.transducer)->cross_product(*(yyvsp[(4) - (5)].transducer));
            delete (yyvsp[(4) - (5)].transducer);
        }
    break;

  case 107:

/* Line 1806 of yacc.c  */
#line 985 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(2) - (4)].transducer)->set_final_weights((yyvsp[(4) - (4)].weight), true).minimize();
        }
    break;

  case 108:

/* Line 1806 of yacc.c  */
#line 988 "xre_parse.yy"
    {
            (yyval.transducer) = & (yyvsp[(2) - (3)].transducer)->optionalize();
        }
    break;

  case 109:

/* Line 1806 of yacc.c  */
#line 994 "xre_parse.yy"
    {
            if (strcmp((yyvsp[(1) - (1)].label), hfst::internal_unknown.c_str()) == 0)
              {
                (yyval.transducer) = new HfstTransducer(hfst::internal_identity, hfst::xre::format);
              }
            else
              {
                (yyval.transducer) = new HfstTransducer((yyvsp[(1) - (1)].label), (yyvsp[(1) - (1)].label), hfst::xre::format);
              }
            free((yyvsp[(1) - (1)].label));
        }
    break;

  case 110:

/* Line 1806 of yacc.c  */
#line 1005 "xre_parse.yy"
    {
            HfstTransducer * tmp ;
            if (strcmp((yyvsp[(2) - (2)].label), hfst::internal_unknown.c_str()) == 0)
              {
                 tmp = new HfstTransducer(hfst::internal_identity, hfst::xre::format);
              }
            else
              {
                 tmp = new HfstTransducer((yyvsp[(2) - (2)].label), (yyvsp[(2) - (2)].label), hfst::xre::format);
              }

            (yyvsp[(1) - (2)].transducer)->disjunct(*tmp, false); // do not harmonize
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->minimize();
            delete (yyvsp[(2) - (2)].label), tmp; 
            }
    break;

  case 111:

/* Line 1806 of yacc.c  */
#line 1022 "xre_parse.yy"
    { }
    break;

  case 112:

/* Line 1806 of yacc.c  */
#line 1023 "xre_parse.yy"
    { 
            (yyval.transducer) = & (yyvsp[(1) - (2)].transducer)->set_final_weights((yyvsp[(2) - (2)].weight), true);
        }
    break;

  case 113:

/* Line 1806 of yacc.c  */
#line 1026 "xre_parse.yy"
    {
            try {
              hfst::HfstInputStream instream((yyvsp[(1) - (1)].label));
              (yyval.transducer) = new HfstTransducer(instream);
              instream.close();
              free((yyvsp[(1) - (1)].label));
            }
            catch (const HfstException & e) {
              (void) e; // todo handle the exception
              char msg [256];
              sprintf(msg, "Error reading transducer file '%s'.", (yyvsp[(1) - (1)].label));
              xreerror(msg);
              YYABORT;
            }
        }
    break;

  case 114:

/* Line 1806 of yacc.c  */
#line 1041 "xre_parse.yy"
    {
            FILE * f = NULL;
            f = fopen((yyvsp[(1) - (1)].label), "r");
            if (f == NULL) {
              xreerror("File cannot be opened.\n");
              YYABORT;
            }
            else {
              HfstBasicTransducer tmp;
              HfstTokenizer tok;
              char line [1000];

              while( fgets(line, 1000, f) != NULL )
              {
                hfst::xre::strip_newline(line);
                StringPairVector spv = tok.tokenize(line);
                tmp.disjunct(spv, 0);
              }
              fclose(f);
              HfstTransducer * retval = new HfstTransducer(tmp, hfst::xre::format); 
              retval->minimize();
              (yyval.transducer) = retval;
            }
        }
    break;

  case 115:

/* Line 1806 of yacc.c  */
#line 1065 "xre_parse.yy"
    {
            FILE * f = NULL;
            f = fopen((yyvsp[(1) - (1)].label), "r");
            if (f == NULL) {
              xreerror("File cannot be opened.\n");
              YYABORT;
            }
            else {
              HfstTokenizer tok;
              HfstBasicTransducer tmp;
              char line [1000];

              while( fgets(line, 1000, f) != NULL )
              {
                hfst::xre::strip_newline(line);
                StringPairVector spv = HfstTokenizer::tokenize_space_separated(line);
                tmp.disjunct(spv, 0);
              }
              fclose(f);
              HfstTransducer * retval = new HfstTransducer(tmp, hfst::xre::format); 
              retval->minimize();
              (yyval.transducer) = retval;
            }
        }
    break;

  case 116:

/* Line 1806 of yacc.c  */
#line 1089 "xre_parse.yy"
    {
            FILE * f = NULL;
            f = fopen((yyvsp[(1) - (1)].label), "r");
            if (f == NULL) {
              xreerror("File cannot be opened.\n");
              YYABORT;
            }
            else {
              try {
                unsigned int linecount = 0;
                HfstBasicTransducer tmp = HfstBasicTransducer::read_in_prolog_format(f, linecount);
                fclose(f);
                HfstTransducer * retval = new HfstTransducer(tmp, hfst::xre::format);
                retval->minimize();
                (yyval.transducer) = retval;
              }
              catch (const HfstException & e) {
                (void) e; // todo handle the exception
                fclose(f);
                xreerror("Error reading prolog file.\n");
                YYABORT;
              }
            }
        }
    break;

  case 117:

/* Line 1806 of yacc.c  */
#line 1113 "xre_parse.yy"
    {
            FILE * f = NULL;
            f = fopen((yyvsp[(1) - (1)].label), "r");
            if (f == NULL) {
              xreerror("File cannot be opened.\n");
              fclose(f);
              YYABORT;
            }
            else {
              fclose(f);
              // read the regex in a string
              std::ifstream ifs((yyvsp[(1) - (1)].label));
              std::stringstream buffer;
              buffer << ifs.rdbuf();
              char * regex_string = strdup(buffer.str().c_str());

              // create a new scanner for evaluating the regex
              yyscan_t scanner;
              xrelex_init(&scanner);
              YY_BUFFER_STATE bs = xre_scan_string(regex_string, scanner);

              unsigned int chars_read = hfst::xre::cr;
              hfst::xre::cr = 0;

              int parse_retval = xreparse(scanner);

              xre_delete_buffer(bs,scanner);
              xrelex_destroy(scanner);

              free(regex_string);

              hfst::xre::cr = chars_read;

              (yyval.transducer) = hfst::xre::last_compiled;

              if (parse_retval != 0)
              {
                xreerror("Error parsing regex.\n");
                YYABORT;
              }
            }
        }
    break;

  case 118:

/* Line 1806 of yacc.c  */
#line 1157 "xre_parse.yy"
    {
        if (strcmp((yyvsp[(1) - (1)].label), hfst::internal_unknown.c_str()) == 0)
          {
            (yyval.transducer) = new HfstTransducer(hfst::internal_identity, hfst::xre::format);
          }
        else
          {
            // HfstTransducer * tmp = new HfstTransducer($1, hfst::xre::format);
	    // $$ = hfst::xre::expand_definition(tmp, $1);
            (yyval.transducer) = hfst::xre::expand_definition((yyvsp[(1) - (1)].label));
          }
        free((yyvsp[(1) - (1)].label));
     }
    break;

  case 119:

/* Line 1806 of yacc.c  */
#line 1171 "xre_parse.yy"
    {
     	(yyval.transducer) = hfst::xre::xfst_label_to_transducer((yyvsp[(1) - (3)].label),(yyvsp[(3) - (3)].label));
        free((yyvsp[(1) - (3)].label));
        free((yyvsp[(3) - (3)].label));
     }
    break;

  case 120:

/* Line 1806 of yacc.c  */
#line 1176 "xre_parse.yy"
    {
        (yyval.transducer) = hfst::xre::xfst_label_to_transducer((yyvsp[(1) - (3)].label),(yyvsp[(1) - (3)].label));
        free((yyvsp[(1) - (3)].label));
        HfstTransducer * tmp = hfst::xre::xfst_curly_label_to_transducer((yyvsp[(3) - (3)].label),(yyvsp[(3) - (3)].label));
        free((yyvsp[(3) - (3)].label));
        (yyval.transducer) = & (yyval.transducer)->cross_product(*tmp);
        delete tmp;
     }
    break;

  case 121:

/* Line 1806 of yacc.c  */
#line 1184 "xre_parse.yy"
    {
        HfstTransducer * tmp = hfst::xre::xfst_label_to_transducer((yyvsp[(3) - (3)].label),(yyvsp[(3) - (3)].label));
        free((yyvsp[(3) - (3)].label));
        (yyval.transducer) = hfst::xre::xfst_curly_label_to_transducer((yyvsp[(1) - (3)].label),(yyvsp[(1) - (3)].label));
        free((yyvsp[(1) - (3)].label));
        (yyval.transducer) = & (yyval.transducer)->cross_product(*tmp);
        delete tmp;
     }
    break;

  case 122:

/* Line 1806 of yacc.c  */
#line 1192 "xre_parse.yy"
    {
     	(yyval.transducer) = hfst::xre::xfst_curly_label_to_transducer((yyvsp[(1) - (1)].label),(yyvsp[(1) - (1)].label));
        free((yyvsp[(1) - (1)].label));
     }
    break;

  case 123:

/* Line 1806 of yacc.c  */
#line 1196 "xre_parse.yy"
    {
     	(yyval.transducer) = hfst::xre::xfst_curly_label_to_transducer((yyvsp[(1) - (3)].label),(yyvsp[(3) - (3)].label));
        free((yyvsp[(1) - (3)].label));
	free((yyvsp[(3) - (3)].label));
     }
    break;

  case 124:

/* Line 1806 of yacc.c  */
#line 1202 "xre_parse.yy"
    {
            if (! hfst::xre::is_valid_function_call((yyvsp[(1) - (3)].label), (yyvsp[(2) - (3)].transducerVector))) {
              return EXIT_FAILURE;
            }
            else {
              // create a new scanner for evaluating the function
              yyscan_t scanner;
              xrelex_init(&scanner);
              YY_BUFFER_STATE bs = xre_scan_string(hfst::xre::get_function_xre((yyvsp[(1) - (3)].label)),scanner);

              // define special variables so that function arguments get the values given in regexp list
              if (! hfst::xre::define_function_args((yyvsp[(1) - (3)].label), (yyvsp[(2) - (3)].transducerVector)))
              {
                xreerror("Could not define function args.\n");  // TODO: more informative message
                YYABORT;
              }

              // if we are scanning a function definition for argument symbols, 
              // do not include the characters read when evaluating functions inside it 
              unsigned int chars_read = hfst::xre::cr;

              int parse_retval = xreparse(scanner);

              hfst::xre::cr = chars_read;
              hfst::xre::undefine_function_args((yyvsp[(1) - (3)].label));

              xre_delete_buffer(bs,scanner);
              xrelex_destroy(scanner);

              (yyval.transducer) = hfst::xre::last_compiled;

              if (parse_retval != 0)
              {
                YYABORT;
              }
            }
        }
    break;

  case 127:

/* Line 1806 of yacc.c  */
#line 1253 "xre_parse.yy"
    {
       // Symbols of form <foo> are not harmonized in xfst, that is why
       // they need to be escaped as @_<foo>_@.
       // $$ = hfst::xre::escape_enclosing_angle_brackets($1); 
       hfst::xre::warn_about_hfst_special_symbol((yyvsp[(1) - (1)].label));
       hfst::xre::warn_about_xfst_special_symbol((yyvsp[(1) - (1)].label));
       (yyval.label) = (yyvsp[(1) - (1)].label); 
     }
    break;

  case 128:

/* Line 1806 of yacc.c  */
#line 1261 "xre_parse.yy"
    {
        (yyval.label) = strdup(hfst::internal_epsilon.c_str());
     }
    break;

  case 129:

/* Line 1806 of yacc.c  */
#line 1264 "xre_parse.yy"
    {
        (yyval.label) = strdup(hfst::internal_unknown.c_str());
     }
    break;

  case 130:

/* Line 1806 of yacc.c  */
#line 1267 "xre_parse.yy"
    {
        (yyval.label) = strdup("@#@");
     }
    break;

  case 131:

/* Line 1806 of yacc.c  */
#line 1272 "xre_parse.yy"
    { 
       (yyval.transducerVector)->push_back(*((yyvsp[(3) - (3)].transducer)));
       delete (yyvsp[(3) - (3)].transducer); 
     }
    break;

  case 132:

/* Line 1806 of yacc.c  */
#line 1276 "xre_parse.yy"
    { 
       (yyval.transducerVector) = new hfst::HfstTransducerVector();
       (yyval.transducerVector)->push_back(*((yyvsp[(1) - (1)].transducer))); 
       delete (yyvsp[(1) - (1)].transducer);
     }
    break;

  case 133:

/* Line 1806 of yacc.c  */
#line 1283 "xre_parse.yy"
    {
        (yyval.label) = strdup((yyvsp[(1) - (1)].label));
    }
    break;



/* Line 1806 of yacc.c  */
#line 3676 "xre_parse.cc"
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (scanner, YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (scanner, yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval, scanner);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp, scanner);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (scanner, YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, scanner);
    }
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp, scanner);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 2067 of yacc.c  */
#line 1287 "xre_parse.yy"



