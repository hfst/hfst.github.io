/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     WEIGHT = 258,
     END_OF_WEIGHTED_EXPRESSION = 259,
     CHARACTER_RANGE = 260,
     MERGE_LEFT_ARROW = 261,
     MERGE_RIGHT_ARROW = 262,
     INTERSECTION = 263,
     LENIENT_COMPOSITION = 264,
     COMPOSITION = 265,
     CROSS_PRODUCT = 266,
     MARKUP_MARKER = 267,
     CENTER_MARKER = 268,
     AFTER = 269,
     BEFORE = 270,
     SHUFFLE = 271,
     LEFT_RESTRICTION = 272,
     LEFT_RIGHT_ARROW = 273,
     RIGHT_ARROW = 274,
     LEFT_ARROW = 275,
     LTR_SHORTEST_MATCH = 276,
     LTR_LONGEST_MATCH = 277,
     RTL_SHORTEST_MATCH = 278,
     RTL_LONGEST_MATCH = 279,
     OPTIONAL_REPLACE_LEFT_RIGHT = 280,
     REPLACE_LEFT_RIGHT = 281,
     OPTIONAL_REPLACE_LEFT = 282,
     OPTIONAL_REPLACE_RIGHT = 283,
     REPLACE_LEFT = 284,
     REPLACE_RIGHT = 285,
     REPLACE_CONTEXT_LL = 286,
     REPLACE_CONTEXT_UL = 287,
     REPLACE_CONTEXT_LU = 288,
     REPLACE_CONTEXT_UU = 289,
     LOWER_PRIORITY_UNION = 290,
     UPPER_PRIORITY_UNION = 291,
     LOWER_MINUS = 292,
     UPPER_MINUS = 293,
     MINUS = 294,
     UNION = 295,
     LEFT_QUOTIENT = 296,
     IGNORE_INTERNALLY = 297,
     IGNORING = 298,
     COMMACOMMA = 299,
     COMMA = 300,
     CONTAINMENT_OPT = 301,
     CONTAINMENT_ONCE = 302,
     CONTAINMENT = 303,
     COMPLEMENT = 304,
     TERM_COMPLEMENT = 305,
     SUBSTITUTE_LEFT = 306,
     LOWER_PROJECT = 307,
     UPPER_PROJECT = 308,
     INVERT = 309,
     REVERSE = 310,
     PLUS = 311,
     STAR = 312,
     READ_LEXC = 313,
     READ_RE = 314,
     READ_PROLOG = 315,
     READ_SPACED = 316,
     READ_TEXT = 317,
     READ_BIN = 318,
     CATENATE_N_TO_K = 319,
     CATENATE_N_MINUS = 320,
     CATENATE_N_PLUS = 321,
     CATENATE_N = 322,
     LEFT_BRACKET = 323,
     RIGHT_BRACKET = 324,
     LEFT_PARENTHESIS = 325,
     RIGHT_PARENTHESIS = 326,
     LEFT_BRACKET_DOTTED = 327,
     RIGHT_BRACKET_DOTTED = 328,
     PAIR_SEPARATOR = 329,
     PAIR_SEPARATOR_SOLE = 330,
     PAIR_SEPARATOR_WO_RIGHT = 331,
     PAIR_SEPARATOR_WO_LEFT = 332,
     EPSILON_TOKEN = 333,
     ANY_TOKEN = 334,
     BOUNDARY_MARKER = 335,
     LEXER_ERROR = 336,
     SYMBOL = 337,
     SYMBOL_WITH_LEFT_PAREN = 338,
     QUOTED_LITERAL = 339,
     CURLY_LITERAL = 340,
     ALPHA = 341,
     LOWERALPHA = 342,
     UPPERALPHA = 343,
     NUM = 344,
     PUNCT = 345,
     WHITESPACE = 346,
     COUNTER_LEFT = 347,
     SIGMA_LEFT = 348,
     INTERPOLATE_LEFT = 349,
     EXC_LEFT = 350,
     LST_LEFT = 351,
     TAG_LEFT = 352,
     AND_LEFT = 353,
     OR_LEFT = 354,
     NRC_LEFT = 355,
     NLC_LEFT = 356,
     RC_LEFT = 357,
     LC_LEFT = 358,
     ENDTAG_LEFT = 359,
     DEFINE_LEFT = 360,
     TOUPPER_LEFT = 361,
     TOLOWER_LEFT = 362,
     OPTCAP_LEFT = 363,
     DEFINED_LIST = 364,
     DEFINS = 365,
     REGEX = 366,
     INS_LEFT = 367,
     LIT_LEFT = 368,
     DEFINE = 369
   };
#endif
/* Tokens.  */
#define WEIGHT 258
#define END_OF_WEIGHTED_EXPRESSION 259
#define CHARACTER_RANGE 260
#define MERGE_LEFT_ARROW 261
#define MERGE_RIGHT_ARROW 262
#define INTERSECTION 263
#define LENIENT_COMPOSITION 264
#define COMPOSITION 265
#define CROSS_PRODUCT 266
#define MARKUP_MARKER 267
#define CENTER_MARKER 268
#define AFTER 269
#define BEFORE 270
#define SHUFFLE 271
#define LEFT_RESTRICTION 272
#define LEFT_RIGHT_ARROW 273
#define RIGHT_ARROW 274
#define LEFT_ARROW 275
#define LTR_SHORTEST_MATCH 276
#define LTR_LONGEST_MATCH 277
#define RTL_SHORTEST_MATCH 278
#define RTL_LONGEST_MATCH 279
#define OPTIONAL_REPLACE_LEFT_RIGHT 280
#define REPLACE_LEFT_RIGHT 281
#define OPTIONAL_REPLACE_LEFT 282
#define OPTIONAL_REPLACE_RIGHT 283
#define REPLACE_LEFT 284
#define REPLACE_RIGHT 285
#define REPLACE_CONTEXT_LL 286
#define REPLACE_CONTEXT_UL 287
#define REPLACE_CONTEXT_LU 288
#define REPLACE_CONTEXT_UU 289
#define LOWER_PRIORITY_UNION 290
#define UPPER_PRIORITY_UNION 291
#define LOWER_MINUS 292
#define UPPER_MINUS 293
#define MINUS 294
#define UNION 295
#define LEFT_QUOTIENT 296
#define IGNORE_INTERNALLY 297
#define IGNORING 298
#define COMMACOMMA 299
#define COMMA 300
#define CONTAINMENT_OPT 301
#define CONTAINMENT_ONCE 302
#define CONTAINMENT 303
#define COMPLEMENT 304
#define TERM_COMPLEMENT 305
#define SUBSTITUTE_LEFT 306
#define LOWER_PROJECT 307
#define UPPER_PROJECT 308
#define INVERT 309
#define REVERSE 310
#define PLUS 311
#define STAR 312
#define READ_LEXC 313
#define READ_RE 314
#define READ_PROLOG 315
#define READ_SPACED 316
#define READ_TEXT 317
#define READ_BIN 318
#define CATENATE_N_TO_K 319
#define CATENATE_N_MINUS 320
#define CATENATE_N_PLUS 321
#define CATENATE_N 322
#define LEFT_BRACKET 323
#define RIGHT_BRACKET 324
#define LEFT_PARENTHESIS 325
#define RIGHT_PARENTHESIS 326
#define LEFT_BRACKET_DOTTED 327
#define RIGHT_BRACKET_DOTTED 328
#define PAIR_SEPARATOR 329
#define PAIR_SEPARATOR_SOLE 330
#define PAIR_SEPARATOR_WO_RIGHT 331
#define PAIR_SEPARATOR_WO_LEFT 332
#define EPSILON_TOKEN 333
#define ANY_TOKEN 334
#define BOUNDARY_MARKER 335
#define LEXER_ERROR 336
#define SYMBOL 337
#define SYMBOL_WITH_LEFT_PAREN 338
#define QUOTED_LITERAL 339
#define CURLY_LITERAL 340
#define ALPHA 341
#define LOWERALPHA 342
#define UPPERALPHA 343
#define NUM 344
#define PUNCT 345
#define WHITESPACE 346
#define COUNTER_LEFT 347
#define SIGMA_LEFT 348
#define INTERPOLATE_LEFT 349
#define EXC_LEFT 350
#define LST_LEFT 351
#define TAG_LEFT 352
#define AND_LEFT 353
#define OR_LEFT 354
#define NRC_LEFT 355
#define NLC_LEFT 356
#define RC_LEFT 357
#define LC_LEFT 358
#define ENDTAG_LEFT 359
#define DEFINE_LEFT 360
#define TOUPPER_LEFT 361
#define TOLOWER_LEFT 362
#define OPTCAP_LEFT 363
#define DEFINED_LIST 364
#define DEFINS 365
#define REGEX 366
#define INS_LEFT 367
#define LIT_LEFT 368
#define DEFINE 369




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 2068 of yacc.c  */
#line 36 "pmatch_parse.yy"

         int value;
         int* values;
         double weight;
         char* label;
         hfst::pmatch::PmatchObject* pmatchObject;
         std::pair<std::string, hfst::pmatch::PmatchObject*>* pmatchDefinition;
         std::vector<hfst::pmatch::PmatchObject *>* pmatchObject_vector;
         std::vector<std::string>* string_vector;

         hfst::pmatch::PmatchParallelRulesContainer * replaceRules;
         hfst::pmatch::PmatchReplaceRuleContainer * replaceRule;
         hfst::pmatch::PmatchMappingPairsContainer * mappings;
         hfst::pmatch::PmatchContextsContainer * parallelContexts;
         hfst::pmatch::PmatchObjectPair * restrictionContext;
         hfst::pmatch::MappingPairVector * restrictionContexts;
         hfst::xeroxRules::ReplaceType replType;
         hfst::xeroxRules::ReplaceArrow replaceArrow; 
     


/* Line 2068 of yacc.c  */
#line 300 "pmatch_parse.hh"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE pmatchlval;


